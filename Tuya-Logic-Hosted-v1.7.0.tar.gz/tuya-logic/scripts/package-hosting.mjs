// Dependency-free, allowlisted source package. Never traverses user data or parent folders.
import {readFile, writeFile, mkdir, lstat} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {gzipSync, gunzipSync} from 'node:zlib';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';

const root = fileURLToPath(new URL('../', import.meta.url));
const sourceFiles = [
  'Dockerfile', '.dockerignore', '.gitignore', 'DEPLOYMENT.md', 'package.json', 'package-lock.json',
  'src/engine.mjs', 'src/program.mjs', 'src/scenes.mjs', 'src/server.mjs', 'src/storage.mjs', 'src/tuya.mjs',
  'src/supabase-storage.mjs', 'sql/supabase.sql',
  'public/app.js', 'public/ladder.js', 'public/ladder-ui.js', 'public/ladder-network.js', 'public/ladder-canvas.js',
  'public/fbd-editor.js', 'public/fbd.css', 'public/property-labels.js',
  'public/styles.css', 'public/index.html', 'public/icon.svg',
  'scripts/healthcheck.mjs', 'scripts/generate-lock.mjs', 'scripts/package-hosting.mjs'
].sort();
const hash = data => createHash('sha256').update(data).digest('hex');

async function readSources() {
  const files = new Map();
  for (const name of sourceFiles) {
    const location = path.join(root, name);
    const info = await lstat(location);
    assert(info.isFile() && !info.isSymbolicLink(), `Not an ordinary file: ${name}`);
    const content = await readFile(location);
    // Catch accidentally embedded credentials without printing the match.
    const body = content.toString('utf8');
    assert(!/sk-[A-Za-z0-9_-]{24,}|sb_secret_[A-Za-z0-9_-]{20,}|eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}/.test(body), `Possible embedded credential in ${name}`);
    files.set(name, content);
  }
  const pkg = JSON.parse(files.get('package.json'));
  const lock = JSON.parse(files.get('package-lock.json'));
  assert.equal(lock.lockfileVersion, 3);
  assert.equal(lock.version, pkg.version);
  assert.deepEqual(lock.packages[''].dependencies, pkg.dependencies);
  assert.equal(lock.packages['node_modules/ws'].version, pkg.dependencies.ws);
  assert.match(lock.packages['node_modules/ws'].integrity, /^sha512-/);
  const server = files.get('src/server.mjs').toString();
  const storage = files.get('src/storage.mjs').toString();
  for (const required of ['TUYA_HOSTED', 'PUBLIC_ORIGIN', '/api/health']) {
    assert(server.includes(required), `Hosted server contract missing: ${required}`);
  }
  for (const required of ['TUYA_AUTH_SALT', 'TUYA_AUTH_HASH', 'TUYA_API_KEY']) {
    assert((server + storage).includes(required), `Hosted environment contract missing: ${required}`);
  }
  return {files, pkg};
}

function tarEntry(name, data) {
  assert(Buffer.byteLength(name) <= 100, `Archive path too long: ${name}`);
  const header = Buffer.alloc(512);
  header.write(name, 0, 100, 'utf8');
  const octal = (value, offset, length) => header.write(value.toString(8).padStart(length - 1, '0') + '\0', offset, length, 'ascii');
  octal(0o644, 100, 8); octal(0, 108, 8); octal(0, 116, 8);
  octal(data.length, 124, 12); octal(0, 136, 12);
  header.fill(0x20, 148, 156); header[156] = 0x30;
  header.write('ustar\0', 257, 6, 'ascii'); header.write('00', 263, 2, 'ascii');
  header.write([...header].reduce((sum, byte) => sum + byte, 0).toString(8).padStart(6, '0') + '\0 ', 148, 8, 'ascii');
  return Buffer.concat([header, data, Buffer.alloc((512 - data.length % 512) % 512)]);
}

function verifyArchive(archive, expectedSources) {
  const tar = gunzipSync(archive, {maxOutputLength: 32 * 1024 * 1024});
  const files = new Map();
  const readString = bytes => bytes.toString('utf8').replace(/\0.*$/s, '');
  let offset = 0;
  while (offset + 512 <= tar.length) {
    const header = tar.subarray(offset, offset + 512);
    if (header.every(byte => byte === 0)) break;
    const checksum = parseInt(readString(header.subarray(148, 156)).trim(), 8);
    const actualChecksum = [...header].reduce((sum, byte, index) => sum + (index >= 148 && index < 156 ? 32 : byte), 0);
    assert.equal(checksum, actualChecksum, 'Archive header checksum mismatch');
    assert.equal(header[156], 0x30, 'Only regular archive files are allowed');
    const name = readString(header.subarray(0, 100));
    assert(name.startsWith('tuya-logic/') && !name.includes('..') && !files.has(name), 'Unsafe or duplicate archive path');
    const length = parseInt(readString(header.subarray(124, 136)), 8);
    assert(Number.isSafeInteger(length) && length >= 0 && offset + 512 + length <= tar.length, 'Invalid archive size');
    files.set(name.slice('tuya-logic/'.length), tar.subarray(offset + 512, offset + 512 + length));
    offset += 512 + Math.ceil(length / 512) * 512;
  }
  assert.deepEqual([...files.keys()].sort(), [...sourceFiles, 'manifest.json'].sort(), 'Archive contains unexpected or missing files');
  const manifest = JSON.parse(files.get('manifest.json'));
  assert.deepEqual(Object.keys(manifest.files).sort(), sourceFiles);
  for (const name of sourceFiles) {
    assert.equal(files.get(name).length, manifest.files[name].bytes, `Length mismatch: ${name}`);
    assert.equal(hash(files.get(name)), manifest.files[name].sha256, `Hash mismatch: ${name}`);
    if (expectedSources) assert.equal(hash(files.get(name)), hash(expectedSources.get(name)), `Current source differs: ${name}`);
  }
  return {version: manifest.version, files: files.size, bytes: archive.length, sha256: hash(archive)};
}

const [mode = '--check', target] = process.argv.slice(2);
if (mode === '--verify') {
  assert(target, 'Usage: node scripts/package-hosting.mjs --verify <archive.tar.gz>');
  const {files} = await readSources();
  console.log(JSON.stringify({verified: true, matchesCurrentSources: true, ...verifyArchive(await readFile(path.resolve(target)), files)}, null, 2));
} else {
  assert(mode === '--check' || mode === '--archive', 'Use --check, --archive, or --verify <archive.tar.gz>.');
  const {files, pkg} = await readSources();
  if (mode === '--check') {
    console.log(JSON.stringify({checked: true, version: pkg.version, files: files.size, note: 'Source/dependency/hosted contract check only; not a Docker runtime test.'}, null, 2));
  } else {
    const manifest = {format: 1, name: 'Tuya Logic hosted source', version: pkg.version, files: {}};
    for (const [name, data] of files) manifest.files[name] = {bytes: data.length, sha256: hash(data)};
    files.set('manifest.json', Buffer.from(JSON.stringify(manifest, null, 2) + '\n'));
    const archive = gzipSync(Buffer.concat([...files].map(([name, data]) => tarEntry(`tuya-logic/${name}`, data)).concat(Buffer.alloc(1024))), {level: 9});
    const verified = verifyArchive(archive, files);
    const outputDir = path.join(root, 'artifacts');
    await mkdir(outputDir, {recursive: true});
    const output = path.join(outputDir, `Tuya-Logic-Hosted-v${pkg.version}.tar.gz`);
    // Refuse to replace an earlier reviewed artifact silently.
    await writeFile(output, archive, {flag: 'wx'});
    await writeFile(`${output}.sha256`, `${verified.sha256}  ${path.basename(output)}\n`, {flag: 'wx'});
    console.log(JSON.stringify({archive: output, verified: true, ...verified}, null, 2));
  }
}
