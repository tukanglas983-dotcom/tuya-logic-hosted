// Pure ladder-to-graph compiler shared by the editor and server.
import {compileNetwork} from './ladder-network.js';
const copy = value => JSON.parse(JSON.stringify(value));
const idPattern = /^[A-Za-z][A-Za-z0-9_-]{0,23}$/;
const primitive = value => typeof value === 'boolean' || typeof value === 'string' || typeof value === 'number' && Number.isFinite(value);
const comparisons = new Set(['GT','GTE','LT','LTE','EQ','NEQ']);
const mathTypes = new Set(['ADD','SUB','MUL','DIV','MOD','ABS','MIN','MAX','CLAMP','SELECT']);
const booleanTypes = new Set(['AND','OR','XOR','NAND','NOR']);
const unary = new Set(['NOT','R_TRIG','F_TRIG','TON','TOF','PULSE','BLINK']);
const stateful = new Set(['TONR','COUNTER','CTD','CTUD','LATCH','SR']);
function fail(message) { throw new Error(message); }
function validId(id, label) { if(typeof id!=='string'||!idPattern.test(id))fail(`${label} must start with a letter and contain at most 24 letters, digits, underscores or hyphens.`); return id; }
function text(value, fallback, max=160) {const v=value ?? fallback;if(typeof v!=='string'||!v.trim()||v.length>max)fail(`A label must contain 1–${max} characters.`);return v;}
export function compileLadder(source,options={}) {return source?.version===2?compileNetwork(source,options):compileLadderV1(source,options);}
export function compileLadderV1(source,{id='ladder-program',name='Ladder program'}={}) {
  if(!source||source.version!==1||!Array.isArray(source.tags)||!Array.isArray(source.rungs))fail('Unsupported ladder format.');
  if(source.tags.length>512||source.rungs.length>64)fail('A ladder supports up to 512 mapped tags and 64 rungs.');
  const ladder=copy(source),tags=new Map(),addresses=new Set(),rungIds=new Set(),nodes=[],nodeIds=new Set(),tagInputs=new Map(),refTypes=new Map();
  const add=(nodeId,type,inputs=[],params={},label=type)=>{
    if(nodeIds.has(nodeId))fail(`Duplicate ladder element: ${nodeId}.`);if(nodes.length>=512)fail('The compiled ladder exceeds 512 logic blocks.');
    const types=inputs.map(id=>refTypes.get(id));
    if(mathTypes.has(type)&&type!=='SELECT'&&types.some(t=>t&&t!=='number'))fail(`${type} requires numeric operands.`);
    if(['GT','GTE','LT','LTE'].includes(type)&&types.some(t=>t&&t!=='number'))fail(`${type} requires numeric operands.`);
    if(['EQ','NEQ'].includes(type)&&types[0]&&types[1]&&types[0]!==types[1])fail(`${type} requires operands of the same type.`);
    if(type==='SELECT'&&(types[0]!=='boolean'||types[1]!==types[2]))fail('SELECT needs a boolean condition and two values of the same type.');
    if((booleanTypes.has(type)||unary.has(type)||stateful.has(type))&&types.some(t=>t&&t!=='boolean'))fail(`${type} requires boolean operands.`);
    refTypes.set(nodeId,type==='CONST'?typeof params.value:type==='SELECT'?types[1]:mathTypes.has(type)?'number':'boolean');
    nodeIds.add(nodeId);nodes.push({id:nodeId,type,label,inputs,params});return nodeId;
  };
  const constant=(nodeId,value)=>{if(!primitive(value))fail('Operands must be a finite number, boolean, or text.');return add(nodeId,'CONST',[],{value},String(value));};
  for(const tag of ladder.tags) {
    validId(tag.id,'Tag ID');if(tags.has(tag.id))fail(`Duplicate tag: ${tag.id}.`);
    if(!['input','output'].includes(tag.direction)||!['boolean','number','string'].includes(tag.dataType))fail(`Invalid direction or data type for ${tag.id}.`);
    tag.name=text(tag.name,tag.id);tag.address=text(tag.address,tag.id,30);
    if(addresses.has(tag.address.toUpperCase()))fail(`Duplicate I/O address: ${tag.address}.`);addresses.add(tag.address.toUpperCase());
    if(tag.source==='virtual') {
      if(tag.direction!=='input'||!['boolean','number'].includes(tag.dataType))fail('Virtual inputs must be boolean or numeric input tags.');
      if(tag.deviceId||tag.code)fail('Virtual inputs cannot be mapped to a physical device property.');
      if(tag.dataType==='number'&&(typeof tag.defaultValue!=='number'||!Number.isFinite(tag.defaultValue)))fail('Numeric virtual inputs require a finite default value.');
      if(tag.dataType==='boolean'&&tag.defaultValue!==undefined&&tag.defaultValue!==false)fail('Virtual switches must default to FALSE.');
      if(tag.unit!==undefined&&(typeof tag.unit!=='string'||tag.unit.length>16))fail('Virtual input unit must be text of at most 16 characters.');
      delete tag.deviceId;delete tag.code;
    }else {
      if(tag.source!==undefined&&tag.source!=='physical')fail(`Unknown input source for ${tag.name}.`);
      tag.deviceId=text(tag.deviceId,undefined,200);tag.code=text(tag.code,undefined,200);
    }
    tag.scale=tag.scale ?? 1;tag.offset=tag.offset ?? 0;
    if(!Number.isFinite(tag.scale)||!Number.isFinite(tag.offset))fail(`Invalid scaling for ${tag.name}.`);
    if(tag.source==='virtual'&&(tag.scale!==1||tag.offset!==0))fail('Virtual inputs use their entered value directly; scale must be 1 and offset 0.');
    if(tag.dataType!=='number'&&(tag.scale!==1||tag.offset!==0))fail(`Only numeric tags can use scaling: ${tag.name}.`);
    tags.set(tag.id,tag);
  }
  const getTag=tagId=>tags.get(tagId)||fail(`Map the I/O tag ${tagId || '(not selected)'} before saving.`);
  function input(tagId) {
    const tag=getTag(tagId);
    if(tag.direction!=='input')fail(`Use a readable input tag for ${tag.name}. Map the device feedback separately in I/O mapping.`);
    if(!tagInputs.has(tagId)){tagInputs.set(tagId,tag.source==='virtual'?add(`tag_${tagId}`,'VIRTUAL',[],{defaultValue:tag.dataType==='number'?tag.defaultValue:false,...(tag.unit!==undefined?{unit:tag.unit}:{})},tag.name):add(`tag_${tagId}`,'INPUT',[],{deviceId:tag.deviceId,code:tag.code,scale:tag.scale,offset:tag.offset},`${tag.address} · ${tag.name}`));refTypes.set(tagInputs.get(tagId),tag.dataType);}
    return tagInputs.get(tagId);
  }
  function boolTag(tagId,otherwise,nodeId) {if(!tagId)return constant(nodeId,otherwise);if(getTag(tagId).dataType!=='boolean')fail(`${tagId} must be a boolean tag.`);return input(tagId);}
  const written=new Set();
  for(const rung of ladder.rungs) {
    validId(rung.id,'Rung ID');if(rungIds.has(rung.id))fail(`Duplicate rung: ${rung.id}.`);rungIds.add(rung.id);
    rung.name=text(rung.name,rung.id);if(!Array.isArray(rung.branches)||!rung.branches.length||rung.branches.length>16)fail(`${rung.name} needs 1–16 parallel branches.`);
    if(rung.blocks===undefined)rung.blocks=[];else if(!Array.isArray(rung.blocks))fail('Rung instructions must be an array.');
    const localIds=new Set(['flow','coil']),blockRefs=new Map(),prefix=`ld_${rung.id}_`;
    const elementId=el=>{validId(el.id,'Element ID');if(localIds.has(el.id))fail(`Duplicate element ${el.id} in ${rung.name}.`);localIds.add(el.id);return prefix+el.id;};
    const branchRefs=[];
    for(const branch of rung.branches) {
      const branchId=elementId(branch);
      if(!Array.isArray(branch.contacts)||branch.contacts.length>32)fail('A branch supports up to 32 series contacts.');
      const contactRefs=[];
      for(const contact of branch.contacts) {
        const contactId=elementId(contact),tag=getTag(contact.tagId),ref=input(tag.id);
        if(contact.kind==='NO'||contact.kind==='NC') {
          if(tag.dataType!=='boolean')fail(`Use a comparison contact for ${tag.name}; NO/NC contacts require boolean tags.`);
          contactRefs.push(contact.kind==='NC'?add(contactId,'NOT',[ref],{},tag.address):add(contactId,'OR',[ref,constant(contactId+'_z',false)],{},tag.address));
        }else if(contact.kind==='COMPARE') {
          if(!comparisons.has(contact.operator))fail('Select a supported comparison operator.');
          const right=contact.valueTagId?input(contact.valueTagId):constant(contactId+'_v',contact.value);
          contactRefs.push(add(contactId,contact.operator,[ref,right],{},`${tag.address} ${contact.operator}`));
        }else fail('Select Normally Open, Normally Closed, or Comparison contact.');
      }
      branchRefs.push(!contactRefs.length?constant(branchId,true):contactRefs.length===1?add(branchId,'OR',[contactRefs[0],constant(branchId+'_z',false)]):add(branchId,'AND',contactRefs));
    }
    let flow=add(prefix+'flow','OR',branchRefs.length===1?[branchRefs[0],constant(prefix+'flow_z',false)]:branchRefs,{},rung.name);
    function operand(o,key) {
      if(!o||typeof o!=='object')fail('Select a tag, constant, or earlier function result for each operand.');
      if(o.tagId)return input(o.tagId);
      if(o.blockId)return blockRefs.get(o.blockId)||fail(`Function ${o.blockId} must appear earlier in this rung.`);
      if(Object.hasOwn(o,'value'))return constant(key,o.value);
      fail('Invalid function operand.');
    }
    for(const block of rung.blocks) {
      const blockId=elementId(block),params=block.params || {},type=block.type;
      let refs,result;
      if(mathTypes.has(type)||comparisons.has(type)) {
        if(!Array.isArray(block.operands))fail(`Set the operands for ${type}.`);
        refs=block.operands.map((o,i)=>operand(o,`${blockId}_v${i}`));
        result=add(blockId,type,refs,params,type);blockRefs.set(block.id,result);
        if(comparisons.has(type))flow=add(blockId+'_gate','AND',[flow,result]);
      }else if(booleanTypes.has(type)) {
        refs=[flow,...(block.operands || []).map((o,i)=>operand(o,`${blockId}_v${i}`))];
        if(refs.length<2)fail(`${type} requires at least one additional boolean operand.`);
        flow=add(blockId,type,refs,params,type);blockRefs.set(block.id,flow);
      }else if(unary.has(type)) {
        flow=add(blockId,type,[flow],params,type);blockRefs.set(block.id,flow);
      }else if(stateful.has(type)) {
        const reset=boolTag(block.resetTagId,false,blockId+'_reset');
        refs=type==='CTUD'?[flow,boolTag(block.downTagId,false,blockId+'_down'),reset]:[flow,reset];
        flow=add(blockId,type,refs,params,type);blockRefs.set(block.id,flow);
      }else fail(`Unsupported ladder instruction: ${type}.`);
    }
    if(!rung.coil)fail(`Choose an output coil for ${rung.name}.`);
    const coil=rung.coil,tag=getTag(coil.tagId),mode=coil.mode || 'follow';
    if(tag.direction!=='output')fail(`${tag.name} is an input; select a writable output tag.`);
    const physical=tag.deviceId+'\0'+tag.code;if(written.has(physical))fail(`Only one coil may write ${tag.name}; combine its conditions using parallel branches.`);written.add(physical);
    if(['follow','pulse'].includes(mode)&&tag.dataType!=='boolean')fail('Continuous and Pulse require a boolean output.');
    if(!['trigger','follow','pulse','value','adjust'].includes(mode))fail('Select a supported output execution mode.');
    if(mode==='adjust'&&(tag.dataType!=='number'||typeof coil.delta!=='number'||!Number.isFinite(coil.delta)||coil.delta===0))fail('Increase/decrease requires a numeric output and a nonzero finite adjustment.');
    const params={deviceId:tag.deviceId,code:tag.code,mode};
    if(mode==='trigger'||mode==='pulse')params.value=coil.value;
    if(mode==='pulse')params.durationMs=coil.durationMs;
    if(mode==='adjust')params.delta=coil.delta;
    const refs=mode==='value'?[flow,operand(coil.source,prefix+'coil_v')]:[flow];
    if(mode==='value'&&refTypes.get(refs[1])!==tag.dataType)fail(`The source type must match output ${tag.name} (${tag.dataType}).`);
    if(['trigger','pulse'].includes(mode)&&typeof params.value!==tag.dataType)fail(`The action value must match output ${tag.name} (${tag.dataType}).`);
    add(prefix+'coil','OUTPUT',refs,params,`${tag.address} · ${tag.name}`);
  }
  return {id:text(id,'ladder-program',80),name:text(name,'Ladder program'),nodes,ladder};
}

export function createDemoLadder() {
  return {version:1,tags:[
    {id:'current',name:'Plug current',address:'AI0',direction:'input',deviceId:'demo-switch',code:'cur_current',dataType:'number',scale:0.001,offset:0,unit:'A'},
    {id:'switch_status',name:'Switch feedback',address:'I0.0',direction:'input',deviceId:'demo-switch',code:'switch_1',dataType:'boolean',scale:1,offset:0,unit:''},
    {id:'switch_output',name:'Plug switch',address:'Q0.0',direction:'output',deviceId:'demo-switch',code:'switch_1',dataType:'boolean',scale:1,offset:0,unit:''}
  ],rungs:[{id:'r1',name:'Current above 2 A for 30 seconds',branches:[{id:'b1',contacts:[{id:'c1',tagId:'current',kind:'COMPARE',operator:'GT',value:2}]}],blocks:[{id:'timer1',type:'TON',params:{durationMs:30000}}],coil:{tagId:'switch_output',mode:'trigger',value:false}}]};
}

export function graphToLadder(program,devices=[]) {
  if([1,2].includes(program?.ladder?.version))return copy(program.ladder);
  if(!program?.nodes?.length)return {version:1,tags:[],rungs:[]};
  const nodes=program.nodes,byId=new Map(nodes.map(n=>[n.id,n])),outputs=nodes.filter(n=>n.type==='OUTPUT');
  if(outputs.length!==1 || outputs[0].inputs.length!==1)return null;
  const output=outputs[0],used=new Set([output.id]),blocks=[];
  let cursor=byId.get(output.inputs[0]);
  while(cursor&&unary.has(cursor.type)&&cursor.type!=='NOT') {
    used.add(cursor.id);blocks.unshift({id:`fn${blocks.length+1}`,type:cursor.type,params:copy(cursor.params || {})});cursor=byId.get(cursor.inputs[0]);
  }
  let source,contact;
  if(cursor&&comparisons.has(cursor.type)) {
    const left=byId.get(cursor.inputs[0]),right=byId.get(cursor.inputs[1]);
    if(left?.type!=='INPUT'||right?.type!=='CONST')return null;
    source=left;used.add(cursor.id);used.add(left.id);used.add(right.id);contact={id:'c1',tagId:'source',kind:'COMPARE',operator:cursor.type,value:right.params.value};
  }else if(cursor?.type==='INPUT') {source=cursor;used.add(cursor.id);contact={id:'c1',tagId:'source',kind:'NO'};}
  else return null;
  if(used.size!==nodes.length)return null;
  const d=devices.find(d=>d.id===source.params.deviceId),property=d?.properties?.[source.params.code];
  const dataType=contact.kind==='COMPARE'?typeof contact.value:typeof property?.value;
  if(!['boolean','number','string'].includes(dataType))return null;
  return {version:1,tags:[
    {id:'source',name:source.label || 'Input',address:dataType==='number'?'AI0':'I0.0',direction:'input',dataType,deviceId:source.params.deviceId,code:source.params.code,scale:source.params.scale ?? 1,offset:source.params.offset ?? 0,unit:source.params.code==='cur_current'&&source.params.scale===0.001?'A':property?.unit || ''},
    {id:'target',name:output.label || 'Output',address:output.params.mode==='adjust'?'AQ0':'Q0.0',direction:'output',dataType:output.params.mode==='adjust'?'number':typeof output.params.value,deviceId:output.params.deviceId,code:output.params.code,scale:1,offset:0,unit:''}
  ],rungs:[{id:'r1',name:program.name || 'Imported rung',branches:[{id:'b1',contacts:[contact]}],blocks,coil:{tagId:'target',mode:output.params.mode || 'trigger',value:output.params.value,durationMs:output.params.durationMs,...(output.params.mode==='adjust'?{delta:output.params.delta}:{})}}]};
}
