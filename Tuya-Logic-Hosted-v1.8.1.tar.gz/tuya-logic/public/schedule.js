// Shared calendar schedule rules; runtime time is supplied by the server engine.
const formatters=new Map();
const periods=new Set(['night','daytime','all_day','custom']);
const timelines=new Set(['every_day','selected_days']);
const weekdays={Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6,Sun:7};
const presets={night:{start:'17:30',end:'05:30'},daytime:{start:'05:30',end:'17:30'},all_day:{start:'00:00',end:'24:00'}};
function minuteOfDay(value,label){
  if(typeof value!=='string'||!/^([01]\d|2[0-3]):[0-5]\d$/.test(value))throw new Error(label+' must use 24-hour HH:MM format.');
  return Number(value.slice(0,2))*60+Number(value.slice(3));
}
function formatter(timeZone){
  if(typeof timeZone!=='string'||!timeZone||timeZone!==timeZone.trim()||timeZone.length>100)throw new Error('Select a valid schedule time zone.');
  if(formatters.has(timeZone))return formatters.get(timeZone);
  let result;try{result=new Intl.DateTimeFormat('en-GB-u-nu-latn',{timeZone,weekday:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});}catch{throw new Error('Unknown schedule time zone: '+timeZone+'.');}
  // A small shared cache avoids creating formatters on each PLC scan.
  if(formatters.size>=64)formatters.delete(formatters.keys().next().value);
  formatters.set(timeZone,result);return result;
}
export function validateSchedule(params){
  if(!params||typeof params!=='object'||Array.isArray(params))throw new Error('Set schedule parameters.');
  const legacy=!['period','timeline','days'].some(key=>Object.hasOwn(params,key)),period=params.period??'custom',timeline=params.timeline??'every_day';
  if(!periods.has(period)||params.period===null)throw new Error('Select Night, Daytime, All day, or Manual.');
  if(!timelines.has(timeline)||params.timeline===null)throw new Error('Select Every day or Selected days.');
  const range=period==='custom'?{start:params.start,end:params.end}:presets[period];
  if(period!=='all_day'){
    const start=minuteOfDay(range.start,'Schedule start'),end=minuteOfDay(range.end,'Schedule end');
    if(start===end)throw new Error('Schedule start and end must be different.');
  }
  let days;
  if(params.days!==undefined){
    if(!Array.isArray(params.days)||params.days.length>7||params.days.some(day=>!Number.isInteger(day)||day<1||day>7)||new Set(params.days).size!==params.days.length)throw new Error('Schedule days must be unique weekday numbers from 1 (Monday) to 7 (Sunday).');
    days=[...params.days].sort((a,b)=>a-b);
  }
  if(timeline==='selected_days'&&!days?.length)throw new Error('Select at least one day for this schedule.');
  formatter(params.timeZone);
  const result={start:range.start,end:range.end,timeZone:params.timeZone};
  return legacy?result:{period,timeline,...result,...(days===undefined?{}:{days})};
}
export function scheduleActive(params,wallEpochMs){
  if(typeof wallEpochMs!=='number'||!Number.isFinite(wallEpochMs)||!Number.isFinite(new Date(wallEpochMs).getTime()))throw new Error('The server wall clock is invalid.');
  const schedule=validateSchedule(params),parts=formatter(schedule.timeZone).formatToParts(wallEpochMs),hour=Number(parts.find(part=>part.type==='hour')?.value),minute=Number(parts.find(part=>part.type==='minute')?.value),weekday=weekdays[parts.find(part=>part.type==='weekday')?.value];
  if(!Number.isInteger(hour)||hour<0||hour>23||!Number.isInteger(minute)||minute<0||minute>59||!weekday)throw new Error('The server local time could not be read.');
  let active=true,anchorDay=weekday;
  if(schedule.period!=='all_day'){
    const start=minuteOfDay(schedule.start,'Schedule start'),end=minuteOfDay(schedule.end,'Schedule end'),current=hour*60+minute;
    active=start<end?current>=start&&current<end:current>=start||current<end;
    // Overnight windows belong to their start day, including after midnight.
    if(start>end&&current<end)anchorDay=weekday===1?7:weekday-1;
  }
  return active&&(schedule.timeline!=='selected_days'||schedule.days.includes(anchorDay));
}
