import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {createHash,randomBytes,scrypt,timingSafeEqual} from 'node:crypto';
import {promisify} from 'node:util';
import {Engine,validateProgram} from './engine.mjs';
import {Storage} from './storage.mjs';
import {TuyaClient,DemoClient,validateCommand,resolveAdjustment} from './tuya.mjs';
import {exampleProgram,emptyProgram} from './program.mjs';
import {compileLadder} from '../public/ladder.js';
import {SceneReader} from './scenes.mjs';
import {SupabaseStorage,supabaseConfiguration} from './supabase-storage.mjs';

const derive=promisify(scrypt), root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const safeError=e=>String(e.message || 'An error occurred.').replace(/sk-[A-Za-z0-9_-]+|sb_secret_[A-Za-z0-9_-]+|eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g,'[key redacted]').slice(0,400);
const isLocal=req=>['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress);
const canonicalJson=value=>JSON.stringify(value,(_,item)=>item&&typeof item==='object'&&!Array.isArray(item)?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);
const runtimeMutations=new Set(['/api/program','/api/run','/api/test-run','/api/live-test','/api/control','/api/input-force','/api/virtual-input','/api/demo']);

// Hosted authentication is provisioned before the public server can listen.
// A loopback reverse proxy must never gain local setup/credential privileges.
export function hostedConfiguration(env=process.env){
  if(env.TUYA_HOSTED!=='1')return null;
  const remote=supabaseConfiguration(env);
  let origin;
  try{origin=new URL(env.PUBLIC_ORIGIN);}catch{}
  if(!origin||origin.protocol!=='https:'||origin.origin!==env.PUBLIC_ORIGIN||origin.username||origin.password)throw new Error('Hosted mode requires PUBLIC_ORIGIN to be an exact HTTPS origin without a path, query, or credentials.');
  if(!remote&&(!env.TUYA_LOGIC_DATA||!path.isAbsolute(env.TUYA_LOGIC_DATA)))throw new Error('Hosted mode requires TUYA_LOGIC_DATA to point to an absolute persistent-volume directory.');
  if(!/^[0-9a-fA-F]{32}$/.test(env.TUYA_AUTH_SALT||'')||!/^[0-9a-fA-F]{128}$/.test(env.TUYA_AUTH_HASH||''))throw new Error('Hosted mode requires TUYA_AUTH_SALT (32 hex characters) and TUYA_AUTH_HASH (128 hex characters).');
  return {publicOrigin:origin.origin,dataDir:env.TUYA_LOGIC_DATA,remote,auth:{salt:env.TUYA_AUTH_SALT,hash:env.TUYA_AUTH_HASH}};
}

export async function createApp({dataDir,port=Number(process.env.PORT || 3210),host=process.env.HOST || '0.0.0.0',providerFactory,storageFactory,pollIntervalMs=15000}={}) {
  const hostedConfig=hostedConfiguration(),hosted=!!hostedConfig,publicOrigin=hostedConfig?.publicOrigin||process.env.PUBLIC_ORIGIN;
  const remoteStorage=!!hostedConfig?.remote;
  const storage=remoteStorage?(storageFactory?await storageFactory(hostedConfig.remote):new SupabaseStorage(hostedConfig.remote)):new Storage(dataDir||hostedConfig?.dataDir,{hosted});
  if(remoteStorage)await storage.initialize();
  const config=hosted?{}:storage.read('settings',{mode:'demo'});
  let apiKey=storage.loadKey(), auth=hosted?hostedConfig.auth:storage.read('auth',null), mode=(hosted||config.mode==='live')&&apiKey?'live':'demo';
  let provider, epoch=0, switchBusy=false, refreshBusy=false, closed=false, polling=false;
  let closePromise,programSaveBusy=false;
  let executionMode=null;
  const testOutputs=new Map(),outputFeedback=new Map(),outputKey=(id,code)=>id+'\0'+code;
  const inputForces=new Map(),inputForceFeedback=new Map(),inputForceJobs=new Map(),releasedInputForces=new Set();
  let connection={status:'demo',message:'Local simulation; no physical devices are controlled.'};
  const sessions=new Map(), attempts=new Map(), clients=new Map(), draftDownloads=new Map(),deviceWatches=new Map(),refreshJobs=new Map(),lastWatchRefresh=new Map();
  let refreshTail=Promise.resolve();
  const sceneReader=new SceneReader();
  let logs=storage.read('logs',[]).slice(-250); let saveLogsTimer;
  let programs=storage.read('programs',{demo:exampleProgram(),live:emptyProgram()});
  let program=programs[mode]||emptyProgram();
  const engine=new Engine({
    readInput:(id,code)=>{
      const key=outputKey(id,code),testing=executionMode==='test'&&engine.running;
      const forced=testing?inputForces.get(key):undefined;
      if(forced)return {value:forced.value,valid:true};
      const shadow=testing&&!releasedInputForces.has(key)?testOutputs.get(key):undefined;
      return shadow?{value:shadow.value,valid:true}:provider.readInput(id,code);
    },
    writeOutput:async(id,code,value,{nodeId,shouldSend=()=>true,adjustDelta}={})=>{
      const generation=epoch, active=provider,runMode=executionMode;
      const current=()=>hasRuntimeLease()&&shouldSend()&&generation===epoch&&active===provider&&engine.running&&executionMode===runMode;
      if(!current())return;
      const record={nodeId,deviceId:id,code,commandState:'pending',commandedAt:Date.now(),...(adjustDelta===undefined?{desiredValue:value}:{})};
      const sameRecord=()=>generation===epoch&&active===provider&&executionMode===runMode&&outputFeedback.get(nodeId)===record;
      outputFeedback.set(nodeId,record);broadcast();
      try {
       if(runMode==='test') {
        // This branch has no provider command path. Cached output values may
        // seed relative simulation, but never make physical INPUTs fresh.
        const device=testDevice(id);
        if(adjustDelta!==undefined)value=resolveAdjustment(device,code,adjustDelta);
        else validateCommand(device,code,value);
        if(!current()){if(sameRecord()){record.commandState='cancelled';broadcast();}return;}
        const key=outputKey(id,code);
        if(!testOutputs.has(key)&&testOutputs.size>=512)throw new Error('Too many simulated output properties.');
        testOutputs.set(key,{deviceId:id,code,value});
        Object.assign(record,{desiredValue:value,commandState:'simulated'});broadcast();
        log('info',`TEST output ${id} / ${code} = ${JSON.stringify(value)}; no device command sent.`);
        return;
       }
      if(!['live','live-test'].includes(runMode)){record.commandState='cancelled';broadcast();return;}
      log('info',adjustDelta===undefined?`Sending ${code} = ${JSON.stringify(value)} to ${id}.`:`Adjusting ${id} / ${code} by ${adjustDelta} raw units.`);
      const result=await active.issue(id,code,value,{adjustDelta,shouldSend:current});
      if(!sameRecord()||!engine.running)return;
      const confirmedValue=adjustDelta===undefined?value:result?.value,sample=active.readInput(id,code);
      if(result?.confirmed!==true||sample?.valid!==true||sample.value!==confirmedValue)throw new Error('The device output state is not confirmed. Check the device feedback.');
      Object.assign(record,{desiredValue:confirmedValue,commandState:'confirmed',confirmedAt:Date.now()});broadcast();
      log('success',`Status ${id} / ${code} confirmed: ${JSON.stringify(confirmedValue)}.`);
      }catch(error){
        if(sameRecord()) {
          Object.assign(record,current()?{commandState:'failed',commandError:safeError(error)}:{commandState:'cancelled'});broadcast();
        }
        throw error;
      }
    },
    onLog:(level,message)=>{if(message.startsWith('Program STOP')){cancelPendingOutputs();clearInputForces();}log(level,executionMode==='test'?'TEST · '+message:executionMode==='live-test'?'LIVE TEST · '+message:message);}
  });
  function log(level,message) {
    if(closed)return;
    logs.push({time:new Date().toISOString(),level,message:safeError({message})});
    if(logs.length>250) logs.shift();
    if(remoteStorage){if(!saveLogsTimer)saveLogsTimer=setTimeout(()=>{saveLogsTimer=null;if(storage.canWrite())void storage.write('logs',logs).catch(()=>{});},30000);}
    else{clearTimeout(saveLogsTimer);saveLogsTimer=setTimeout(()=>{try{storage.write('logs',logs);}catch{}},500);}
  }
  function cancelPendingOutputs(){for(const record of outputFeedback.values())if(record.commandState==='pending')record.commandState='cancelled';}
  function clearInputForces(){inputForces.clear();releasedInputForces.clear();inputForceJobs.clear();for(const record of inputForceFeedback.values())if(['pending','simulated'].includes(record.commandState))record.commandState='cancelled';}
  function resetOutputFeedback(){outputFeedback.clear();inputForceFeedback.clear();clearInputForces();for(const n of program.nodes)if(n.type==='OUTPUT')outputFeedback.set(n.id,{nodeId:n.id,deviceId:n.params.deviceId,code:n.params.code,commandState:'idle'});}
  function resetExecution() {cancelPendingOutputs();clearInputForces();executionMode=null;testOutputs.clear();}
  function stop(reason='Program stopped.') {epoch++;resetExecution();engine.stop();log('info',reason);broadcast();}
  function testDevice(id) {
    const device=provider.list().find(d=>d.id===id);
    if(!device)return undefined;
    const properties=Object.fromEntries(Object.entries(device.properties||{}).map(([code,sample])=>[code,{...sample,valid:true}]));
    for(const shadow of testOutputs.values())if(shadow.deviceId===id)properties[shadow.code]={value:shadow.value,valid:true};
    return {...device,online:true,error:undefined,properties};
  }
  function inputForceTarget(deviceId,code,value,{simulation=false,release=false}={}){
    if(typeof deviceId!=='string'||typeof code!=='string'||!deviceId||!code||deviceId.length>200||code.length>200)fail(400,'Select a known device and property for input forcing.');
    if(!program.nodes.some(n=>n.type==='INPUT'&&n.params.deviceId===deviceId))fail(400,'Input forcing is available only for devices referenced by this program.');
    const device=provider.list().find(d=>d.id===deviceId),property=device?.model.find(p=>p.code===code);
    if(!property||!['ro','rw'].includes(property.accessMode))fail(400,'Select a readable input property.');
    if(!['bool','value','enum','string'].includes(property.typeSpec?.type))fail(400,'Input forcing supports boolean, number, enum, and text properties; raw and bitmap payloads are unsupported.');
    if(release)return {device,property};
    if(simulation){
      // Reuse actual model bounds without granting physical write access to a
      // read-only sensor. Only this temporary validation copy is writable.
      validateCommand({...device,online:true,model:[{...property,accessMode:'rw'}]},code,value);
    }else{
      if(mode!=='live'||provider.status!=='connected')fail(409,'Reconnect to Tuya before forcing a physical input.');
      if(property.accessMode!=='rw')fail(400,'This sensor is read-only. Simulate it with Test Run; Live Test cannot command it.');
      if(program.nodes.some(n=>n.type==='OUTPUT'&&n.params.deviceId===deviceId&&n.params.code===code))fail(409,'This property is controlled by a program output. Input forcing cannot compete with that coil.');
      validateCommand(device,code,value);
      if(device.error||provider.readInput(deviceId,code)?.valid!==true)fail(409,'The input device value is stale or unavailable. Refresh its feedback before Live Test forcing.');
    }
    return {device,property};
  }
  function hasRuntimeLease(){return !closed&&(!remoteStorage||storage.canWrite());}
  function requireRuntimeLease(){if(!hasRuntimeLease())fail(503,'This server does not hold a verified runtime lease. Changes and commands are disabled until shared storage reconnects.');}
  engine.setProgram(program);
  resetOutputFeedback();
  const ips=Object.values(os.networkInterfaces()).flat().filter(n=>n?.family==='IPv4'&&!n.internal).map(n=>n.address);
  const allowedHosts=new Set(hosted?[]:['localhost','127.0.0.1','[::1]',os.hostname().toLowerCase(),...ips]);
  if(publicOrigin) {const u=new URL(publicOrigin);if(u.protocol!=='https:')throw new Error('PUBLIC_ORIGIN must use HTTPS.');allowedHosts.add(u.hostname);}
  let actualPort=port;
  let revisionProgram,revisionMode,revision;
  function programRevision() {
    if(revisionProgram!==program||revisionMode!==mode){revision=createHash('sha256').update(canonicalJson({mode,program})).digest('hex');revisionProgram=program;revisionMode=mode;}
    return revision;
  }
  function state() {const lease=remoteStorage?storage.leaseState():undefined,runtime=engine.snapshot();return {mode,configured:!!apiKey,connection,devices:provider?.list() || [],program,programRevision:programRevision(),runtime:{...runtime,executionMode:runtime.running?executionMode:null,testOutputs:runtime.running&&executionMode==='test'?[...testOutputs.values()]:[],inputForces:runtime.running&&executionMode==='test'?[...inputForces.values()].map(record=>({...record})):[],inputForceFeedback:[...inputForceFeedback.values()].map(record=>({...record})),outputFeedback:[...outputFeedback.values()].map(record=>({...record}))},logs:[...logs].reverse(),server:{hosted,persistence:remoteStorage?'supabase':'file',...(lease?{lease}:{}),urls:hosted?[publicOrigin]:[`http://localhost:${actualPort}`,...ips.map(ip=>`http://${ip}:${actualPort}`),...(publicOrigin?[publicOrigin]:[])],version:'1.6.1'}};}
  function broadcast() {
    if(!clients.size)return;
    const packet=`event: state\ndata: ${JSON.stringify(state())}\n\n`;
    for(const [res,{token}] of clients) {
      if(!sessions.has(token) || sessions.get(token)<Date.now()) {res.end();clients.delete(res);continue;}
      if(res.writableLength>1000000){res.end();clients.delete(res);}else res.write(packet);
    }
  }
  if(remoteStorage)storage.onChange=(lease,{reloaded=false}={})=>{
    if(closed)return;
    if(!lease.writable){epoch++;resetExecution();engine.stop();}
    if(reloaded){
      try{
        const saved=storage.read('programs',{demo:exampleProgram(),live:emptyProgram()});
        const next=normalizeProgram(saved[mode]||emptyProgram());checkProgram(next);
        epoch++;resetExecution();engine.stop();engine.setProgram(next);programs=saved;program=next;resetOutputFeedback();
        logs=storage.read('logs',[]).slice(-250);
      }catch{storage.revoke('The shared program could not be validated. Runtime disabled until the stored program is repaired.');}
    }
    broadcast();
  };
  async function activate(newMode) {
    epoch++;resetExecution();engine.stop();provider?.close();deviceWatches.clear();lastWatchRefresh.clear();
    mode=newMode;program=programs[mode] || emptyProgram();engine.setProgram(program);resetOutputFeedback();
    const active=provider=providerFactory?await providerFactory({mode}):mode==='demo'?new DemoClient():new TuyaClient(apiKey);
    connection=mode==='demo'?{status:'demo',message:'Local simulation; no physical devices are controlled.'}:{status:'connecting',message:'Reading devices from your Tuya account…'};
    active.on?.('warning',message=>{if(active===provider)log('warning',message);});
    active.on?.('status',status=>{
      if(active!==provider)return;
      connection={status,message:status==='connected'?'Tuya events connected.':'Event connection is not ready; inputs are marked invalid.'};
      if(status!=='connected' && engine.running && ['live','live-test'].includes(executionMode)) stop('Tuya disconnected. Program stopped; press Run again after reconnection.');
      broadcast();
    });
    active.on?.('change',()=>{if(active===provider)broadcast();});
    if(mode==='demo')return;
    try {await active.discover();if(active===provider&&!closed)active.connect();}
    catch(e){if(active===provider&&!closed){connection={status:'error',message:safeError(e)};log('error',safeError(e));}}
  }
  if(mode==='live') {
    // The local UI must be available while a large account is discovered.
    // Mutations remain locked until the initial connection operation finishes.
    switchBusy=true;
    void activate(mode).catch(e=>{if(!closed){connection={status:'error',message:safeError(e)};log('error',safeError(e));}}).finally(()=>{switchBusy=false;if(!closed)broadcast();});
  } else await activate(mode);
  const ticks=setInterval(()=>{if(!closed){if(!hasRuntimeLease())return;engine.tick().then(broadcast).catch(e=>{stop('Execution failed: '+safeError(e));});}},100);
  const updates=setInterval(broadcast,1000);
  function watchedDeviceIds() {
    const ids=new Set(),time=Date.now();
    for(const [token,watch]of deviceWatches){
      if(watch.expires<=time||!sessions.has(token)||sessions.get(token)<=time){deviceWatches.delete(token);continue;}
      for(const id of watch.ids)ids.add(id);
    }
    return ids;
  }
  function refreshDevice(id) {
    if(mode!=='live'||closed)return Promise.resolve();
    const active=provider,existing=refreshJobs.get(id);
    if(existing?.provider===active)return existing.promise;
    const job={provider:active};
    const work=refreshTail.then(async()=>{
      if(closed||active!==provider||mode!=='live')return;
      lastWatchRefresh.set(id,Date.now());
      try{await active.refresh(id);}catch(error){if(active===provider&&!closed)log('warning',safeError(error));}
      if(active===provider&&!closed)broadcast();
    }).finally(()=>{if(refreshJobs.get(id)===job)refreshJobs.delete(id);});
    job.promise=work;refreshJobs.set(id,job);refreshTail=work.catch(()=>{});return work;
  }
  const poll=setInterval(async()=>{
    if(mode!=='live'||polling||refreshBusy||switchBusy||provider.status!=='connected')return;
    polling=true;const active=provider;
    try {
      const known=new Set(active.list().map(d=>d.id));
      const used=new Set([...program.nodes.filter(n=>['INPUT','OUTPUT'].includes(n.type)).map(n=>n.params.deviceId),...watchedDeviceIds()]);
      for(const id of used) {if(active!==provider)break;if(known.has(id))await refreshDevice(id);}
    }catch(e){log('warning',safeError(e));}finally{polling=false;}
  },pollIntervalMs);
  const cleanup=setInterval(()=>{for(const [t,expiry]of sessions)if(expiry<Date.now()){sessions.delete(t);deviceWatches.delete(t);}watchedDeviceIds();for(const[k,a]of attempts)if(a.until<Date.now())attempts.delete(k);for(const[id,download]of draftDownloads)if(download.expires<Date.now()||!sessions.has(download.token))draftDownloads.delete(id);},60000);
  function json(res,status,payload,headers={}) {res.writeHead(status,{'Content-Type':'application/json; charset=utf-8',...headers});res.end(JSON.stringify(payload));}
  function fail(status,message,code) {const e=new Error(message);e.status=status;if(code)e.code=code;throw e;}
  async function body(req) {
    if(!req.headers['content-type']?.startsWith('application/json'))fail(415,'Use a JSON request.');
    let text='';for await(const chunk of req){text+=chunk;if(Buffer.byteLength(text)>1048576)fail(413,'Program exceeds the maximum size.');}
    if(closed)fail(503,'The server is shutting down.');
    if(runtimeMutations.has(new URL(req.url,'http://localhost').pathname))requireRuntimeLease();
    try{return JSON.parse(text);}catch{fail(400,'Invalid JSON.');}
  }
  function tokenFor(req) {return (req.headers.cookie || '').split(';').map(v=>v.trim()).find(v=>v.startsWith('tuya_session='))?.slice(13);}
  function authenticated(req) {const token=tokenFor(req);return token && sessions.get(token)>Date.now();}
  function loginCookie(res) {const token=randomBytes(32).toString('hex');sessions.set(token,Date.now()+12*3600000);res.setHeader('Set-Cookie',`tuya_session=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=43200${publicOrigin?'; Secure':''}`);}
  function normalizeProgram(candidate) {
    const compiled=candidate?.ladder?compileLadder(candidate.ladder,{id:candidate.id,name:candidate.name}):candidate;
    return {...validateProgram(compiled),...(compiled.ladder?{ladder:compiled.ladder}:{})};
  }
  function checkProgram(p,{forRun=false,testRun=false,liveTest=false}={}) {
    validateProgram(p);
    const outputs=new Set();
    for(const n of p.nodes) {
      if(forRun&&!testRun&&!liveTest&&n.type==='VIRTUAL')fail(400,'Virtual inputs require Test Run or Live Test. Replace them with physical inputs before normal Run.');
      if(n.type==='OUTPUT') {
        const key=n.params.deviceId+'\0'+n.params.code;
        if(outputs.has(key))fail(400,'Two outputs cannot write the same device property. Combine their conditions first.');outputs.add(key);
        if(forRun) {
          const device=testRun?testDevice(n.params.deviceId):provider.list().find(d=>d.id===n.params.deviceId);
          if(n.params.mode==='adjust')resolveAdjustment(device,n.params.code,n.params.delta);
          else if(n.params.mode==='value') {
            const property=device?.model.find(p=>p.code===n.params.code);
            if(!device?.online||!property||!['rw','wr'].includes(property.accessMode))fail(400,'Select an online device and a writable output property.');
          }else validateCommand(device,n.params.code,n.params.value);
        }
      }
      if(forRun && n.type==='INPUT') {
        const d=provider.list().find(d=>d.id===n.params.deviceId);
        if(!d?.properties[n.params.code])fail(400,`Input ${n.id} is not mapped to an available device property.`);
      }
    }
    if(forRun && !p.nodes.some(n=>n.type==='OUTPUT'))fail(400,'Add at least one output coil.');
  }
  const server=http.createServer(async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Cache-Control','no-store');res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
    try {
      const url=new URL(req.url,'http://'+req.headers.host);
      if(url.pathname==='/api/health'&&['GET','HEAD'].includes(req.method))return json(res,closed?503:200,{ok:!closed});
      if(closed)fail(503,'The server is shutting down.');
      if(!allowedHosts.has(url.hostname.toLowerCase()))fail(403,'Host not allowed.');
      const local=!hosted&&isLocal(req), route=url.pathname;
      if(!['GET','HEAD'].includes(req.method)) {
        const origin=req.headers.origin,expected=`http://${req.headers.host}`;
        if(hosted?origin!==publicOrigin:(origin!==expected && (!publicOrigin || origin!==publicOrigin)))fail(403,'Request origin does not match the server.');
      }
      if(route==='/api/session'&&req.method==='GET')return json(res,200,{authenticated:!!authenticated(req),setupRequired:!auth,local,hosted});
      if(['/api/setup','/api/login'].includes(route)&&req.method==='POST') {
        if(route==='/api/setup'&&(!local||auth))fail(403,'Initial setup is available only on the server computer before an account exists.');
        const ip=req.socket.remoteAddress,attempt=attempts.get(ip)||{count:0,until:Date.now()+900000};
        if(attempt.until<Date.now()){attempt.count=0;attempt.until=Date.now()+900000;}
        if(++attempt.count>10)fail(429,'Too many attempts. Try again in 15 minutes.');attempts.set(ip,attempt);
        const data=await body(req);
        if(typeof data.password!=='string'||data.password.length<12||data.password.length>200)fail(400,'Password must contain 12–200 characters.');
        if(route==='/api/setup') {
          const salt=randomBytes(16).toString('hex'),hash=(await derive(data.password,salt,64)).toString('hex');
          // Recheck after asynchronous hashing to prevent concurrent setup races.
          if(auth)fail(409,'Account already exists. Please sign in.');
          auth={salt,hash};storage.write('auth',auth);log('info','Application password created.');
        } else {
          if(!auth)fail(409,'Create the application password on the server computer first.');
          const hash=await derive(data.password,auth.salt,64);
          if(!timingSafeEqual(hash,Buffer.from(auth.hash,'hex')))fail(401,'Incorrect password.');
        }
        attempts.delete(ip);loginCookie(res);return json(res,200,{ok:true});
      }
      if(route.startsWith('/api/')) {
        if(!authenticated(req))fail(401,'Please sign in first.');
        if(!['GET','HEAD'].includes(req.method)&&runtimeMutations.has(route)){requireRuntimeLease();if(programSaveBusy)fail(409,'Wait for the program save to finish.');}
        if(route==='/api/logout'&&req.method==='POST'){sessions.delete(tokenFor(req));deviceWatches.delete(tokenFor(req));res.setHeader('Set-Cookie','tuya_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0');return json(res,200,{ok:true});}
        if(route==='/api/state'&&req.method==='GET')return json(res,200,state());
        if(route==='/api/scenes'&&req.method==='GET'){
          if(switchBusy)fail(409,'Wait for the Tuya connection operation to finish before reading scenes.');
          const active=provider,currentMode=mode;
          const result=await sceneReader.read(active,{mode:currentMode,homeId:url.searchParams.has('homeId')?url.searchParams.get('homeId'):undefined,refresh:url.searchParams.get('refresh')==='1'});
          if(!authenticated(req))fail(401,'Please sign in first.');
          if(active!==provider||currentMode!==mode)fail(409,'The Tuya connection changed. Reload the rule lists.');
          return json(res,200,result);
        }
        if(route==='/api/events'&&req.method==='GET'){
          res.writeHead(200,{'Content-Type':'text/event-stream','Connection':'keep-alive','X-Accel-Buffering':'no'});res.write(`event: state\ndata: ${JSON.stringify(state())}\n\n`);
          clients.set(res,{token:tokenFor(req)});req.on('close',()=>clients.delete(res));return;
        }
        if(route==='/api/program'&&req.method==='GET')return json(res,200,program,{'Content-Disposition':'attachment; filename="tuya-program.json"',ETag:`"${programRevision()}"`});
        if(route==='/api/exports'&&req.method==='POST'){
          // Native Android downloads need an authenticated HTTP URL. Retain
          // unfinished drafts briefly in memory without saving or executing them.
          const draft=await body(req);
          if(!draft||typeof draft!=='object'||Array.isArray(draft)||!Array.isArray(draft.nodes)||draft.nodes.length>512)fail(400,'Invalid draft format.');
          if(draft.ladder&&(!Array.isArray(draft.ladder.tags)||draft.ladder.tags.length>512||!Array.isArray(draft.ladder.rungs)||draft.ladder.rungs.length>64))fail(400,'Invalid ladder draft format.');
          const token=tokenFor(req),owned=[...draftDownloads].filter(([,value])=>value.token===token);
          for(const[id]of owned.slice(0,Math.max(0,owned.length-3)))draftDownloads.delete(id);
          while(draftDownloads.size>=16)draftDownloads.delete(draftDownloads.keys().next().value);
          const id=randomBytes(24).toString('hex');
          draftDownloads.set(id,{token,expires:Date.now()+5*60000,content:JSON.stringify(draft,null,2)});
          return json(res,200,{url:`/api/exports/${id}`});
        }
        if(route.startsWith('/api/exports/')&&req.method==='GET'){
          const download=draftDownloads.get(route.slice('/api/exports/'.length));
          if(!download||download.token!==tokenFor(req)||download.expires<Date.now())fail(404,'This draft download has expired. Export it again.');
          res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Content-Disposition':'attachment; filename="tuya-logic-draft.json"'});res.end(download.content);return;
        }
        if(route==='/api/program'&&req.method==='PUT'){
          if(switchBusy||engine.snapshot().running)fail(409,'Stop the program before editing logic.');
          const generation=epoch;
          const candidate=normalizeProgram(await body(req));checkProgram(candidate);
          if(generation!==epoch||switchBusy||engine.snapshot().running)fail(409,'Program state changed. Reload before saving.');
          const expected=req.headers['if-match'];
          if(expected!==undefined&&expected!==programRevision()&&expected!==`"${programRevision()}"`)fail(409,'The program changed on another client. Your draft has not been saved. Export your draft or reload the server version.','PROGRAM_CONFLICT');
          requireRuntimeLease();if(programSaveBusy)fail(409,'Wait for the program save to finish.');programSaveBusy=true;
          try{
            const nextPrograms={...programs,[mode]:candidate};
            await storage.write('programs',nextPrograms);
            requireRuntimeLease();
            resetExecution();engine.setProgram(candidate);program=candidate;programs=nextPrograms;resetOutputFeedback();log('info','Program saved: '+program.name);broadcast();return json(res,200,state());
          }finally{programSaveBusy=false;}
        }
        if(['/api/run','/api/test-run','/api/live-test'].includes(route)&&req.method==='POST'){
          const testRun=route==='/api/test-run',liveTest=route==='/api/live-test';
          if(switchBusy)fail(409,'Wait for the mode change to finish.');
          if(engine.snapshot().running)fail(409,'Program is already running.');
          const generation=epoch,savedProgram=program;
          if(req.headers['content-length']!=='0'&&(req.headers['content-length']||req.headers['transfer-encoding']))await body(req);
          if(generation!==epoch||savedProgram!==program||switchBusy||engine.running)fail(409,'Program state changed. Reload before starting.');
          requireRuntimeLease();if(programSaveBusy)fail(409,'Wait for the program save to finish.');
          if(liveTest&&mode!=='live')fail(409,'Live Test requires a connected live Tuya account.');
          if(!testRun&&mode==='live'&&provider.status!=='connected')fail(409,'Wait for devices and the Tuya event connection to be ready.');
          testOutputs.clear();checkProgram(program,{forRun:true,testRun,liveTest});epoch++;resetOutputFeedback();executionMode=testRun?'test':liveTest?'live-test':'live';engine.start();log('info',`${testRun?'TEST RUN · shadow outputs only':liveTest?'LIVE TEST · physical device commands enabled':'RUN · '+(mode==='demo'?'simulation':'physical devices')} · ${program.name}`);broadcast();return json(res,200,state());
        }
        if(route==='/api/virtual-input'&&req.method==='POST'){
          if(!['test','live-test'].includes(executionMode)||!engine.running||switchBusy)fail(409,'Virtual inputs can be changed only during Test Run or Live Test.');
          const generation=epoch,data=await body(req);
          if(generation!==epoch||!['test','live-test'].includes(executionMode)||!engine.running||switchBusy)fail(409,'Execution changed. Reload before changing a virtual input.');
          if(!data||typeof data.id!=='string'||!['boolean','number'].includes(typeof data.value)||typeof data.value==='number'&&!Number.isFinite(data.value))fail(400,'Provide a virtual input ID and a boolean or finite numeric value.');
          if(!program.nodes.some(n=>n.type==='VIRTUAL'&&n.id===data.id))fail(400,'Unknown virtual input.');
          await engine.setVirtualInput(data.id,data.value);broadcast();return json(res,200,state());
        }
        if(route==='/api/input-force'&&req.method==='POST'){
          if(!['test','live-test'].includes(executionMode)||!engine.running||switchBusy)fail(409,'Start Test Run or Live Test before forcing a physical input.');
          const generation=epoch,runMode=executionMode,active=provider,data=await body(req);
          if(!authenticated(req))fail(401,'Please sign in first.');
          if(generation!==epoch||executionMode!==runMode||!engine.running||switchBusy)fail(409,'Execution changed. Reload before forcing an input.');
          if(!data||typeof data!=='object'||Array.isArray(data)||(data.release!==undefined&&typeof data.release!=='boolean')||data.release===true&&Object.hasOwn(data,'value'))fail(400,'Provide a device, property and value, or release the simulated override.');
          const {deviceId,code,value}=data,release=data.release===true,simulation=runMode==='test';
          if(release&&!simulation)fail(400,'Live Test does not latch an input override. The device retains its actual state.');
          inputForceTarget(deviceId,code,value,{simulation,release});
          const key=outputKey(deviceId,code),input=program.nodes.find(n=>n.type==='INPUT'&&n.params.deviceId===deviceId&&n.params.code===code);
          const identity={...(input?{id:input.id}:{}),deviceId,code};
          if(release){
            if(inputForces.has(key)){inputForces.delete(key);releasedInputForces.add(key);inputForceFeedback.set(key,{...identity,commandState:'idle'});await engine.tick();}
            broadcast();return json(res,200,state());
          }
          if(!inputForceFeedback.has(key)&&inputForceFeedback.size>=512)fail(400,'At most 512 input properties may be forced in one test session.');
          if(simulation){
            inputForces.set(key,{...identity,value,source:'simulated',forced:true});releasedInputForces.delete(key);
            inputForceFeedback.set(key,{...identity,desiredValue:value,commandState:'simulated',commandedAt:Date.now()});
            await engine.tick();broadcast();return json(res,200,state());
          }
          const existing=inputForceJobs.get(key),previous=inputForceFeedback.get(key);
          if(existing&&previous===existing.record&&previous.desiredValue===value){await existing.promise;return json(res,200,state());}
          if(previous?.commandState==='confirmed'&&previous.desiredValue===value&&active.readInput(deviceId,code).value===value)return json(res,200,state());
          const record={...identity,desiredValue:value,commandState:'pending',commandedAt:Date.now()};
          inputForceFeedback.set(key,record);broadcast();
          const sameRequest=()=>hasRuntimeLease()&&generation===epoch&&active===provider&&executionMode==='live-test'&&engine.running&&inputForceFeedback.get(key)===record;
          let invalidReason;
          const shouldSend=()=>{
            if(!sameRequest()||!authenticated(req))return false;
            try{inputForceTarget(deviceId,code,value);return true;}catch(error){invalidReason=safeError(error);return false;}
          };
          const job={record};
          job.promise=(async()=>{
            try{
              const result=await active.issue(deviceId,code,value,{shouldSend});
              if(!sameRequest())fail(409,'The input command was cancelled because execution changed.');
              const sample=active.readInput(deviceId,code);
              if(result?.confirmed!==true||sample?.valid!==true||sample.value!==value)throw new Error('The forced input device state is not confirmed. Check actual device feedback.');
              Object.assign(record,{commandState:'confirmed',confirmedAt:Date.now()});
              log('success',`LIVE TEST input ${deviceId} / ${code} confirmed: ${JSON.stringify(value)}.`);
              void engine.tick().then(broadcast);broadcast();
            }catch(error){
              if(sameRequest()){
                if(!authenticated(req))record.commandState='cancelled';
                else{Object.assign(record,{commandState:'failed',commandError:invalidReason||safeError(error)});engine.fault(new Error('Input force failed: '+record.commandError));}
                broadcast();
              }
              throw error;
            }finally{if(inputForceJobs.get(key)===job)inputForceJobs.delete(key);}
          })();
          inputForceJobs.set(key,job);await job.promise;return json(res,200,state());
        }
        if(route==='/api/stop'&&req.method==='POST'){stop();return json(res,200,state());}
        if(route==='/api/demo'&&req.method==='POST'){
          if(mode!=='demo'||switchBusy)fail(409,'Simulation controls are available only in demo mode.');
          const data=await body(req);if(mode!=='demo'||switchBusy)fail(409,'Mode changed. Reload the page.');
          provider.update(data);broadcast();return json(res,200,state());
        }
        if(route==='/api/control'&&req.method==='POST'){
          if(switchBusy||engine.snapshot().running)fail(409,'Stop the program before manual control.');
          const data=await body(req),active=provider,generation=epoch;
          if(switchBusy||engine.snapshot().running)fail(409,'Stop the program before manual control.');
          requireRuntimeLease();
          await active.issue(data.deviceId,data.code,data.value,{shouldSend:()=>hasRuntimeLease()&&active===provider&&generation===epoch&&!engine.snapshot().running});
          log('success',`Manual control ${data.deviceId} / ${data.code} confirmed.`);broadcast();return json(res,200,state());
        }
        if(route==='/api/devices/refresh'&&req.method==='POST'){
          if(refreshBusy||switchBusy||polling||refreshJobs.size)fail(409,'Device refresh is still in progress.');
          refreshBusy=true;try{if(mode==='live'){await provider.discover();if(provider.status==='disconnected'&&!provider.reconnect)provider.connect();}broadcast();return json(res,200,state());}finally{refreshBusy=false;}
        }
        if(route==='/api/devices/watch'&&req.method==='POST'){
          if(switchBusy||refreshBusy)fail(409,'Wait for the device connection operation to finish.');
          const active=provider,data=await body(req),token=tokenFor(req);
          if(!authenticated(req))fail(401,'Please sign in first.');
          if(active!==provider||switchBusy||refreshBusy)fail(409,'Devices changed. Reload before watching devices.');
          if(!data||!Array.isArray(data.deviceIds)||data.deviceIds.length>32||data.deviceIds.some(id=>typeof id!=='string'||!id||id.length>200))fail(400,'Watch up to 32 known device IDs.');
          const devices=new Map(provider.list().map(d=>[d.id,d]));
          if(data.deviceIds.some(id=>!devices.has(id)))fail(400,'A watched device is not available in this account.');
          const previous=deviceWatches.get(token),ids=new Set(data.deviceIds);
          deviceWatches.set(token,{ids,expires:Date.now()+120000});
          const needed=[...ids].filter(id=>!previous?.ids.has(id)||Object.values(devices.get(id).properties||{}).some(p=>p.valid!==true));
          await Promise.all(needed.filter(id=>refreshJobs.has(id)||Date.now()-(lastWatchRefresh.get(id)??-Infinity)>=15000).map(refreshDevice));
          return json(res,200,state());
        }
        if(route==='/api/settings'&&req.method==='POST'){
          if(hosted)fail(403,'Hosted credentials and connection mode are managed through server environment secrets.');
          if(!local)fail(403,'Configure the account and API Key through localhost on the server computer.');
          if(switchBusy||refreshBusy||polling||refreshJobs.size)fail(409,'Wait for the connection operation to finish.');
          const generation=epoch;
          const data=await body(req);
          if(generation!==epoch||switchBusy||refreshBusy||polling||refreshJobs.size)fail(409,'Server state changed. Retry after the previous operation finishes.');
          if(!['demo','live'].includes(data.mode))fail(400,'Choose demo or live mode.');
          switchBusy=true;
          try {
            if(data.apiKey){if(typeof data.apiKey!=='string')fail(400,'Invalid API Key.');const candidate=new TuyaClient(data.apiKey.trim());try{await candidate.request('/v1.0/end-user/homes/all');}finally{candidate.close();}storage.saveKey(data.apiKey.trim());apiKey=data.apiKey.trim();}
            if(data.mode==='live'&&!apiKey)fail(400,'Enter a Tuya.AI API Key first.');
            stop('Program stopped to change the connection.');await activate(data.mode);storage.write('settings',{mode});log('info','Mode changed to '+mode);broadcast();return json(res,200,state());
          }finally{switchBusy=false;}
        }
        fail(404,'Endpoint not found.');
      }
      if(!['GET','HEAD'].includes(req.method))fail(405,'Method not allowed.');
      const staticFiles={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/ladder.js':'ladder.js','/ladder-ui.js':'ladder-ui.js','/property-labels.js':'property-labels.js','/styles.css':'styles.css','/icon.svg':'icon.svg'};
      const name=staticFiles[route];if(!name)fail(404,'Page not found.');
      const file=path.join(root,'public',name);if(!fs.existsSync(file))fail(503,'The application interface is not available yet.');
      const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml'};
      res.writeHead(200,{'Content-Type':types[path.extname(file)]});if(req.method==='HEAD')res.end();else fs.createReadStream(file).pipe(res);
    }catch(e){if(!res.headersSent)json(res,e.status || 400,{error:safeError(e),...(e.code==='PROGRAM_CONFLICT'?{code:e.code}: {})});else res.end();}
  });
  server.requestTimeout=15000;server.headersTimeout=10000;
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,()=>{actualPort=server.address().port;resolve();});});
  log('info','Server started. The program always starts in STOP after a restart.');
  return {server,state,storage,engine,port:actualPort,close(){
    if(closePromise)return closePromise;
    // Cancel queued sends before releasing sockets or persisting final logs.
    closed=true;epoch++;resetExecution();engine.stop();provider?.close();
    for(const t of[ticks,updates,poll,cleanup])clearInterval(t);clearTimeout(saveLogsTimer);
    closePromise=(async()=>{
      let storageError;try{if(!remoteStorage||storage.canWrite())await storage.write('logs',logs);}catch(error){storageError=error;}
      if(remoteStorage)await storage.close();
      for(const res of clients.keys())res.end();clients.clear();sessions.clear();
      server.closeAllConnections();await new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve()));
      if(storageError)throw storageError;
    })();return closePromise;
  }};
}
if(process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const app=await createApp();
  console.log(`Tuya Logic ready: ${app.state().server.urls[0]}\nMode: ${app.state().mode}. Program: STOP.`);
  let stopping=false;
  for(const signal of['SIGINT','SIGTERM'])process.on(signal,()=>{if(stopping)return;stopping=true;app.close().then(()=>process.exit(0),()=>{console.error('The server stopped, but its final log could not be saved.');process.exit(1);});});
}
