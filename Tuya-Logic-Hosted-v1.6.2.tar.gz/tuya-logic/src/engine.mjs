// Deterministic PLC scan engine. Device I/O and data freshness are supplied by the server.
const TYPES = new Set(['INPUT', 'VIRTUAL', 'CONST', 'GT', 'GTE', 'LT', 'LTE', 'EQ', 'NEQ', 'AND', 'OR', 'NOT', 'XOR', 'NAND', 'NOR', 'TON', 'TOF', 'PULSE', 'TONR', 'BLINK', 'R_TRIG', 'F_TRIG', 'LATCH', 'SR', 'COUNTER', 'CTD', 'CTUD', 'ADD', 'SUB', 'MUL', 'DIV', 'MOD', 'ABS', 'MIN', 'MAX', 'CLAMP', 'SELECT', 'OUTPUT']);
const NUMERIC = new Set(['GT', 'GTE', 'LT', 'LTE']);
const MATH = new Set(['ADD', 'SUB', 'MUL', 'DIV', 'MOD', 'ABS', 'MIN', 'MAX', 'CLAMP']);
const TIMERS = new Set(['TON', 'TOF', 'PULSE', 'TONR', 'BLINK']);
const COUNTERS = new Set(['COUNTER', 'CTD', 'CTUD']);
const MANY_INPUTS = new Set(['AND', 'OR', 'XOR', 'NAND', 'NOR', 'MIN', 'MAX']);
const ARITY = { INPUT: 0, VIRTUAL: 0, CONST: 0, NOT: 1, ABS: 1, R_TRIG: 1, F_TRIG: 1, TON: 1, TOF: 1, PULSE: 1, BLINK: 1, CTUD: 3, CLAMP: 3, SELECT: 3 };
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const finite = value => typeof value === 'number' && Number.isFinite(value);
const primitive = value => typeof value === 'boolean' || typeof value === 'string' || finite(value);
const bool = value => typeof value === 'boolean';
const text = (value, field, max = 200) => {
  if (typeof value !== 'string' || !value.trim() || value.length > max) throw new Error(`${field} must contain 1–${max} characters.`);
  return value;
};

/** Validate and copy a graph, returning nodes in dependency order. Never executes code. */
export function validateProgram(input) {
  if (!plain(input) || !Array.isArray(input.nodes) || input.nodes.length > 512) throw new Error('A program must contain an array of at most 512 blocks.');
  const nodes = input.nodes.map(raw => {
    if (!plain(raw)) throw new Error('Invalid block.');
    const id = text(raw.id, 'Block ID', 80);
    if (!TYPES.has(raw.type)) throw new Error(`Unknown block type for ${id}.`);
    if (raw.inputs !== undefined && !Array.isArray(raw.inputs)) throw new Error(`Inputs for ${id} must be an array of block IDs.`);
    const inputs = (raw.inputs ?? []).map(ref => text(ref, 'Input reference', 80));
    const expected = raw.type === 'OUTPUT' ? (raw.params?.mode === 'value' ? 2 : 1) : (ARITY[raw.type] ?? 2);
    if (MANY_INPUTS.has(raw.type) ? inputs.length < 2 || inputs.length > 100 : inputs.length !== expected) throw new Error(`Incorrect input count for ${id} (${raw.type}).`);
    if (raw.params !== undefined && !plain(raw.params)) throw new Error(`Invalid parameters for ${id}.`);
    const source = raw.params ?? {};
    const params = {};
    if (raw.type === 'VIRTUAL') {
      params.defaultValue = source.defaultValue ?? false;
      if (source.defaultValue === null || params.defaultValue !== false && !finite(params.defaultValue)) throw new Error(`Virtual input ${id} must default to FALSE or a finite number.`);
      if (source.unit !== undefined) {
        if (typeof source.unit !== 'string' || source.unit.length > 16) throw new Error(`Virtual input unit for ${id} must be text of at most 16 characters.`);
        params.unit = source.unit;
      }
    }
    if (['INPUT', 'OUTPUT'].includes(raw.type)) {
      params.deviceId = text(source.deviceId, `Device for ${id}`);
      params.code = text(source.code, `Property code for ${id}`);
    }
    if (raw.type === 'INPUT') {
      params.scale = source.scale ?? 1;
      params.offset = source.offset ?? 0;
      if (!finite(params.scale) || !finite(params.offset)) throw new Error(`Scale and offset for ${id} must be finite numbers.`);
    }
    if (raw.type === 'OUTPUT') {
      params.mode = source.mode ?? 'trigger';
      if (!['trigger', 'follow', 'pulse', 'value', 'adjust'].includes(params.mode)) throw new Error(`Output mode for ${id} must be trigger, follow, pulse, value, or adjust.`);
      if (params.mode === 'adjust') {
        if (!finite(source.delta) || source.delta === 0) throw new Error(`Adjustment for ${id} must be a finite nonzero number.`);
        params.delta = source.delta;
      }
      if (params.mode === 'pulse') {
        if (typeof source.value !== 'boolean') throw new Error(`Active pulse value for ${id} must be boolean ON/OFF.`);
        if (!Number.isSafeInteger(source.durationMs) || source.durationMs < 100 || source.durationMs > 86400000) throw new Error(`Pulse duration for ${id} must be an integer from 100 to 86400000 milliseconds.`);
        params.durationMs = source.durationMs;
      }
    }
    if (['CONST', 'OUTPUT'].includes(raw.type)) {
      const value = ['follow', 'value', 'adjust'].includes(params.mode) ? false : source.value;
      if (!primitive(value) || (typeof value === 'string' && value.length > 2000)) throw new Error(`Value for ${id} must be a boolean, finite number, or string of at most 2000 characters.`);
      params.value = value;
    }
    if (TIMERS.has(raw.type) && raw.type !== 'BLINK') {
      if (!Number.isSafeInteger(source.durationMs) || source.durationMs < 0) throw new Error(`Duration for ${id} must be an integer number of milliseconds >= 0.`);
      params.durationMs = source.durationMs;
    }
    if (raw.type === 'BLINK') {
      for (const field of ['onMs', 'offMs']) {
        if (!Number.isSafeInteger(source[field]) || source[field] < 100) throw new Error(`${field} for ${id} must be an integer >= 100 milliseconds.`);
        params[field] = source[field];
      }
      if (!Number.isSafeInteger(params.onMs + params.offMs)) throw new Error(`Combined blink period for ${id} is too large.`);
    }
    if (COUNTERS.has(raw.type)) {
      if (!Number.isSafeInteger(source.preset) || source.preset < 1) throw new Error(`Preset for ${id} must be an integer >= 1.`);
      params.preset = source.preset;
    }
    const node = { id, type: raw.type, label: raw.label === undefined ? raw.type : text(raw.label, `Label for ${id}`), inputs, params };
    for (const axis of ['x', 'y']) {
      if (raw[axis] !== undefined) {
        if (!finite(raw[axis])) throw new Error(`Invalid position for ${id}.`);
        node[axis] = raw[axis];
      }
    }
    return node;
  });
  const byId = new Map();
  for (const node of nodes) {
    if (byId.has(node.id)) throw new Error(`Duplicate block ID: ${node.id}.`);
    byId.set(node.id, node);
  }
  const order = [], active = new Set(), visited = new Set();
  const visit = node => {
    if (visited.has(node.id)) return;
    if (active.has(node.id)) throw new Error(`Cycle detected at ${node.id}; use memory blocks for internal state.`);
    active.add(node.id);
    for (const id of node.inputs) {
      if (!byId.has(id)) throw new Error(`Input ${id} for ${node.id} does not exist.`);
      visit(byId.get(id));
    }
    active.delete(node.id); visited.add(node.id); order.push(node);
  };
  nodes.forEach(visit);
  // Known types catch wiring mistakes before RUN. INPUT types are checked on every scan.
  const known = new Map();
  for (const node of order) {
    const inputTypes = node.inputs.map(id => known.get(id));
    const requireType = (types, expected) => { if (types.some(type => type !== 'unknown' && type !== expected)) throw new Error(`${node.id} requires ${expected} inputs.`); };
    const requireSame = types => { const knownTypes = types.filter(type => type !== 'unknown'); if (new Set(knownTypes).size > 1) throw new Error(`${node.id} requires matching input types.`); };
    let outputType = 'boolean';
    if (node.type === 'INPUT') outputType = 'unknown';
    else if (node.type === 'VIRTUAL') outputType = typeof node.params.defaultValue;
    else if (node.type === 'CONST') outputType = typeof node.params.value;
    else if (NUMERIC.has(node.type) || MATH.has(node.type)) { requireType(inputTypes, 'number'); if (MATH.has(node.type)) outputType = 'number'; }
    else if (['EQ', 'NEQ'].includes(node.type)) requireSame(inputTypes);
    else if (node.type === 'SELECT') {
      requireType([inputTypes[0]], 'boolean'); requireSame(inputTypes.slice(1));
      outputType = inputTypes[1] === inputTypes[2] ? inputTypes[1] : 'unknown';
    } else if (node.type === 'OUTPUT' && node.params.mode === 'value') { requireType([inputTypes[0]], 'boolean'); outputType = inputTypes[1]; }
    else requireType(inputTypes, 'boolean');
    known.set(node.id, outputType);
  }
  return { id: input.id === undefined ? 'program' : text(input.id, 'Program ID', 80), name: input.name === undefined ? 'Tuya Program' : text(input.name, 'Program name'), nodes: order };
}

function emptyState(node, error) {
  return { id: node.id, value: null, valid: false, ...(TIMERS.has(node.type) || node.type === 'OUTPUT' && node.params.mode === 'pulse' ? { elapsedMs: 0 } : {}), ...(COUNTERS.has(node.type) ? { count: node.type === 'CTD' ? node.params.preset : 0 } : {}), ...(node.type === 'OUTPUT' && node.params.mode === 'value' ? { enabled: false } : {}), ...(error ? { error } : {}) };
}

export class Engine {
  constructor({ readInput, writeOutput, onLog = () => {}, now = () => performance.now() } = {}) {
    if (typeof readInput !== 'function' || typeof writeOutput !== 'function' || typeof now !== 'function' || typeof onLog !== 'function') throw new Error('Invalid engine I/O adapter.');
    this.readInput = readInput; this.writeOutput = writeOutput; this.onLog = onLog; this.now = now;
    this.program = null; this.running = false; this.error = null;
    this.states = new Map(); this.memory = new Map(); this.generation = 0; this.lastTime = null;
    this.outputs = new Map(); this.queue = new Map(); this.draining = false; this.scanning = false; this.scanIndex = 0;
    this.virtualInputs = new Map();
  }

  log(level, message, extra) { try { this.onLog(level, message, extra); } catch { /* Logging must never change control state. */ } }

  reset() {
    this.states = new Map((this.program?.nodes ?? []).map(node => [node.id, emptyState(node)]));
    this.memory = new Map(); this.lastTime = null; this.scanIndex = 0;
    this.virtualInputs = new Map((this.program?.nodes ?? []).filter(node => node.type === 'VIRTUAL').map(node => [node.id, node.params.defaultValue]));
    this.outputs = new Map();
    for (const action of this.queue.values()) action.resolve();
    this.queue.clear();
  }

  setProgram(program) {
    if (this.running) throw new Error('STOP the program before changing blocks.');
    const validated = validateProgram(program);
    for (const node of validated.nodes) { Object.freeze(node.inputs); Object.freeze(node.params); Object.freeze(node); }
    Object.freeze(validated.nodes); this.program = Object.freeze(validated);
    this.generation++; this.error = null; this.reset();
    return this.snapshot();
  }

  start() {
    if (!this.program) throw new Error('No program has been loaded.');
    if (this.running) return this.snapshot();
    this.generation++; this.error = null; this.reset(); this.running = true;
    this.log('info', 'Program RUN', { programId: this.program.id });
    return this.snapshot();
  }

  stop() {
    const wasRunning = this.running;
    this.generation++; this.running = false; this.error = null; this.reset();
    if (wasRunning) this.log('info', 'Program STOP; device outputs retain their last physical state.');
    return this.snapshot();
  }

  fault(error) {
    this.stop(); this.error = String(error?.message ?? error);
    this.log('error', this.error);
  }

  snapshot() {
    return { running: this.running, nodes: [...this.states.values()].map(state => ({ ...state })), virtualInputs: (this.program?.nodes ?? []).filter(node => node.type === 'VIRTUAL').map(node => ({ id: node.id, label: node.label, value: this.virtualInputs.get(node.id) })), ...(this.error ? { error: this.error } : {}) };
  }

  setVirtualInput(id, value) {
    if (!this.running) throw new Error('Start Test Run or Live Test before changing a virtual input.');
    if (!this.virtualInputs.has(id)) throw new Error('Unknown virtual input.');
    const expected = typeof this.program.nodes.find(node => node.id === id).params.defaultValue;
    if (typeof value !== expected || expected === 'number' && !finite(value)) throw new Error(`Virtual input value must be ${expected === 'number' ? 'a finite number' : 'boolean'}.`);
    this.virtualInputs.set(id, value);
    // Apply the input event immediately, even while an asynchronous output is
    // pending, so a brief FALSE reliably resets timers and queued commands.
    return this.tick();
  }

  tick() {
    if (!this.running) return Promise.resolve(this.snapshot());
    // Scans are synchronous and never wait for the cloud. Awaiting this return
    // value waits only for newly queued actions; subsequent ticks still scan.
    this.scanIndex++;
    const actions = this.scan(this.generation);
    this.ensureDispatch();
    return Promise.all(actions.map(action => action.done)).then(() => this.snapshot());
  }

  scan(generation) {
    if (this.scanning) return [];
    this.scanning = true;
    try { return this.evaluateGraph(generation); }
    finally { this.scanning = false; }
  }

  cancelQueued(id) {
    const action = this.queue.get(id);
    if (action) { this.queue.delete(id); action.resolve(); }
  }

  queueOutput(node, value, generation) {
    let episode = this.outputs.get(node.id);
    if (!episode || episode.value !== value) {
      this.cancelQueued(node.id);
      episode = { value, completed: false, action: null };
      this.outputs.set(node.id, episode);
    }
    if ((['trigger', 'adjust'].includes(node.params.mode) && !value) || episode.completed || episode.action) return null;
    let resolve;
    const done = new Promise(r => { resolve = r; });
    const commandValue = ['follow', 'value'].includes(node.params.mode) ? value : node.params.mode === 'pulse' ? (value ? node.params.value : !node.params.value) : node.params.value;
    const action = { node, episode, generation, commandValue, done, resolve };
    episode.action = action; this.queue.set(node.id, action);
    return action;
  }

  isCurrent(action) {
    return this.running && action.generation === this.generation && this.outputs.get(action.node.id) === action.episode;
  }

  canSend(action) {
    if (!this.isCurrent(action)) return false;
    // The adapter invokes this again immediately before its network send. A
    // fresh scan cancels an obsolete coil/trigger even while that adapter was
    // waiting behind rate-limited API reads.
    this.scan(this.generation);
    this.ensureDispatch();
    return this.isCurrent(action);
  }

  ensureDispatch() {
    if (this.draining || !this.queue.size) return;
    this.draining = true;
    Promise.resolve().then(() => this.drain()).catch(error => this.fault(error)).finally(() => {
      this.draining = false;
      if (this.queue.size) this.ensureDispatch();
    });
  }

  async drain() {
    while (this.queue.size) {
      const [id, action] = this.queue.entries().next().value;
      this.queue.delete(id);
      try {
        if (!this.canSend(action)) continue;
        const { node, commandValue } = action;
        await this.writeOutput(node.params.deviceId, node.params.code, commandValue, { nodeId: node.id, shouldSend: () => this.canSend(action), ...(node.params.mode === 'adjust' ? { adjustDelta: node.params.delta } : {}) });
        if (this.isCurrent(action)) {
          action.episode.completed = true;
          this.log('info', 'Output command completed.', { nodeId: node.id, deviceId: node.params.deviceId, code: node.params.code, value: commandValue });
        }
      } catch (error) {
        if (this.isCurrent(action)) this.fault(new Error(`Output ${action.node.id} failed: ${error?.message ?? error}`));
      } finally {
        if (action.episode.action === action) action.episode.action = null;
        action.resolve();
      }
    }
  }

  evaluateGraph(generation) {
    if (!this.running || generation !== this.generation) return [];
    let time;
    try { time = this.now(); } catch (error) { this.fault(error); return []; }
    if (!finite(time) || (this.lastTime !== null && time < this.lastTime)) { this.fault(new Error('Invalid monotonic engine clock.')); return []; }
    this.lastTime = time;
    const actions = [];
    for (const node of this.program.nodes) {
      if (!this.running || generation !== this.generation) break;
      const upstream = node.inputs.map(id => this.states.get(id));
      const invalidate = reason => {
        this.memory.delete(node.id); this.states.set(node.id, emptyState(node, reason));
        if (node.type === 'OUTPUT') { this.outputs.delete(node.id); this.cancelQueued(node.id); }
      };
      if (upstream.some(state => !state.valid)) { invalidate('Input is invalid or stale.'); continue; }
      const values = upstream.map(state => state.value);
      let memory = this.memory.get(node.id) ?? {};
      let value, elapsedMs, count, enabled;
      try {
        if (node.type === 'INPUT') {
          const input = this.readInput(node.params.deviceId, node.params.code);
          if (!input || input.valid !== true || !primitive(input.value)) { invalidate(input?.reason ?? 'Input data is not available.'); continue; }
          value = input.value;
          if (typeof value === 'number') value = value * node.params.scale + node.params.offset;
          else if (node.params.scale !== 1 || node.params.offset !== 0) { invalidate('Scaling requires a numeric input.'); continue; }
          if (!primitive(value)) { invalidate('Scaled value is not finite.'); continue; }
        } else if (node.type === 'VIRTUAL') value = this.virtualInputs.get(node.id);
        else if (node.type === 'CONST') value = node.params.value;
        else if (NUMERIC.has(node.type)) {
          if (!values.every(finite)) { invalidate('Comparison inputs must be finite numbers.'); continue; }
          value = node.type === 'GT' ? values[0] > values[1] : node.type === 'GTE' ? values[0] >= values[1] : node.type === 'LT' ? values[0] < values[1] : values[0] <= values[1];
        } else if (MATH.has(node.type)) {
          if (!values.every(finite)) { invalidate('Arithmetic inputs must be finite numbers.'); continue; }
          if (['DIV', 'MOD'].includes(node.type) && values[1] === 0) { invalidate('Division or modulo by zero.'); continue; }
          if (node.type === 'CLAMP' && values[1] > values[2]) { invalidate('Clamp minimum must not exceed maximum.'); continue; }
          switch (node.type) {
            case 'ADD': value = values[0] + values[1]; break;
            case 'SUB': value = values[0] - values[1]; break;
            case 'MUL': value = values[0] * values[1]; break;
            case 'DIV': value = values[0] / values[1]; break;
            case 'MOD': value = values[0] % values[1]; break;
            case 'ABS': value = Math.abs(values[0]); break;
            case 'MIN': value = Math.min(...values); break;
            case 'MAX': value = Math.max(...values); break;
            case 'CLAMP': value = Math.max(values[1], Math.min(values[2], values[0])); break;
          }
          if (!finite(value)) { invalidate('Arithmetic result is not finite.'); continue; }
        } else if (['EQ', 'NEQ'].includes(node.type)) {
          if (!values.every(primitive) || typeof values[0] !== typeof values[1]) { invalidate('Equality comparison requires matching primitive types.'); continue; }
          value = node.type === 'EQ' ? values[0] === values[1] : values[0] !== values[1];
        } else if (node.type === 'SELECT') {
          if (!bool(values[0]) || !primitive(values[1]) || !primitive(values[2]) || typeof values[1] !== typeof values[2]) { invalidate('SELECT requires a boolean condition and two matching primitive types.'); continue; }
          value = values[0] ? values[1] : values[2];
        } else if (node.type === 'OUTPUT' && node.params.mode === 'value') {
          if (!bool(values[0]) || !primitive(values[1])) { invalidate('Value output requires a boolean enable and a primitive source.'); continue; }
          enabled = values[0]; value = values[1];
          if (!enabled) { this.outputs.delete(node.id); this.cancelQueued(node.id); }
          else { const action = this.queueOutput(node, value, generation); if (action) actions.push(action); }
        } else {
          if (!values.every(bool)) { invalidate('Block inputs must be boolean.'); continue; }
          const input = values[0];
          if (node.type === 'AND') value = values.every(Boolean);
          else if (node.type === 'OR') value = values.some(Boolean);
          else if (node.type === 'NOT') value = !input;
          else if (node.type === 'XOR') value = values.filter(Boolean).length % 2 === 1;
          else if (node.type === 'NAND') value = !values.every(Boolean);
          else if (node.type === 'NOR') value = !values.some(Boolean);
          else if (['R_TRIG', 'F_TRIG'].includes(node.type)) {
            const edge = node.type === 'R_TRIG' ? input && !memory.previous : !input && memory.previous === true;
            if (edge) memory.pulseFrame = this.scanIndex;
            memory.previous = input;
            // Adapter guards may resample within a scan; retain the edge for
            // that frame so the guard cannot consume its own trigger pulse.
            value = memory.pulseFrame === this.scanIndex;
          }
          else if (node.type === 'TON') {
            if (!input) memory = {};
            else if (memory.started === undefined) memory.started = time;
            elapsedMs = input ? Math.min(node.params.durationMs, time - memory.started) : 0;
            value = input && elapsedMs >= node.params.durationMs;
          } else if (node.type === 'TOF') {
            if (input) { memory.energized = true; delete memory.started; elapsedMs = 0; value = true; }
            else if (memory.energized) {
              if (memory.started === undefined) memory.started = time;
              elapsedMs = Math.min(node.params.durationMs, time - memory.started);
              value = elapsedMs < node.params.durationMs;
              if (!value) memory.energized = false;
            } else { value = false; elapsedMs = memory.started === undefined ? 0 : node.params.durationMs; }
          } else if (node.type === 'PULSE') {
            const rising = input && !memory.previous;
            const wasActive = memory.started !== undefined && time - memory.started < node.params.durationMs;
            if (rising && !wasActive) memory.started = time;
            memory.previous = input;
            elapsedMs = memory.started === undefined ? 0 : Math.min(node.params.durationMs, time - memory.started);
            value = memory.started !== undefined && elapsedMs < node.params.durationMs;
          } else if (node.type === 'TONR') {
            if (values[1]) memory = { elapsed: 0, previousEnabled: false, lastSample: time, hasRun: false };
            else {
              memory.elapsed ??= 0;
              if (input && memory.previousEnabled && memory.lastSample !== undefined) memory.elapsed = Math.min(node.params.durationMs, memory.elapsed + time - memory.lastSample);
              if (input) memory.hasRun = true;
              memory.previousEnabled = input; memory.lastSample = time;
            }
            elapsedMs = memory.elapsed;
            value = !values[1] && !!memory.hasRun && elapsedMs >= node.params.durationMs;
          } else if (node.type === 'BLINK') {
            if (!input) memory = {};
            else if (memory.started === undefined) memory.started = time;
            elapsedMs = input ? (time - memory.started) % (node.params.onMs + node.params.offMs) : 0;
            value = input && elapsedMs < node.params.onMs;
          } else if (['LATCH', 'SR'].includes(node.type)) {
            memory.latched = node.type === 'SR' ? (input ? true : values[1] ? false : (memory.latched ?? false)) : (values[1] ? false : input ? true : (memory.latched ?? false));
            value = memory.latched;
          } else if (node.type === 'COUNTER') {
            memory.count ??= 0;
            if (values[1]) memory.count = 0;
            else if (input && !memory.previous) memory.count = Math.min(Number.MAX_SAFE_INTEGER, memory.count + 1);
            memory.previous = input; count = memory.count; value = count >= node.params.preset;
          } else if (node.type === 'CTD') {
            memory.count ??= node.params.preset;
            if (values[1]) memory.count = node.params.preset;
            else if (input && !memory.previous) memory.count = Math.max(0, memory.count - 1);
            memory.previous = input; count = memory.count; value = count <= 0;
          } else if (node.type === 'CTUD') {
            memory.count ??= 0;
            const up = input && !memory.previousUp, down = values[1] && !memory.previousDown;
            if (values[2]) memory.count = 0;
            else if (up !== down) memory.count = Math.max(0, Math.min(Number.MAX_SAFE_INTEGER, memory.count + (up ? 1 : -1)));
            memory.previousUp = input; memory.previousDown = values[1]; count = memory.count; value = count >= node.params.preset;
          } else if (node.type === 'OUTPUT') {
            value = input;
            if (node.params.mode === 'pulse') {
              const rising = input && !memory.previous;
              const wasActive = memory.started !== undefined && time - memory.started < node.params.durationMs;
              if (rising && !wasActive) memory.started = time;
              memory.previous = input;
              elapsedMs = memory.started === undefined ? 0 : Math.min(node.params.durationMs, time - memory.started);
              value = memory.started !== undefined && elapsedMs < node.params.durationMs;
            }
            const action = this.queueOutput(node, value, generation);
            if (action) actions.push(action);
          }
        }
      } catch (error) { invalidate(`Input evaluation failed: ${error?.message ?? error}`); continue; }
      this.memory.set(node.id, memory);
      this.states.set(node.id, { id: node.id, value, valid: true, ...(elapsedMs === undefined ? {} : { elapsedMs }), ...(count === undefined ? {} : { count }), ...(enabled === undefined ? {} : { enabled }) });
    }
    return actions;
  }
}
