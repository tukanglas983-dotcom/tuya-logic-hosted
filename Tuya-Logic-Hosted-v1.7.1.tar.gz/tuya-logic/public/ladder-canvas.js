import {networkPorts,validateNetwork,compileNetwork} from './ladder-network.js';
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const copy=value=>JSON.parse(JSON.stringify(value));
const $=(selector,root)=>root.querySelector(selector);
const $$=(selector,root)=>[...root.querySelectorAll(selector)];
const snap=value=>Math.max(0,Math.min(9000,Math.round(value/10)*10));
const equal=(a,b)=>a?.nodeId===b?.nodeId&&a?.port===b?.port;
const svg=(name,attributes={})=>{const el=document.createElementNS('http://www.w3.org/2000/svg',name);for(const[k,v]of Object.entries(attributes))el.setAttribute(k,String(v));return el;};
export function clearNetworkBinding(node,port){
  if(node.bindings)delete node.bindings[port];
  if(port.startsWith('operand')){node.operands ||= [];node.operands[Number(port.slice(7))]=null;}
  else if(port==='reset')delete node.resetTagId;
  else if(port==='down')delete node.downTagId;
  else if(port==='value'&&node.nodeType==='coil')delete node.source;
  else if(port==='value'&&node.nodeType==='contact'){delete node.value;delete node.valueTagId;}
}
function networkId(rung,base='wire'){
  const used=new Set([...rung.nodes,...rung.edges].map(item=>item.id));
  const stem=String(base).replace(/[^A-Za-z0-9_-]/g,'').replace(/^[^A-Za-z]+/,'').slice(0,20)||'wire';let id=stem,index=1;
  while(used.has(id))id=stem+'_'+index++;return id;
}
function addAutomaticJunction(rung,{id,position,target}={}){
  const point=target&&pointFor(rung,target),node={id:networkId(rung,id||'join'),nodeType:'junction',automatic:true,position:position?copy(position):{x:Math.max(0,(point?.x??200)-110),y:Math.max(0,(point?.y??100)-29)}};
  rung.nodes.push(node);return node;
}
export function connectNetworkPorts(ladder,rungId,from,to,{id,replaceId,junctionId,position,waypoints}={}){
  const candidate=copy(ladder),rung=candidate.rungs.find(r=>r.id===rungId);if(!rung)throw new Error('The rung is no longer available.');
  const source=rung.nodes.find(n=>n.id===from.nodeId),target=rung.nodes.find(n=>n.id===to.nodeId),out=source&&networkPorts(source).find(p=>p.id===from.port),input=target&&networkPorts(target).find(p=>p.id===to.port);
  if(!out||!input||out.direction!=='out'||input.direction!=='in')throw new Error('Connect an output port to an input port.');
  if(out.kind!==input.kind)throw new Error('Power wires and value wires use different ports.');
  if(from.nodeId===to.nodeId)throw new Error('A node cannot connect to itself.');
  if(waypoints!==undefined&&(!Array.isArray(waypoints)||waypoints.length>32))throw new Error('A new wire route supports at most 32 corners.');
  const previous=rung.edges.find(e=>e.id===replaceId);
  rung.edges=rung.edges.filter(e=>e.id!==replaceId);
  if(rung.edges.some(e=>equal(e.from,from)&&equal(e.to,to)))throw new Error('These ports are already connected.');
  const incoming=rung.edges.filter(e=>equal(e.to,to));let destination=copy(to);
  if(input.kind==='power'&&!replaceId&&input.multiple!==true&&incoming.length){
    const upstream=rung.nodes.find(n=>n.id===incoming[0].from.nodeId);
    // Reuse only a private merge point: adding a branch must not energize other downstream paths.
    const reusable=upstream?.nodeType==='junction'&&rung.edges.filter(e=>e.from.nodeId===upstream.id).length===1;
    const junction=reusable?upstream:addAutomaticJunction(rung,{id:junctionId||String(id||'wire')+'_join',position,target:to});
    destination={nodeId:junction.id,port:'powerIn'};
    if(!reusable){
      for(const edge of incoming)edge.to=copy(destination);
      rung.edges.push({id:networkId(rung,String(id||'wire')+'_tail'),from:{nodeId:junction.id,port:'powerOut'},to:copy(to),waypoints:[]});
    }
    if(rung.edges.some(e=>equal(e.from,from)&&equal(e.to,destination)))throw new Error('These paths are already connected.');
  }else if(input.multiple!==true)rung.edges=rung.edges.filter(e=>!equal(e.to,to));
  if(input.kind==='data')clearNetworkBinding(target,to.port);
  rung.edges.push({id:replaceId||id||networkId(rung),from:copy(from),to:destination,waypoints:waypoints===undefined?previous?.waypoints || []:copy(waypoints)});
  validateNetwork(candidate,{draft:true});return candidate;
}
// Connecting to a power wire creates the electrical junction automatically.
// An output merges into the wire (OR); an input takes a parallel branch from it.
export function connectNetworkWire(ladder,rungId,endpoint,edgeId,{id,junctionId,position,replaceId,waypoints}={}){
  const candidate=copy(ladder),rung=candidate.rungs.find(r=>r.id===rungId);if(!rung)throw new Error('The rung is no longer available.');
  const edge=rung.edges.find(e=>e.id===edgeId),node=rung.nodes.find(n=>n.id===endpoint.nodeId),port=node&&networkPorts(node).find(p=>p.id===endpoint.port);
  const source=edge&&rung.nodes.find(n=>n.id===edge.from.nodeId),wirePort=source&&networkPorts(source).find(p=>p.id===edge.from.port);
  if(!edge||!port)throw new Error('The wire or port is no longer available.');
  if(port.kind!=='power'||wirePort?.kind!=='power')throw new Error('Parallel branches connect power wires only.');
  if(edgeId===replaceId)throw new Error('Reconnect to a different wire.');
  if(equal(endpoint,edge.from)||equal(endpoint,edge.to))throw new Error('This port is already on the wire.');
  const destination=rung.nodes.find(n=>n.id===edge.to.nodeId);
  if(port.direction==='out'&&destination?.nodeType==='junction')return connectNetworkPorts(candidate,rungId,endpoint,edge.to,{id,replaceId,waypoints});
  // A private merge already feeding this wire can accept the restored/new branch directly.
  if(port.direction==='out'&&source.nodeType==='junction'&&rung.edges.filter(e=>e.from.nodeId===source.id).length===1)return connectNetworkPorts(candidate,rungId,endpoint,{nodeId:source.id,port:'powerIn'},{id,replaceId,waypoints});
  // The split affects only the selected segment, not other wires from its source.
  const originalTo=copy(edge.to),start=pointFor(rung,edge.from),end=pointFor(rung,edge.to);
  const junction=addAutomaticJunction(rung,{id:junctionId||String(id||'wire')+'_join',position:position||{x:Math.max(0,((start?.x??0)+(end?.x??0))/2-29),y:Math.max(0,((start?.y??0)+(end?.y??0))/2-29)}});
  const path=orthogonalWire(start,end,edge.waypoints||[]),tap={x:junction.position.x+29,y:junction.position.y+29};let split=0,distance=Infinity;
  for(let i=0;i<path.length-1;i++){const a=path[i],b=path[i+1],p={x:Math.max(Math.min(a.x,b.x),Math.min(Math.max(a.x,b.x),tap.x)),y:Math.max(Math.min(a.y,b.y),Math.min(Math.max(a.y,b.y),tap.y))},d=(p.x-tap.x)**2+(p.y-tap.y)**2;if(d<distance){distance=d;split=i;}}
  // Preserve authored bends on their respective halves of the selected segment.
  const upstream=[],downstream=[];let pathIndex=0;
  for(const bend of edge.waypoints||[]){let index=path.findIndex((p,i)=>i>=pathIndex&&p.x===bend.x&&p.y===bend.y);if(index<0)index=pathIndex;(index<=split?upstream:downstream).push(copy(bend));pathIndex=index;}
  edge.to={nodeId:junction.id,port:'powerIn'};edge.waypoints=upstream;
  rung.edges.push({id:networkId(rung,String(id||'wire')+'_tail'),from:{nodeId:junction.id,port:'powerOut'},to:originalTo,waypoints:downstream});
  const from=port.direction==='out'?endpoint:{nodeId:junction.id,port:'powerOut'},to=port.direction==='in'?endpoint:{nodeId:junction.id,port:'powerIn'};
  return connectNetworkPorts(candidate,rungId,from,to,{id,replaceId,waypoints});
}
export function deleteNetworkElement(ladder,rungId,id,kind){
  const rung=ladder.rungs.find(r=>r.id===rungId);if(!rung)return false;
  if(kind==='wire'){const index=rung.edges.findIndex(e=>e.id===id);if(index<0)return false;rung.edges.splice(index,1);return true;}
  const index=rung.nodes.findIndex(n=>n.id===id);if(index<0)return false;
  rung.nodes.splice(index,1);rung.edges=rung.edges.filter(e=>e.from.nodeId!==id&&e.to.nodeId!==id);return true;
}
export function orthogonalWire(from,to,waypoints=[]){
  const anchors=[from,...waypoints,to],points=[{...from}];
  for(let i=1;i<anchors.length;i++){
    const a=points.at(-1),b=anchors[i];
    if(a.x!==b.x&&a.y!==b.y){
      if(anchors.length===2){const x=Math.round((a.x+b.x)/2);points.push({x,y:a.y},{x,y:b.y});}
      else points.push({x:b.x,y:a.y});
    }
    points.push({...b});
  }
  return points.filter((p,i)=>!i||p.x!==points[i-1].x||p.y!==points[i-1].y);
}
export function moveOrthogonalSegment(points,index,cursor){
  if(!Array.isArray(points)||points.length<2||!Number.isInteger(index)||index<0||index>=points.length-1)throw new Error('Select a valid wire segment.');
  const valid=point=>point&&Number.isFinite(point.x)&&Number.isFinite(point.y)&&Math.abs(point.x)<=100000&&Math.abs(point.y)<=100000;
  if(!valid(cursor)||points.some(point=>!valid(point)))throw new Error('Wire coordinates must be finite and within the canvas limits.');
  const a=copy(points[index]),b=copy(points[index+1]);
  if(a.x!==b.x&&a.y!==b.y)throw new Error('Select a horizontal or vertical wire segment.');
  if(a.y===b.y){a.y=cursor.y;b.y=cursor.y;}else{a.x=cursor.x;b.x=cursor.x;}
  const waypoints=[...points.slice(1,index),a,b,...points.slice(index+2,-1)].filter((p,i,all)=>!i||p.x!==all[i-1].x||p.y!==all[i-1].y);
  if(waypoints.length>128)throw new Error('This wire has reached its limit of 128 routing points. Reset some wire bends before adding more.');
  return copy(waypoints);
}
function size(node){return node.nodeType==='rail'?{w:38,h:126}:node.nodeType==='junction'?{w:58,h:58}:node.nodeType==='coil'?{w:172,h:190}:{w:148,h:Math.max(126,60+networkPorts(node).filter(p=>p.direction==='in').length*28)};}
function ports(node){
  const all=networkPorts(node),s=size(node);
  return all.map(port=>{const side=all.filter(p=>p.direction===port.direction),index=side.indexOf(port);return {...port,x:port.direction==='in'?0:s.w,y:side.length===1?s.h/2:35+index*28};});
}
function pointFor(rung,endpoint){const node=rung.nodes.find(n=>n.id===endpoint.nodeId),port=node&&ports(node).find(p=>p.id===endpoint.port);return port?{x:node.position.x+port.x,y:node.position.y+port.y}:null;}
export class LadderCanvas {
  constructor(editor){this.editor=editor;this.pendingWire=null;this.gesture=null;this.map={};}
  get ladder(){return this.editor.ladder;}
  rung(id){return this.ladder.rungs.find(r=>r.id===id);}
  view(rung,selection=this.editor.selection){
    const view=Object.create(rung);view.graphRung=rung;
    view.branches=[{id:'graph',contacts:rung.nodes.filter(n=>n.nodeType==='contact')}];view.blocks=rung.nodes.filter(n=>n.nodeType==='block');
    view.coil=rung.nodes.find(n=>n.nodeType==='coil'&&n.id===selection?.id)||rung.nodes.find(n=>n.nodeType==='coil');
    Object.defineProperty(view,'name',{get:()=>rung.name,set:value=>{rung.name=value;},enumerable:true});return view;
  }
  rebuildMap(){try{this.map=compileNetwork(this.ladder).networkMap || {};}catch{this.map={};}}
  changed(){this.pendingWire=null;this.editor.clearPlacement();this.rebuildMap();this.editor.changed();}
  canPlace(payload,kind){
    if(this.editor.runtime.running||!payload)return false;
    if(payload.instruction)return ['graph','new-rung'].includes(kind);
    const device=this.editor.devices.find(d=>d.id===payload.deviceId);if(!device)return false;
    const features=kind==='output'?this.editor.writableFeatures(device):this.editor.readableFeatures(device);
    return payload.code?features.some(p=>p.code===payload.code):features.length>0;
  }
  addRung(){
    if(this.editor.runtime.running)return;if(this.ladder.rungs.length>=64)throw new Error('At most 64 rungs are supported.');
    const rung={id:this.editor.uid('rung'),name:`Rung ${this.ladder.rungs.length+1}`,nodes:[{id:this.editor.uid('rail'),nodeType:'rail',position:{x:30,y:90}}],edges:[]};this.ladder.rungs.push(rung);return rung;
  }
  place(payload,target){
    if(!this.canPlace(payload,target.kind))return;
    const before=copy(this.ladder);
    try{
      const rung=target.kind==='new-rung'?this.addRung():this.rung(target.rungId);if(!rung)throw new Error('Select a rung first.');if(rung.nodes.length>=128)throw new Error('This rung has reached its node limit.');
      const position={x:snap(target.x??180),y:snap(target.y??90)};let node;
      if(payload.instruction){
        const type=payload.instruction;
        if(['NO','NC','VIRTUAL','VIRTUAL_NUMBER'].includes(type)){
          const tag=type.startsWith('VIRTUAL')?this.editor.createVirtualTag(type==='VIRTUAL_NUMBER'?'number':'boolean'):null;
          node={id:this.editor.uid('contact'),nodeType:'contact',position,tagId:tag?.id || '',kind:type==='NC'?'NC':type==='VIRTUAL_NUMBER'?'COMPARE':'NO',operator:'GT',value:0};
        }else if(['PARALLEL','JUNCTION'].includes(type))node={id:this.editor.uid('junction'),nodeType:'junction',position};
        else if(type==='RAIL')node={id:this.editor.uid('rail'),nodeType:'rail',position};
        else if(type==='COIL')node={id:this.editor.uid('coil'),nodeType:'coil',position,tagId:'',deviceId:'',mode:'follow',value:false};
        else{node={...this.editor.makeFunction(type),nodeType:'block',position};for(const port of networkPorts(node))if(['reset','down'].includes(port.id)){node.bindings ||= {};node.bindings[port.id]={value:false};}}
      }else{
        const device=this.editor.devices.find(d=>d.id===payload.deviceId),output=target.kind==='output',features=output?this.editor.writableFeatures(device):this.editor.readableFeatures(device),feature=features.find(p=>p.code===payload.code);
        if(output){node={id:this.editor.uid('coil'),nodeType:'coil',position,deviceId:device.id,tagId:'',mode:'follow',value:false};if(feature)this.editor.selectOutputFeature({id:rung.id,coil:node},device,feature);}
        else{const tag=feature?this.editor.ensurePropertyTag(device,feature,'input'):null;node={id:this.editor.uid('contact'),nodeType:'contact',position,deviceId:device.id,tagId:tag?.id || '',kind:!tag||tag.dataType==='boolean'?'NO':'COMPARE',operator:tag?.dataType==='string'?'EQ':'GT',value:tag?.dataType==='string'?'':0};}
      }
      rung.nodes.push(node);validateNetwork(this.ladder,{draft:true});this.editor.selection={kind:node.nodeType,id:node.id,rungId:rung.id,branchId:'graph'};this.changed();
    }catch(error){this.editor.ladder=before;this.editor.onError?.(error.message);}
  }
  disconnectBinding(rungId,nodeId,port){const rung=this.rung(rungId),node=rung?.nodes.find(n=>n.id===nodeId);if(node?.bindings)delete node.bindings[port];if(rung)rung.edges=rung.edges.filter(e=>!(e.to.nodeId===nodeId&&e.to.port===port));}
  syncPorts(rung,node){const ids=new Set(networkPorts(node).map(p=>p.id));rung.edges=rung.edges.filter(edge=>(edge.from.nodeId!==node.id||ids.has(edge.from.port))&&(edge.to.nodeId!==node.id||ids.has(edge.to.port)));if(node.bindings)for(const port of Object.keys(node.bindings))if(!ids.has(port))delete node.bindings[port];}
  bindingChanged(rungId,nodeId,port){
    const rung=this.rung(rungId),node=rung?.nodes.find(n=>n.id===nodeId);if(!node)return;this.disconnectBinding(rungId,nodeId,port);
    if(port==='reset'&&!node.resetTagId){node.bindings ||= {};node.bindings.reset={value:false};}
    if(port==='down'&&!node.downTagId){node.bindings ||= {};node.bindings.down={value:false};}
  }
  setOperand(rungId,nodeId,port,source){
    if(this.editor.runtime.running)return;
    try{
      if(Object.hasOwn(source,'blockId')){
        this.editor.ladder=connectNetworkPorts(this.ladder,rungId,{nodeId:source.blockId,port:'result'},{nodeId,port},{id:this.editor.uid('wire')});
      }else{
        const rung=this.rung(rungId),node=rung.nodes.find(n=>n.id===nodeId);this.disconnectBinding(rungId,nodeId,port);
        if(port==='value')node.source=copy(source);else{node.operands ||= [];node.operands[Number(port.slice(7))]=copy(source);}
      }
      this.changed();
    }catch(error){this.editor.onError?.(error.message);}
  }
  assignDevice(rung,node,payload){
    if(this.editor.runtime.running||!payload?.deviceId||!['contact','coil'].includes(node.nodeType))return;
    const before=copy(this.ladder),e=this.editor,device=e.devices.find(d=>d.id===payload.deviceId),features=node.nodeType==='coil'?e.writableFeatures(device):e.readableFeatures(device),feature=features.find(f=>f.code===payload.code);
    try{
      if(!features.length||payload.code&&!feature)throw new Error('Choose a device feature compatible with this element.');
      if(node.nodeType==='coil'){if(feature)e.selectOutputFeature({id:rung.id,coil:node},device,feature);else Object.assign(node,{tagId:'',deviceId:device.id,mode:'follow',value:false});}
      else if(feature)e.selectInputFeature(node,device,feature);else Object.assign(node,{tagId:'',deviceId:device.id,kind:'NO'});
      this.syncPorts(rung,node);e.selection={kind:node.nodeType,id:node.id,rungId:rung.id,branchId:'graph'};this.changed();
    }catch(error){e.ladder=before;e.onError?.(error.message);}
  }
  deleteSelection(){
    const selection=this.editor.selection;if(!selection||this.editor.runtime.running)return false;
    if(selection.kind==='multi'){
      const candidate=copy(this.ladder),rung=candidate.rungs.find(r=>r.id===selection.rungId);if(!rung)return false;
      const nodeIds=new Set(selection.nodeIds||[]),wireIds=new Set(selection.wireIds||[]),before=rung.nodes.length+rung.edges.length;
      rung.nodes=rung.nodes.filter(node=>!nodeIds.has(node.id));rung.edges=rung.edges.filter(edge=>!wireIds.has(edge.id)&&!nodeIds.has(edge.from.nodeId)&&!nodeIds.has(edge.to.nodeId));
      if(before===rung.nodes.length+rung.edges.length)return false;
      try{validateNetwork(candidate,{draft:true});}catch(error){this.editor.onError?.(error.message);return false;}
      this.gesture?.dispose?.();this.editor.ladder=candidate;
    }else if(selection.kind==='rung'){
      if(!confirm('Delete this rung and its elements?'))return false;const index=this.ladder.rungs.findIndex(r=>r.id===selection.id);if(index<0)return false;this.ladder.rungs.splice(index,1);
    }else if(!deleteNetworkElement(this.ladder,selection.rungId,selection.id,selection.kind))return false;
    this.editor.selection=null;this.changed();this.editor.onInspector?.('instructions');return true;
  }
  select(kind,id,rungId){this.pendingWire=null;this.editor.clearPlacement();this.editor.selection={kind,id,rungId,branchId:'graph'};this.editor.renderInspector();this.editor.highlightSelection();this.editor.onInspector?.('properties');this.renderWires(rungId);const canvas=$$('[data-network-rung]',this.editor.stage).find(c=>c.dataset.networkRung===rungId);canvas?.focus?.({preventScroll:true});this.updateWireActions();}
  updateWireActions(){const button=$('#network-delete-wire',this.editor.stage);if(button){button.disabled=this.editor.runtime.running||!['wire','multi'].includes(this.editor.selection?.kind);button.textContent=this.editor.selection?.kind==='multi'?'Delete selected':'Delete wire';}}
  multiSelection(rungId,nodeIds=[],wireIds=[]){
    const rung=this.rung(rungId);if(!rung)return null;
    const nodes=[...new Set(nodeIds)].filter(id=>rung.nodes.some(node=>node.id===id)),wires=[...new Set(wireIds)].filter(id=>rung.edges.some(edge=>edge.id===id));
    return nodes.length||wires.length?{kind:'multi',rungId,nodeIds:nodes,wireIds:wires}:null;
  }
  beginMarquee(event,rungId,canvas){
    const e=this.editor,rung=this.rung(rungId);
    if(!rung||event.button!==0||e.runtime.running||this.pendingWire||this.gesture||e.placement||e.paletteDragging)return;
    if(event.target.closest('[data-network-node],[data-wire-id],[data-port],[data-wire-end],[data-wire-segment],button,input,textarea,select'))return;
    const bounds=canvas.getBoundingClientRect(),point=ev=>({x:Math.max(0,ev.clientX-bounds.left),y:Math.max(0,ev.clientY-bounds.top)}),start=point(event),previous=e.selection?copy(e.selection):null;
    const same=event.shiftKey&&previous?.rungId===rungId,baseNodes=same?(previous.kind==='multi'?previous.nodeIds||[]:rung.nodes.some(node=>node.id===previous.id)?[previous.id]:[]):[],baseWires=same?(previous.kind==='multi'?previous.wireIds||[]:previous.kind==='wire'?[previous.id]:[]):[];
    let rectangle=null,moved=false;const doc=canvas.ownerDocument||document;
    event.preventDefault();canvas.focus?.({preventScroll:true});
    const refresh=()=>{e.highlightSelection();this.renderWires(rungId);this.updateWireActions();};
    const dispose=()=>{doc.removeEventListener('pointermove',move);doc.removeEventListener('pointerup',up);doc.removeEventListener('pointercancel',cancel);rectangle?.remove();if(this.gesture===gesture)this.gesture=null;};
    const cancel=()=>{dispose();e.selection=previous;e.renderInspector();refresh();};
    const move=ev=>{
      if(e.runtime.running){cancel();return;}
      const end=point(ev);if(!moved&&Math.abs(end.x-start.x)+Math.abs(end.y-start.y)<6)return;moved=true;
      if(!rectangle){rectangle=doc.createElement('div');rectangle.className='network-marquee';rectangle.setAttribute('aria-hidden','true');canvas.append(rectangle);}
      const rect={left:Math.min(start.x,end.x),top:Math.min(start.y,end.y),right:Math.max(start.x,end.x),bottom:Math.max(start.y,end.y)};
      Object.assign(rectangle.style,{left:rect.left+'px',top:rect.top+'px',width:(rect.right-rect.left)+'px',height:(rect.bottom-rect.top)+'px'});
      const hit=rung.nodes.filter(node=>{const s=size(node);return node.position.x<=rect.right&&node.position.x+s.w>=rect.left&&node.position.y<=rect.bottom&&node.position.y+s.h>=rect.top;}).map(node=>node.id);
      e.selection=this.multiSelection(rungId,[...baseNodes,...hit],baseWires);refresh();
    };
    const up=ev=>{if(e.runtime.running){cancel();return;}if(moved)move(ev);dispose();if(moved){this.suppressCanvasClick=true;e.clearPlacement();e.renderInspector();refresh();e.onInspector?.('properties');this.status(e.selection?e.selection.nodeIds.length+' elements selected. Press Delete or Backspace to remove them.':'No elements selected.');canvas.focus?.({preventScroll:true});}};
    const gesture={kind:'marquee',rungId,cancel,dispose};this.gesture=gesture;doc.addEventListener('pointermove',move);doc.addEventListener('pointerup',up);doc.addEventListener('pointercancel',cancel);
  }
  wireFrom(rungId,endpoint,replaceId){
    if(this.editor.runtime.running)return;const node=this.rung(rungId)?.nodes.find(n=>n.id===endpoint.nodeId),port=node&&networkPorts(node).find(p=>p.id===endpoint.port);if(!port)return;
    this.pendingWire={rungId,endpoint,port,replaceId};this.editor.clearPlacement();this.status('Choose a matching '+(port.direction==='out'?'IN':'OUT')+' port or power wire. Escape cancels.');this.renderWires(rungId);
  }
  trackWirePointer(canvas){
    const move=event=>{if(!this.pendingWire)return;this.pendingWire.cursor=this.canvasPoint(event,canvas);this.renderWires(this.pendingWire.rungId);};
    const up=event=>{
      document.removeEventListener('pointermove',move);document.removeEventListener('pointerup',up);
      if(!this.pendingWire)return;
      const hit=document.elementFromPoint(event.clientX,event.clientY),port=hit?.closest('[data-port]'),wire=hit?.closest('[data-wire-id]');
      if(port)this.choosePort(port.dataset.rungId,{nodeId:port.dataset.nodeId,port:port.dataset.port});
      else if(wire)this.chooseWire(wire.closest('[data-network-rung]')?.dataset.networkRung,wire.dataset.wireId,event);
    };
    document.addEventListener('pointermove',move);document.addEventListener('pointerup',up);
  }
  choosePort(rungId,endpoint){
    if(this.editor.runtime.running)return;const pending=this.pendingWire;
    if(!pending){this.wireFrom(rungId,endpoint);return;}
    if(pending.rungId!==rungId){this.editor.onError?.('Wires connect ports within the same rung.');return;}
    if(equal(pending.endpoint,endpoint))return;
    const from=pending.port.direction==='out'?pending.endpoint:endpoint,to=pending.port.direction==='in'?pending.endpoint:endpoint;
    try{const next=connectNetworkPorts(this.ladder,rungId,from,to,{id:this.editor.uid('wire'),replaceId:pending.replaceId,junctionId:this.editor.uid('join')});this.editor.ladder=next;this.editor.selection=null;this.changed();}
    catch(error){this.editor.onError?.(error.message);}
  }
  chooseWire(rungId,edgeId,event){
    if(this.editor.runtime.running||!this.pendingWire)return;
    const pending=this.pendingWire;
    if(pending.rungId!==rungId){this.editor.onError?.('Wires connect within the same rung.');return;}
    const canvas=$$('[data-network-rung]',this.editor.stage).find(c=>c.dataset.networkRung===rungId);
    const point=event&&canvas?this.canvasPoint(event,canvas):null;
    try{
      this.editor.ladder=connectNetworkWire(this.ladder,rungId,pending.endpoint,edgeId,{id:this.editor.uid('wire'),junctionId:this.editor.uid('join'),position:point?{x:snap(point.x-29),y:snap(point.y-29)}:undefined,replaceId:pending.replaceId});
      this.editor.selection=null;this.changed();
    }catch(error){this.editor.onError?.(error.message);}
  }
  status(text){const el=$('#network-status',this.editor.stage);if(el)el.textContent=text;}
  handleKeyDown(event){if(event.key==='Escape'&&(this.pendingWire||this.gesture)){this.gesture?.cancel?.();this.pendingWire=null;this.gesture=null;this.renderAllWires();this.status('Connect ports or end a wire on another power wire. Parallel paths combine with OR.');event.preventDefault();return true;}return false;}
  canvasPoint(event,canvas){const rect=canvas.getBoundingClientRect();return {x:snap(event.clientX-rect.left),y:snap(event.clientY-rect.top)};}
  bindCanvasDrop(canvas,rungId,kind='graph'){
    canvas.dataset.dropKind=kind;if(rungId)canvas.dataset.dropRung=rungId;
    if(kind==='graph'){canvas.addEventListener('pointerdown',()=>{this.suppressCanvasClick=false;},true);canvas.addEventListener('pointerdown',event=>this.beginMarquee(event,rungId,canvas));}
    const payload=event=>{try{return JSON.parse(event.dataTransfer?.getData('application/x-tuya-logic-device')||'null')||this.editor.placement;}catch{return this.editor.placement;}},position=event=>kind==='new-rung'?{x:180,y:90}:this.canvasPoint(event,canvas.closest('.network-canvas')||canvas);
    canvas.addEventListener('dragover',event=>{if(this.canPlace(this.editor.placement,kind)){event.preventDefault();event.stopPropagation();canvas.classList.add('drop-over');}});
    canvas.addEventListener('dragleave',()=>canvas.classList.remove('drop-over'));
    canvas.addEventListener('drop',event=>{event.preventDefault();event.stopPropagation();canvas.classList.remove('drop-over');this.place(payload(event),{kind,rungId,...position(event)});});
    canvas.addEventListener('click',event=>{if(this.suppressCanvasClick){this.suppressCanvasClick=false;event.preventDefault();event.stopPropagation();return;}if(event.target.closest('[data-network-node],[data-wire-id],[data-port]'))return;if(kind==='output')return;if(this.editor.placement){event.stopPropagation();this.place(this.editor.placement,{kind,rungId,...position(event)});}else if(event.target===canvas){this.editor.selection=null;this.editor.renderInspector();this.editor.highlightSelection();this.renderWires(rungId);}});
  }
  render(){
    const e=this.editor;e.ensureDeviceWorkspace();e.renderToolbox();this.rebuildMap();
    const scroll=$('#ladder-scroll',e.stage),old={left:scroll?.scrollLeft||0,top:scroll?.scrollTop||0};
    e.stage.innerHTML='<div class="ladder-toolbar"><div><strong>Free-wiring ladder</strong><small id="network-status">Connect ports or end a wire on another power wire. Parallel paths combine with OR.</small></div><div class="network-actions"><button id="network-delete-wire" class="button small" disabled>Delete wire</button><button id="ladder-add-rung" class="button small" data-ladder-edit>+ Rung</button></div></div><div id="ladder-scroll" class="ladder-scroll network-scroll"><div id="ladder-rungs"></div></div><div class="ladder-legend"><span>Power wire</span><span class="value-wire-legend">Value wire</span><span>Series = AND · Parallel = OR</span><span>Drag symbols or selected wire bends · Delete removes selection</span></div>';
    $('#ladder-add-rung',e.stage).onclick=()=>{try{const rung=this.addRung();if(rung){e.selection={kind:'rung',id:rung.id,rungId:rung.id};this.changed();}}catch(error){e.onError?.(error.message);}};
    $('#network-delete-wire',e.stage).onclick=()=>{if(['wire','multi'].includes(e.selection?.kind))e.deleteSelection();};
    const list=$('#ladder-rungs',e.stage);
    for(const[index,rung]of this.ladder.rungs.entries()){
      const section=document.createElement('section');section.className='network-rung';section.dataset.rungId=rung.id;
      section.innerHTML=`<div class="rung-heading"><button class="rung-select" data-element-id="${esc(rung.id)}"><span>${String(index+1).padStart(3,'0')}</span><strong>${esc(rung.name||'Rung')}</strong></button><span class="network-count">${rung.nodes.length} elements · ${rung.edges.length} wires</span></div>`;
      $('.rung-select',section).onclick=()=>this.select('rung',rung.id,rung.id);
      const canvas=document.createElement('div');canvas.className='network-canvas';canvas.dataset.networkRung=rung.id;canvas.tabIndex=0;canvas.setAttribute('aria-label','Ladder wiring canvas');
      const width=Math.max(1000,...rung.nodes.map(n=>n.position.x+size(n).w+110)),height=Math.max(310,...rung.nodes.map(n=>n.position.y+size(n).h+80));canvas.style.width=width+'px';canvas.style.height=height+'px';
      const wires=svg('svg',{class:'network-wires',width,height,'aria-label':'Rung connections'});canvas.append(wires);canvas.append(svg('svg',{class:'network-wire-controls',width,height,'aria-label':'Wire editing handles'}));this.bindCanvasDrop(canvas,rung.id);
      for(const node of rung.nodes)canvas.append(this.renderNode(rung,node));
      const output=document.createElement('button');output.type='button';output.className='ladder-output-slot network-output-slot';output.dataset.outputSlot=rung.id;output.dataset.ladderEdit='';output.innerHTML='<span>+</span><strong>Drop output</strong>';output.style.left=(width-140)+'px';output.style.top='20px';this.bindCanvasDrop(output,rung.id,'output');output.addEventListener('click',event=>{event.stopPropagation();if(e.placement)this.place(e.placement,{kind:'output',rungId:rung.id,x:width-220,y:100});else this.place({instruction:'COIL'},{kind:'graph',rungId:rung.id,x:width-220,y:100});});canvas.append(output);
      section.append(canvas);list.append(section);this.renderWires(rung.id);
    }
    const blank=document.createElement('button');blank.id='ladder-blank-drop';blank.className='ladder-blank-drop';blank.innerHTML='<strong>+ Drop an input or instruction to add a rung</strong><span>Connect OUT to IN, or end on a power wire to add a parallel branch.</span>';this.bindCanvasDrop(blank,null,'new-rung');list.append(blank);
    const newScroll=$('#ladder-scroll',e.stage);newScroll.scrollLeft=old.left;newScroll.scrollTop=old.top;e.renderInspector();e.highlightSelection();e.refresh(e.devices,e.runtime);this.updateWireActions();
  }
  renderNode(rung,node){
    const e=this.editor,s=size(node),el=document.createElement('div');el.className='network-node network-'+node.nodeType;el.dataset.networkNode=node.id;el.dataset.elementId=node.id;el.style.cssText=`left:${node.position.x}px;top:${node.position.y}px;width:${s.w}px;height:${s.h}px`;el.tabIndex=0;el.setAttribute('role','group');
    let content=document.createElement('button');content.type='button';content.className='network-symbol';
    if(node.nodeType==='contact'){
      const tag=e.tag(node.tagId),device=e.devices.find(d=>d.id===node.deviceId);content.dataset.contactId=node.id;if(tag?.source==='virtual')content.dataset.virtualContact=tag.id;
      content.innerHTML=`<small>${esc(tag?.address||'INPUT')}</small><span class="network-contact-glyph">${node.kind==='COMPARE'?esc(({GT:'>',GTE:'≥',LT:'<',LTE:'≤',EQ:'=',NEQ:'≠'}[node.operator]||'>')+' '+(node.value??'?')):node.kind==='NC'?'─|/|─':'─| |─'}</span><strong>${esc(tag?e.tagName(tag):device?.name||'Choose input')}</strong><em class="contact-live">—</em>`;
    }else if(node.nodeType==='coil'){
      const view=this.view(rung,{id:node.id}),rendered=e.createOutputElement(view);content.className=rendered.className+' network-coil-symbol';content.innerHTML=rendered.innerHTML;content.dataset.coilId=node.id;content.dataset.elementId=node.id;
      if(!e.hasOutputElement(view)){content.className='network-symbol network-pending-output';content.innerHTML='<small>OUTPUT</small><span class="network-contact-glyph">─( )─</span><strong>Choose device</strong>';delete content.dataset.outputSlot;}
    }else if(node.nodeType==='block'){content.dataset.blockId=node.id;content.innerHTML=`<small>${esc(node.type)}</small><strong>${esc(e.types[node.type]?.label||node.type)}</strong><em class="block-live">READY</em>`;}
    else if(node.nodeType==='junction'){content.innerHTML='<span class="junction-dot">●</span>';content.setAttribute('aria-label','Parallel connection');content.title='Parallel connection — OR';}
    else content.innerHTML='<span class="power-rail"></span><small>POWER</small>';
    content.addEventListener('click',event=>{event.stopPropagation();if(e.placement?.deviceId&&['contact','coil'].includes(node.nodeType)){this.assignDevice(rung,node,e.placement);return;}this.select(node.nodeType,node.id,rung.id);const tag=e.tag(node.tagId);if(node.nodeType==='contact'&&tag?.source==='virtual'&&tag.dataType==='boolean'&&e.runtime.running&&['test','live-test'].includes(e.runtime.executionMode))void e.forceVirtualInput(tag.id);});
    if(['contact','coil'].includes(node.nodeType)){
      content.addEventListener('dragover',event=>{if(this.canPlace(e.placement,node.nodeType==='coil'?'output':'graph')){event.preventDefault();event.stopPropagation();}});
      content.addEventListener('drop',event=>{event.preventDefault();event.stopPropagation();let payload;try{payload=JSON.parse(event.dataTransfer.getData('application/x-tuya-logic-device'));}catch{payload=e.placement;}this.assignDevice(rung,node,payload);});
    }
    content.addEventListener('pointerdown',event=>this.beginMove(event,rung,node,el));el.append(content);
    for(const port of ports(node)){
      const button=document.createElement('button');button.type='button';button.className=`network-port ${port.direction} ${port.kind}`;button.dataset.port=port.id;button.dataset.nodeId=node.id;button.dataset.rungId=rung.id;button.style.top=port.y+'px';button.style.left=port.x+'px';button.title=`${port.direction==='in'?'Input':'Output'}: ${port.id} (${port.kind==='power'?'rung power':port.dataType||'value'})`;button.setAttribute('aria-label',node.id+' '+port.id);button.innerHTML='<i></i><span>'+esc(port.id.replace('powerIn','IN').replace('powerOut','OUT').replace('operand','IN '))+'</span>';
      button.addEventListener('pointerdown',event=>{if(e.runtime.running)return;event.preventDefault();event.stopPropagation();const endpoint={nodeId:node.id,port:port.id};if(this.pendingWire){this.choosePort(rung.id,endpoint);return;}this.wireFrom(rung.id,endpoint);const canvas=el.closest('.network-canvas');const move=ev=>{if(!this.pendingWire)return;this.pendingWire.cursor=this.canvasPoint(ev,canvas);this.renderWires(rung.id);};const up=ev=>{document.removeEventListener('pointermove',move);document.removeEventListener('pointerup',up);const hit=document.elementFromPoint(ev.clientX,ev.clientY),target=hit?.closest('[data-port]'),wire=hit?.closest('[data-wire-id]');if(target&&!(target.dataset.nodeId===node.id&&target.dataset.port===port.id))this.choosePort(target.dataset.rungId,{nodeId:target.dataset.nodeId,port:target.dataset.port});else if(wire)this.chooseWire(wire.closest('[data-network-rung]')?.dataset.networkRung,wire.dataset.wireId,ev);};document.addEventListener('pointermove',move);document.addEventListener('pointerup',up);});
      button.addEventListener('click',event=>{event.stopPropagation();if(event.detail===0)this.choosePort(rung.id,{nodeId:node.id,port:port.id});});el.append(button);
    }
    return el;
  }
  beginMove(event,rung,node,el){
    if(this.editor.runtime.running||event.button!==0||this.pendingWire)return;const canvas=el.closest('.network-canvas'),start={x:event.clientX,y:event.clientY},before={...node.position};let moved=false;
    const move=ev=>{if(this.editor.runtime.running)return;const dx=ev.clientX-start.x,dy=ev.clientY-start.y;if(!moved&&Math.abs(dx)+Math.abs(dy)<6)return;moved=true;node.position={x:snap(before.x+dx),y:snap(before.y+dy)};el.style.left=node.position.x+'px';el.style.top=node.position.y+'px';this.renderWires(rung.id);};
    const up=()=>{document.removeEventListener('pointermove',move);document.removeEventListener('pointerup',up);if(moved){this.editor.selection={kind:node.nodeType,id:node.id,rungId:rung.id,branchId:'graph'};this.changed();}};
    document.addEventListener('pointermove',move);document.addEventListener('pointerup',up);
  }
  renderAllWires(){for(const rung of this.ladder.rungs)this.renderWires(rung.id);}
  renderWires(rungId){
    const rung=this.rung(rungId),canvas=$$('[data-network-rung]',this.editor.stage).find(c=>c.dataset.networkRung===rungId),layer=canvas&&$('.network-wires',canvas);if(!rung||!layer)return;layer.replaceChildren();const controls=$('.network-wire-controls',canvas)||layer;if(controls!==layer)controls.replaceChildren();
    for(const edge of rung.edges){
      const from=pointFor(rung,edge.from),to=pointFor(rung,edge.to);if(!from||!to)continue;const points=orthogonalWire(from,to,edge.waypoints),path=points.map((p,i)=>(i?'L':'M')+p.x+' '+p.y).join(' '),selected=this.editor.selection?.kind==='wire'&&this.editor.selection.id===edge.id&&this.editor.selection.rungId===rungId;
      const source=rung.nodes.find(n=>n.id===edge.from.nodeId),kind=networkPorts(source).find(p=>p.id===edge.from.port)?.kind;
      const line=svg('path',{d:path,class:'network-wire '+(kind==='data'?'data ':'')+(selected?'selected':''),'data-wire-id':edge.id});layer.append(line);
      const hit=svg('path',{d:path,class:'network-wire-hit','data-wire-id':edge.id,tabindex:0,role:'button','aria-label':'Select wire '+edge.id});hit.addEventListener('click',event=>{event.stopPropagation();if(this.pendingWire)this.chooseWire(rungId,edge.id,event);else this.select('wire',edge.id,rungId);});hit.addEventListener('keydown',event=>{if(event.key==='Enter')this.select('wire',edge.id,rungId);});layer.append(hit);
      if(selected&&!this.editor.runtime.running){
        for(const[end,point]of [['from',from],['to',to]]){const handle=svg('circle',{cx:point.x,cy:point.y,r:7,class:'wire-end-handle','data-wire-end':end,tabindex:0});handle.addEventListener('pointerdown',event=>{event.preventDefault();event.stopPropagation();this.wireFrom(rungId,end==='from'?edge.to:edge.from,edge.id);this.trackWirePointer(canvas);});controls.append(handle);}
        for(let i=0;i<points.length-1;i++){const a=points[i],b=points[i+1];if(Math.abs(a.x-b.x)+Math.abs(a.y-b.y)<18)continue;const handle=svg('rect',{x:(a.x+b.x)/2-4,y:(a.y+b.y)/2-4,width:8,height:8,class:'wire-bend-handle','data-wire-segment':i});handle.addEventListener('pointerdown',event=>this.moveSegment(event,rung,edge,i,points,canvas));layer.append(handle);}
      }
    }
    if(this.pendingWire?.rungId===rungId){const start=pointFor(rung,this.pendingWire.endpoint),end=this.pendingWire.cursor||{x:start.x+60,y:start.y};if(start)layer.append(svg('path',{d:orthogonalWire(start,end).map((p,i)=>(i?'L':'M')+p.x+' '+p.y).join(' '),class:'network-wire-preview'}));}
  }
  moveSegment(event,rung,edge,index,points,canvas){
    if(this.editor.runtime.running)return;event.preventDefault();event.stopPropagation();const original=copy(edge.waypoints||[]),horizontal=points[index].y===points[index+1].y;let moved=false;
    const move=ev=>{if(this.editor.runtime.running)return;const p=this.canvasPoint(ev,canvas),a={...points[index]},b={...points[index+1]};if(horizontal){a.y=p.y;b.y=p.y;}else{a.x=p.x;b.x=p.x;}try{edge.waypoints=moveOrthogonalSegment(points,index,p);moved=true;this.renderWires(rung.id);}catch(error){this.editor.onError?.(error.message);}};
    const up=()=>{document.removeEventListener('pointermove',move);document.removeEventListener('pointerup',up);if(moved){try{validateNetwork(this.ladder,{draft:true});this.changed();}catch(error){edge.waypoints=original;this.editor.onError?.(error.message);this.renderWires(rung.id);}}};document.addEventListener('pointermove',move);document.addEventListener('pointerup',up);
  }
  renderInspector(){
    const e=this.editor,s=e.selection,rung=this.rung(s?.rungId);if(!s||!rung)return false;
    if(!['wire','junction','rail','multi'].includes(s.kind))return false;
    e.inspector.dataset.owner='ladder';
    if(s.kind==='multi'){
      const nodeIds=new Set(s.nodeIds||[]),wireIds=new Set(s.wireIds||[]),count=rung.nodes.filter(node=>nodeIds.has(node.id)).length,wires=rung.edges.filter(edge=>wireIds.has(edge.id)||nodeIds.has(edge.from.nodeId)||nodeIds.has(edge.to.nodeId)).length;
      e.inspector.innerHTML='<span class="badge">MULTIPLE SELECTION</span><h3>'+count+' elements selected</h3><p class="field-help">Delete or Backspace removes these elements and '+wires+' connected wires. Unselected elements stay in place.</p><p class="field-help">Drag a box on empty canvas to select. Hold Shift to add another area.</p><button type="button" id="network-delete-selection" class="quiet-button delete-button">Delete selected</button>';
      $('#network-delete-selection',e.inspector).onclick=()=>e.deleteSelection();
    }else if(s.kind==='wire'){
      const edge=rung.edges.find(x=>x.id===s.id);if(!edge)return false;
      e.inspector.innerHTML=`<form><span class="badge">WIRE</span><h3>Connection</h3><p class="field-help">${esc(edge.from.nodeId)} / ${esc(edge.from.port)} → ${esc(edge.to.nodeId)} / ${esc(edge.to.port)}</p><p class="field-help">End a power wire on this wire to create a parallel connection automatically. A crossing alone does not connect.</p><button type="button" id="wire-source" class="button secondary small">Reconnect source</button><button type="button" id="wire-target" class="button secondary small">Reconnect destination</button><button type="button" id="wire-straighten" class="quiet-button">Reset wire bends</button><button type="button" id="wire-delete" class="quiet-button delete-button">Delete wire</button></form>`;
      $('#wire-source',e.inspector).onclick=()=>this.wireFrom(rung.id,edge.to,edge.id);$('#wire-target',e.inspector).onclick=()=>this.wireFrom(rung.id,edge.from,edge.id);$('#wire-straighten',e.inspector).onclick=()=>{if(e.runtime.running)return;edge.waypoints=[];this.changed();};$('#wire-delete',e.inspector).onclick=()=>e.deleteSelection();
    }else e.inspector.innerHTML=`<span class="badge">${s.kind==='rail'?'POWER RAIL':'PARALLEL CONNECTION'}</span><p class="field-help">${s.kind==='rail'?'The power rail supplies TRUE to connected paths.':'Parallel paths combine with OR. Connections are created when a wire ends on another wire or on a connected input.'}</p><button type="button" id="network-delete-node" class="quiet-button delete-button">Delete ${s.kind}</button>`;
    $('#network-delete-node',e.inspector)?.addEventListener('click',()=>e.deleteSelection());$$('button',e.inspector).forEach(b=>b.disabled=!!e.runtime.running);return true;
  }
  telemetry(){
    this.updateWireActions();const e=this.editor,live=new Map((e.runtime.nodes||[]).map(n=>[n.id,n]));
    for(const rung of this.ladder.rungs){
      const canvas=$$('[data-network-rung]',e.stage).find(el=>el.dataset.networkRung===rung.id);if(!canvas)continue;const map=this.map[rung.id]||{};
      for(const node of rung.nodes){
        const el=$$('[data-network-node]',canvas).find(el=>el.dataset.networkNode===node.id);if(!el)continue;const result=live.get(map.nodes?.[node.id]?.result||`ld_${rung.id}_${node.id}`),flow=live.get(map.nodes?.[node.id]?.powerOut);el.classList.toggle('energized',!!e.runtime.running&&flow?.valid===true&&flow.value===true);
        if(node.nodeType==='contact'){const tag=e.tag(node.tagId),value=e.readTag(tag),label=$('.contact-live',el);label.textContent=value.valid?String(value.value)+(tag?.unit?' '+tag.unit:''):value.quality.shortLabel;el.classList.toggle('invalid',!value.valid);}
        if(node.nodeType==='block')$('.block-live',el).textContent=!e.runtime.running?'READY':result?.valid===false?'INVALID':result?.elapsedMs!==undefined?(result.elapsedMs/1000).toFixed(1)+' s':String(result?.count??result?.value??'READY');
        if(node.nodeType==='coil'){
          const view=this.view(rung,{id:node.id}),feedback=e.coilFeedback(view);const actual=$('[data-coil-device]',el);if(actual){$('[data-coil-logic]',el).textContent='Logic: '+feedback.logicText;actual.textContent='Device: '+feedback.deviceText;actual.classList.toggle('actual-fresh',feedback.actualFresh);actual.classList.toggle('device-on',feedback.actualFresh&&feedback.actualValue===true);actual.classList.toggle('device-off',feedback.actualFresh&&feedback.actualValue===false);const badge=$('[data-coil-command]',el);badge.textContent=feedback.commandText;badge.dataset.status=feedback.commandKind;$('[data-coil-observed]',el).textContent=feedback.observation;}
          if(e.selection?.kind==='coil'&&e.selection.rungId===rung.id&&e.selection.id===node.id){const panel=$('#ladder-output-feedback',e.inspector);if(panel){$('[data-inspector-logic]',panel).textContent=feedback.logicText;const device=$('[data-inspector-device]',panel);device.textContent=feedback.deviceText;device.classList.toggle('actual-fresh',feedback.actualFresh);$('[data-inspector-desired]',panel).textContent=feedback.desiredText;const command=$('[data-inspector-command]',panel);command.textContent=feedback.commandText;command.dataset.status=feedback.commandKind;$('[data-inspector-observation]',panel).textContent=feedback.observation+' · '+feedback.qualityLabel;$('[data-inspector-command-error]',panel).textContent=feedback.commandError;}}
        }
      }
      for(const edge of rung.edges){const result=live.get(map.edges?.[edge.id]);$$('.network-wire[data-wire-id]',canvas).filter(el=>el.dataset.wireId===edge.id).forEach(el=>el.classList.toggle('energized',!!e.runtime.running&&result?.valid===true&&result.value===true));}
    }
    e.updateDeviceParameters();
  }
}
