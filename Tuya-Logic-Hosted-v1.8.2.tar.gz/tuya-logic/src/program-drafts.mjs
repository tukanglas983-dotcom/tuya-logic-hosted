import {randomUUID} from 'node:crypto';
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i;
const types=new Set(['INPUT','VIRTUAL','CONST','GT','GTE','LT','LTE','EQ','NEQ','AND','OR','NOT','XOR','NAND','NOR','TON','TOF','PULSE','TONR','BLINK','R_TRIG','F_TRIG','LATCH','SR','COUNTER','CTD','CTUD','ADD','SUB','MUL','DIV','MOD','ABS','MIN','MAX','CLAMP','SELECT','SCHEDULE','OUTPUT']);
export const DRAFT_LIMITS=Object.freeze({maxDrafts:20,maxDraftBytes:131072,maxCollectionBytes:524288,maxProgramsBytes:2097152});
const reject=(status,message,code='DRAFT_INVALID')=>{throw Object.assign(new Error(message),{status,code});};
const text=(value,max,label,empty=false)=>{if(typeof value!=='string'||(!empty&&!value.trim())||value.length>max)reject(400,label+' must contain '+(empty?'0':'1')+'–'+max+' characters.');return value;};
const array=(value,max,label)=>{if(!Array.isArray(value)||value.length>max)reject(400,label+' must be an array of at most '+max+' items.');return value;};
function jsonData(value,depth=0,budget={count:0}){
  if(depth>24||++budget.count>30000)reject(400,'The draft structure is too complex.');
  if(value===null||typeof value==='boolean')return;
  if(typeof value==='string'){if(value.length>4000||value.includes('\0'))reject(400,'Draft text must be at most 4000 characters and contain no null characters.');return;}
  if(typeof value==='number'){if(!Number.isFinite(value))reject(400,'Draft numbers must be finite.');return;}
  if(Array.isArray(value)){array(value,2048,'Draft collection');for(const item of value)jsonData(item,depth+1,budget);return;}
  if(!plain(value)||![Object.prototype,null].includes(Object.getPrototypeOf(value)))reject(400,'Drafts must contain plain JSON data.');
  const keys=Object.keys(value);if(keys.length>1024)reject(400,'The draft has too many fields.');
  for(const key of keys){if(['__proto__','prototype','constructor'].includes(key)||key.length>160)reject(400,'Unsupported draft field.');jsonData(value[key],depth+1,budget);}
}
function unique(items,label,maxId=80){const used=new Set();for(const item of items){if(!plain(item))reject(400,'Invalid '+label+'.');text(item.id,maxId,label+' ID');if(used.has(item.id))reject(400,'Duplicate '+label+' ID.');used.add(item.id);}}
function position(value){if(!plain(value)||!['x','y'].every(key=>typeof value[key]==='number'&&Number.isFinite(value[key])&&Math.abs(value[key])<=100000))reject(400,'Draft positions require finite coordinates within the canvas limits.');}
function block(node){if(!types.has(node.type))reject(400,'Unknown draft block type.');if(node.inputs!==undefined)for(const input of array(node.inputs,100,'Block inputs'))text(input,80,'Input reference',true);if(node.params!==undefined&&!plain(node.params))reject(400,'Block parameters must be an object.');for(const axis of ['x','y'])if(node[axis]!==undefined&&(typeof node[axis]!=='number'||Math.abs(node[axis])>100000))reject(400,'Invalid block position.');}
export function validateDraftProgram(program,editorMode){
  if(!plain(program))reject(400,'Provide a program draft.');jsonData(program);
  if(!['ladder','fbd'].includes(editorMode))reject(400,'Choose Ladder or Function Block Diagram.');
  for(const key of Object.keys(program))if(!['id','name','nodes','ladder','draft','networkMap'].includes(key))reject(400,'Unsupported program draft field.');
  if(program.id!==undefined)text(program.id,80,'Program ID');if(program.name!==undefined)text(program.name,160,'Program name',true);
  const nodes=array(program.nodes,512,'Program blocks');unique(nodes,'block');nodes.forEach(block);
  if(editorMode==='ladder'&&!program.ladder)reject(400,'A Ladder draft must include its ladder document.');
  if(program.ladder!==undefined){
    const ladder=program.ladder;if(!plain(ladder)||![1,2].includes(ladder.version))reject(400,'Unsupported Ladder draft version.');
    unique(array(ladder.tags,512,'I/O tags'),'tag',24);const rungs=array(ladder.rungs,64,'Ladder rungs');unique(rungs,'rung',24);let count=0,edges=0;
    for(const rung of rungs){
      if(rung.name!==undefined)text(rung.name,160,'Rung name',true);
      if(ladder.version===2){
        const elements=array(rung.nodes,512,'Rung elements'),wires=array(rung.edges,2048,'Rung wires');unique(elements,'element',24);unique(wires,'wire',24);count+=elements.length;edges+=wires.length;
        for(const node of elements){if(!['rail','junction','contact','coil','block'].includes(node.nodeType))reject(400,'Unknown Ladder element type.');position(node.position);if(node.nodeType==='block')block(node);if(node.nodeType==='contact'&&node.kind!==undefined&&!['NO','NC','COMPARE'].includes(node.kind))reject(400,'Unknown contact type.');}
        for(const wire of wires){for(const endpoint of [wire.from,wire.to]){if(!plain(endpoint))reject(400,'A wire needs endpoint objects.');text(endpoint.nodeId,24,'Wire endpoint',true);text(endpoint.port,40,'Wire port',true);}if(wire.waypoints!==undefined)for(const point of array(wire.waypoints,128,'Wire points'))position(point);}
      }else{
        const branches=array(rung.branches,16,'Parallel branches');unique(branches,'branch',24);for(const branch of branches){const contacts=array(branch.contacts,32,'Contacts');unique(contacts,'contact',24);count+=contacts.length;for(const contact of contacts)if(contact.kind!==undefined&&!['NO','NC','COMPARE'].includes(contact.kind))reject(400,'Unknown contact type.');}
        const blocks=rung.blocks===undefined?[]:array(rung.blocks,512,'Function blocks');unique(blocks,'function',24);blocks.forEach(block);count+=blocks.length;if(rung.coil!==undefined&&rung.coil!==null&&!plain(rung.coil))reject(400,'Invalid output draft.');
      }
    }
    if(count>512||edges>2048)reject(400,'A Ladder draft supports at most 512 elements and 2048 wires.');
  }
  const copy=JSON.parse(JSON.stringify(program));if(Buffer.byteLength(JSON.stringify(copy))>DRAFT_LIMITS.maxDraftBytes)reject(413,'This draft exceeds the 128 KiB size limit.','DRAFT_LIMIT');return copy;
}
export function draftCollection(programs){
  if(programs.drafts===undefined)return [];
  if(!Array.isArray(programs.drafts)||programs.drafts.length>DRAFT_LIMITS.maxDrafts)reject(503,'The saved draft library is invalid.','DRAFT_STORAGE');
  for(const item of programs.drafts)if(!plain(item)||!uuid.test(item.id)||!uuid.test(item.revision)||!['demo','live'].includes(item.mode)||!['ladder','fbd'].includes(item.editorMode)||typeof item.name!=='string'||!item.name.trim()||item.name.length>160||!Number.isFinite(Date.parse(item.updatedAt))||!plain(item.program))reject(503,'The saved draft library is invalid.','DRAFT_STORAGE');
  if(new Set(programs.drafts.map(item=>item.id)).size!==programs.drafts.length)reject(503,'The saved draft library has duplicate IDs.','DRAFT_STORAGE');
  return programs.drafts;
}
export function listDrafts(programs,mode){return draftCollection(programs).filter(item=>item.mode===mode).map(({program,...summary})=>({...summary})).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt)||a.id.localeCompare(b.id));}
export function findDraft(programs,mode,id){const draft=draftCollection(programs).find(item=>item.id===id&&item.mode===mode);if(!uuid.test(id)||!draft)reject(404,'This draft is not available in the current connection mode.','DRAFT_NOT_FOUND');return JSON.parse(JSON.stringify(draft));}
export function draftRevision(expected,current){
  if(typeof expected!=='string'||!expected)reject(409,'Reload this draft before changing it.','DRAFT_CONFLICT');
  if(expected!==current&&expected!=='"'+current+'"')reject(409,'This draft changed on another client. Your local edits have been kept. Reload the saved draft or save a new copy.','DRAFT_CONFLICT');
}
function payloadBytes(value){
  let expansion=0;const json=JSON.stringify(value,(_key,item)=>{if(typeof item==='number'){const match=String(item).match(/e([+-]?\d+)$/i);if(match)expansion+=Math.abs(Number(match[1]))+20;}return item;},1);
  // Pretty JSON upper-bounds JSONB separators; allowance covers expanded SQL numeric exponents.
  return Buffer.byteLength(json)+expansion;
}
export function assertProgramsCapacity(programs){if(payloadBytes(programs)>DRAFT_LIMITS.maxProgramsBytes)reject(413,'The saved programs and drafts exceed shared storage capacity. Remove an unused draft or reduce the program size.','DRAFT_LIMIT');}
export function changeDraft(programs,mode,{id,name,editorMode,program,revision,remove=false}={}){
  const collection=draftCollection(programs),existing=id?findDraft(programs,mode,id):null;if(existing)draftRevision(revision,existing.revision);
  let draft=null;
  if(remove){if(!existing)reject(404,'Draft not found.','DRAFT_NOT_FOUND');}
  else{
    text(name,160,'Draft name');if(!existing&&collection.length>=DRAFT_LIMITS.maxDrafts)reject(409,'The library holds at most 20 drafts. Delete an unused draft before saving another.','DRAFT_LIMIT');
    draft={id:existing?.id||randomUUID(),name:name.trim(),updatedAt:new Date().toISOString(),revision:randomUUID(),editorMode,mode,program:validateDraftProgram(program,editorMode)};
  }
  const drafts=collection.filter(item=>item.id!==existing?.id);if(draft)drafts.push(draft);
  if(payloadBytes(drafts)>DRAFT_LIMITS.maxCollectionBytes)reject(413,'The draft library exceeds its 512 KiB capacity. Delete an unused draft or reduce this draft.','DRAFT_LIMIT');
  const next={...programs,drafts};assertProgramsCapacity(next);return {programs:next,draft};
}
