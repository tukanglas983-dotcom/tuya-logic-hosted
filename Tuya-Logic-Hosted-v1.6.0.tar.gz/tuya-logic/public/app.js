import {propertyLabel,propertyQuality} from './property-labels.js';
import {createDemoLadder, compileLadder, graphToLadder} from './ladder.js';
import {LadderEditor} from './ladder-ui.js';
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clone = value => JSON.parse(JSON.stringify(value));
const icons = {
  blocks:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><path d="M17 3v5a3 3 0 0 1-3 3H7v10m0-5h7"/>',
  plug:'<path d="M8 3v5m8-5v5M6 8h12v3a6 6 0 0 1-6 6v4M6 8H4m14 0h2"/>',
  activity:'<path d="M2 12h5l3-8 4 16 3-8h5"/>',
  settings:'<path d="m10 3-1 3-3 1-2 3 2 3v3l3 2 3-1 3 1 3-2v-3l2-3-2-3-3-1-1-3z"/><circle cx="12" cy="11" r="3"/>',
  logout:'<path d="M9 3H4v18h5m5-14 5 5-5 5m-7-5h12"/>',
  refresh:'<path d="M20 7v5h-5M4 17v-5h5m-4-4a8 8 0 0 1 13-3l2 3M4 16l2 3a8 8 0 0 0 13-3"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  power:'<path d="M12 2v9m-5-6a8 8 0 1 0 10 0"/>',
  flask:'<path d="M9 3h6m-5 0v6l-6 10a1.5 1.5 0 0 0 1 2h14a1.5 1.5 0 0 0 1-2L14 9V3M8 14h8"/>',
  save:'<path d="M4 3h13l4 4v14H3V3h1m3 0v6h10V3M7 21v-8h10v8"/>',
  play:'<path d="m7 3 14 9-14 9z"/>',
  stop:'<rect x="5" y="5" width="14" height="14" rx="1"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  shield:'<path d="m12 3 8 3v6c0 4-8 9-8 9s-8-5-8-9V6z"/><path d="m8 12 3 3 5-6"/>',
  sliders:'<path d="M4 6h5m4 0h7M4 12h11m4 0h1M4 18h1m4 0h11M9 3v6m6 0v6M5 15v6"/>',
  cursor:'<path d="m4 3 15 10-7 1-4 7z"/>',
  cloud:'<path d="M5 18a4 4 0 0 1-1-8 7 7 0 0 1 13-2 5 5 0 0 1 1 10z"/>',
  server:'<rect x="3" y="3" width="18" height="7" rx="2"/><rect x="3" y="14" width="18" height="7" rx="2"/><path d="M7 6.5h.01M7 17.5h.01M12 6.5h5M12 17.5h5"/>',
  trash:'<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',
  arrow:'<path d="M4 12h16m-6-6 6 6-6 6"/>'
};
const icon = name => `<svg viewBox="0 0 24 24" aria-hidden="true">${icons[name] || icons.blocks}</svg>`;
function fillIcons(root = document) { $$('[data-icon]', root).forEach(el => { el.innerHTML = icon(el.dataset.icon); }); }
fillIcons();

const types = {
  INPUT:{label:'Device input',description:'Read a device property',group:'input',category:'I/O',icon:'plug',arity:0},
  VIRTUAL:{label:'Virtual input',description:'Force a switch or numeric value during tests',group:'input',category:'Virtual',icon:'flask',arity:0},
  CONST:{label:'Constant',description:'Number, boolean, or text',group:'input',category:'I/O',icon:'sliders',arity:0},
  OUTPUT:{label:'Device output',description:'Action, coil, pulse, or dynamic value',group:'output',category:'I/O',icon:'power',arity:1},
  GT:{label:'Greater than',description:'A > B',group:'logic',category:'Compare',arity:2},
  GTE:{label:'Greater or equal',description:'A ≥ B',group:'logic',category:'Compare',arity:2},
  LT:{label:'Less than',description:'A < B',group:'logic',category:'Compare',arity:2},
  LTE:{label:'Less or equal',description:'A ≤ B',group:'logic',category:'Compare',arity:2},
  EQ:{label:'Equal',description:'A = B',group:'logic',category:'Compare',arity:2},
  NEQ:{label:'Not equal',description:'A ≠ B',group:'logic',category:'Compare',arity:2},
  AND:{label:'All true',description:'TRUE when all inputs are TRUE',group:'logic',category:'Logic',arity:2,variable:true},
  OR:{label:'Any true',description:'TRUE when any input is TRUE',group:'logic',category:'Logic',arity:2,variable:true},
  NOT:{label:'Invert',description:'Invert a boolean input',group:'logic',category:'Logic',arity:1},
  XOR:{label:'Exclusive OR',description:'TRUE for an odd number of TRUE inputs',group:'logic',category:'Logic',arity:2,variable:true},
  NAND:{label:'Not all true',description:'Inverted AND output',group:'logic',category:'Logic',arity:2,variable:true},
  NOR:{label:'None true',description:'Inverted OR output',group:'logic',category:'Logic',arity:2,variable:true},
  R_TRIG:{label:'Rising edge',description:'One scan on FALSE → TRUE',group:'logic',category:'Logic',arity:1},
  F_TRIG:{label:'Falling edge',description:'One scan on TRUE → FALSE',group:'logic',category:'Logic',arity:1},
  SELECT:{label:'Select value',description:'Choose a value with a boolean condition',group:'logic',category:'Logic',arity:3,ports:['Condition','Value when TRUE','Value when FALSE']},
  ADD:{label:'Add',description:'A + B',group:'logic',category:'Math',arity:2},
  SUB:{label:'Subtract',description:'A − B',group:'logic',category:'Math',arity:2},
  MUL:{label:'Multiply',description:'A × B',group:'logic',category:'Math',arity:2},
  DIV:{label:'Divide',description:'A ÷ B · zero divisor is invalid',group:'logic',category:'Math',arity:2},
  MOD:{label:'Remainder',description:'A modulo B',group:'logic',category:'Math',arity:2},
  ABS:{label:'Absolute value',description:'Magnitude of a number',group:'logic',category:'Math',arity:1},
  MIN:{label:'Minimum',description:'Smallest input value',group:'logic',category:'Math',arity:2,variable:true},
  MAX:{label:'Maximum',description:'Largest input value',group:'logic',category:'Math',arity:2,variable:true},
  CLAMP:{label:'Clamp value',description:'Limit a value between MIN and MAX',group:'logic',category:'Math',arity:3,ports:['Value','Minimum','Maximum']},
  TON:{label:'On-delay timer',description:'Delay TRUE; FALSE resets the timer',group:'logic',category:'Timers',icon:'clock',arity:1},
  TOF:{label:'Off-delay timer',description:'Delay FALSE after input turns off',group:'logic',category:'Timers',icon:'clock',arity:1},
  PULSE:{label:'Pulse timer',description:'Timed pulse on a rising edge',group:'logic',category:'Timers',icon:'activity',arity:1},
  TONR:{label:'Retentive timer',description:'Accumulate enabled time until reset',group:'logic',category:'Timers',icon:'clock',arity:2,ports:['Enable','Reset']},
  BLINK:{label:'Blink',description:'Repeat ON and OFF while enabled',group:'logic',category:'Timers',icon:'activity',arity:1,ports:['Enable']},
  LATCH:{label:'Reset-dominant latch',description:'Store a boolean; RESET has priority',group:'logic',category:'Memory',arity:2,ports:['Set','Reset']},
  SR:{label:'Set-dominant latch',description:'Store a boolean; SET has priority',group:'logic',category:'Memory',arity:2,ports:['Set','Reset']},
  COUNTER:{label:'Up counter',description:'Count rising edges until reset',group:'logic',category:'Memory',arity:2,ports:['Count up','Reset']},
  CTD:{label:'Down counter',description:'Load preset, count down to zero',group:'logic',category:'Memory',arity:2,ports:['Count down','Load preset']},
  CTUD:{label:'Up/down counter',description:'Count both directions; reset to zero',group:'logic',category:'Memory',arity:3,ports:['Count up','Count down','Reset']}
};
let state = null;
let program = null;
let selected = null;
let dirty = false;
let currentView = 'studio';
let sceneData=null,sceneLoading=false,sceneRequest=0;
let session = {};
let stream = null;
let zoom = 1;
let dragging = false;
let lastDeviceSignature = '';
let lastLogSignature = '';
let lastProgramSignature = '';
let baseProgramRevision = null;
let programConflict = false;
let checkingSession = false;
let settingsInitialized = false;
let shuttingDown = false;
let stateFetchPending = null;
let demoSliderInitialized = false;
let editorMode = 'ladder';
let inspectorTab = 'instructions';
let watchTimer=null,watchBusy=false,lastWatchSignature='',lastWatchAt=0,watchEpoch=0,watchRetryAt=0;
const ladderEditor = new LadderEditor({container:$('#ladder-workspace'),inspector:$('#inspector-content'),toolbox:$('#ladder-toolbox'),types,onChange:()=>{dirty=true;if(ladderEditor.selection)setInspectorTab('properties');updateControls();scheduleDeviceWatch();},onInspector:view=>{setInspectorTab(view);updateControls();},onError:message=>toast(message,true),onMapping:()=>setEditorMode('io'),onVirtualInput:forceVirtualInput,onPhysicalInput:forcePhysicalInput});
async function forceVirtualInput(id,value) {
  if(!$('#offline-banner').hidden)throw new Error('Reconnect to the server before changing a virtual input.');
  if(!state?.runtime?.running || !['test','live-test'].includes(state.runtime.executionMode))throw new Error('Start Test Run or Live Test before forcing virtual inputs.');
  applyState(await post('/api/virtual-input',{id,value}));
}
async function forcePhysicalInput(payload) {
  if(!$('#offline-banner').hidden)throw new Error('Reconnect to the server before changing a device input.');
  if(!state?.runtime?.running || !['test','live-test'].includes(state.runtime.executionMode))throw new Error('Start Test Run or Live Test before forcing device inputs.');
  // The event stream supplies confirmed device values and command progress.
  // A delayed command reply must not overwrite newer reports or a later Stop.
  await post('/api/input-force',payload);
}
function watchedDeviceIds() {
  const ids=new Set(),known=new Set((state?.devices || []).map(d=>d.id));
  const add=id=>{if(known.has(id))ids.add(id);};
  if(editorMode!=='fbd'&&ladderEditor.ladder){
    const tags=new Map(ladderEditor.ladder.tags.map(tag=>[tag.id,tag]));
    const visit=value=>{if(!value||typeof value!=='object')return;for(const[key,item]of Object.entries(value)){if(key==='deviceId')add(item);else if(['tagId','valueTagId','resetTagId','downTagId'].includes(key))add(tags.get(item)?.deviceId);else visit(item);}};
    visit(ladderEditor.ladder.rungs);
  }else for(const node of program?.nodes || [])if(['INPUT','OUTPUT'].includes(node.type))add(node.params?.deviceId);
  return [...ids].sort();
}
function scheduleDeviceWatch() {
  if(watchTimer||watchBusy||Date.now()<watchRetryAt||!state||state.mode!=='live'||state.connection?.status!=='connected'||$('#shell').hidden||!$('#offline-banner').hidden)return;
  const signature=JSON.stringify(watchedDeviceIds());
  if(signature===lastWatchSignature&&Date.now()-lastWatchAt<45000)return;
  watchTimer=setTimeout(()=>{watchTimer=null;void syncDeviceWatch();},300);
}
async function syncDeviceWatch() {
  if(watchBusy||$('#shell').hidden||!$('#offline-banner').hidden)return;
  const deviceIds=watchedDeviceIds(),signature=JSON.stringify(deviceIds),generation=watchEpoch;
  watchBusy=true;
  // Refresh replies can overtake newer SSE events. Use the event stream for
  // device/program state; this request only renews the observation lease.
  try{await post('/api/devices/watch',{deviceIds});if(generation===watchEpoch){lastWatchSignature=signature;lastWatchAt=Date.now();watchRetryAt=0;}}
  catch(error){if(generation===watchEpoch&&!$('#shell').hidden){watchRetryAt=Date.now()+5000;if(error.status!==409)toast(`Device feedback: ${error.message}`,true);}}
  finally{watchBusy=false;if(generation===watchEpoch)scheduleDeviceWatch();}
}
document.addEventListener('keydown', event => {
  if ($('#shell').hidden || currentView !== 'studio' || !['ladder','io'].includes(editorMode)) return;
  ladderEditor.handleKeyDown(event);
});
const conflictBanner=document.createElement('div');
conflictBanner.id='program-conflict';conflictBanner.className='notice warning';conflictBanner.hidden=true;conflictBanner.setAttribute('role','alert');
conflictBanner.style.cssText='margin:12px;display:flex;flex-wrap:wrap;gap:10px;align-items:center';
conflictBanner.innerHTML='<span style="flex:1 1 230px">Another client changed the saved program. Your draft is preserved. Export it before reloading the server version.</span><button id="export-draft" class="button secondary small">Export draft</button><button id="reload-program" class="button secondary small">Reload server</button>';
$('.editor-toolbar').after(conflictBanner);

function loadLadderRepresentation() {
  let ladder=program?.ladder || null;
  if(!ladder && program)try{ladder=graphToLadder(program,state?.devices || []);}catch{}
  ladderEditor.refresh(state?.devices || [],state?.runtime || {});
  ladderEditor.load(ladder);
  if(!ladder)editorMode='fbd';
  else if(editorMode==='fbd' && !program.nodes.length)editorMode='ladder';
  setEditorMode(editorMode,true);
}
function setEditorMode(mode,loading=false) {
  if(mode!=='fbd'&&!ladderEditor.ladder){
    if(!loading)toast('This graph cannot be converted automatically. Create a new Ladder program to start a diagram.',true);
    mode='fbd';
  }
  if(mode==='fbd'&&editorMode!=='fbd'&&ladderEditor.ladder&&!loading){
    try{program=compileLadder(ladderEditor.serialize(),{id:program.id,name:$('#program-name').value});positionMissingNodes();renderNodes();}catch(error){toast(`Complete the ladder diagram first: ${error.message}`,true);return;}
  }
  editorMode=mode;
  updateEditorChrome();
  for(const name of ['ladder','io','fbd']){const button=$(`#mode-${name}`);button.classList.toggle('active',name===mode);button.setAttribute('aria-selected',String(name===mode));}
  $('#ladder-workspace').hidden=mode==='fbd';
  for(const selector of ['.canvas-actions','.canvas-scroll','.canvas-footer'])$(selector).hidden=mode!=='fbd';
  setInspectorTab(mode==='ladder'&&ladderEditor.selection?'properties':inspectorTab);
  if(mode==='fbd')renderInspector();else ladderEditor.setMode(mode);
  updateControls();
}
function updateEditorChrome() {
  document.body.classList.toggle('studio-editor-mode',currentView==='studio'&&editorMode==='ladder');
}
function setInspectorTab(tab) {
  inspectorTab=tab==='properties'?'properties':'instructions';
  const ladder=editorMode==='ladder';
  $('#inspector-tabs').hidden=!ladder;
  $('#ladder-toolbox').hidden=!ladder||inspectorTab!=='instructions';
  $('#inspector-content').hidden=ladder&&inspectorTab!=='properties';
  $('#inspector-content').setAttribute('aria-labelledby',ladder?'inspector-tab-properties':'inspector-title');
  const title=$('.inspector .panel-title h2');title.id='inspector-title';
  title.textContent=editorMode==='io'?'I/O tag details':editorMode==='fbd'?'Block details':inspectorTab==='instructions'?'Instructions':'Element properties';
  for(const name of ['instructions','properties']){
    const button=$(`#inspector-tab-${name}`);button.classList.toggle('active',name===inspectorTab);button.setAttribute('aria-selected',String(name===inspectorTab));
  }
}
for(const name of ['instructions','properties'])$(`#inspector-tab-${name}`).addEventListener('click',()=>setInspectorTab(name));

function toast(message, error = false) {
  const el = document.createElement('div');
  el.className = `toast${error ? ' error' : ''}`;
  el.textContent = message;
  const limit = innerWidth < 520 ? 1 : 2;
  while ($('#toasts').children.length >= limit) $('#toasts').firstElementChild.remove();
  $('#toasts').append(el);
  setTimeout(() => el.remove(), error ? 8000 : 4200);
}
async function api(path, options = {}) {
  const response = await fetch(path, {credentials:'same-origin', ...options, headers:{'Content-Type':'application/json', ...(options.headers || {})}});
  let data;
  try { data = await response.json(); } catch { data = {}; }
  if (!response.ok) {
    if (response.status === 401 && path !== '/api/login') { await showAuth(); }
    const error=new Error(data.error || `Request failed (${response.status}).`);error.status=response.status;error.code=data.code;throw error;
  }
  return data;
}
const post = (path, body = {}) => api(path, {method:'POST', body:JSON.stringify(body)});
async function action(button, callback) {
  if (button?.dataset.busy === 'true') return;
  const disabled = button?.disabled;
  if (button) { button.disabled = true; button.dataset.busy = 'true'; }
  try { return await callback(); }
  catch (error) { toast(error.message || 'Something went wrong. Please try again.', true); }
  finally { if (button) delete button.dataset.busy; if (button?.isConnected) button.disabled = disabled || false; updateControls(); }
}
async function loadState() {
  if (stateFetchPending) return stateFetchPending;
  stateFetchPending = api('/api/state').then(applyState).finally(() => { stateFetchPending = null; });
  return stateFetchPending;
}
async function showAuth() {
  sceneRequest++;sceneData=null;sceneLoading=false;
  watchEpoch++;clearTimeout(watchTimer);watchTimer=null;lastWatchSignature='';lastWatchAt=0;watchRetryAt=0;
  stream?.close(); stream = null;
  try { session = await api('/api/session'); }
  catch { session = {authenticated:false}; }
  $('#shell').hidden = true;
  $('#auth').hidden = false;
  const setup = !!session.setupRequired;
  $('#auth-title').textContent = setup ? 'Set up your studio' : 'Sign in to your studio';
  $('#auth-description').textContent = setup ? 'Create a password to secure access to your app and server.' : 'Enter your server password to continue.';
  $('#auth-submit').innerHTML = `${setup ? 'Create workspace' : 'Sign in to your studio'} <span aria-hidden="true">→</span>`;
  $('#auth-password').autocomplete = setup ? 'new-password' : 'current-password';
  $('#auth-password').minLength = setup ? 12 : 1;
  $('#confirm-label').hidden = !setup;
  $('#auth-confirm').required = setup;
  $('#auth-submit').disabled = setup && !session.local;
  $('#auth-error').textContent = setup && !session.local ? 'Complete first-time setup in a browser on the server laptop at http://localhost:3210.' : '';
}
async function openStudio() {
  $('#auth').hidden = true;
  $('#shell').hidden = false;
  shuttingDown = false;
  settingsInitialized = false;
  await loadState();
  connectEvents();
}
function connectEvents() {
  stream?.close();
  stream = new EventSource('/api/events');
  stream.addEventListener('state', event => {
    try { applyState(JSON.parse(event.data)); } catch (error) { console.warn('Invalid state update:', error.message); }
  });
  stream.onopen = () => setOffline(false);
  stream.onerror = async () => {
    setOffline(true);
    if (checkingSession || shuttingDown) return;
    checkingSession = true;
    try { const s = await api('/api/session'); if (!s.authenticated) await showAuth(); }
    catch {} finally { checkingSession = false; }
  };
}
function setOffline(offline) {
  if(!offline&&!$('#offline-banner').hidden){lastWatchAt=0;watchRetryAt=0;}
  $('#offline-banner').hidden = !offline;
  $('#server-dot').classList.toggle('error', offline);
  $('#server-label').textContent = offline ? 'Server disconnected' : 'Server connected';
  if (offline) { $('#footer-status').textContent = 'Server connection lost'; $('#footer-dot').className = 'status-dot error'; }
  updateControls();
}
function applyState(next) {
  if (!next || !next.program || !Array.isArray(next.devices)) return;
  if (state && state.mode !== next.mode) {demoSliderInitialized = false;sceneRequest++;sceneData=null;sceneLoading=false;}
  state = next;
  setOffline(false);
  const signature = JSON.stringify(next.program);
  if (!program || (!dirty && !dragging && (signature !== lastProgramSignature || next.programRevision !== baseProgramRevision))) {
    program = clone(next.program);
    lastProgramSignature = signature;
    baseProgramRevision = next.programRevision || null;
    programConflict = false;
    selected = program.nodes.some(n => n.id === selected) ? selected : program.nodes[0]?.id || null;
    positionMissingNodes();
    $('#program-name').value = program.name;
    renderNodes();
    renderInspector();
    loadLadderRepresentation();
  }
  $('#mode-badge').textContent = next.runtime?.executionMode==='live-test' ? 'LIVE TEST · REAL DEVICES' : next.runtime?.executionMode==='test' ? 'TEST RUN' : next.mode === 'demo' ? 'SIMULATION' : 'TUYA LIVE';
  $('#mode-badge').classList.toggle('amber', next.mode === 'demo' || ['test','live-test'].includes(next.runtime?.executionMode));
  $('#demo-panel').hidden = next.mode !== 'demo';
  if (next.mode === 'demo' && !demoSliderInitialized) {
    const device = next.devices.find(d => d.id.startsWith('demo')) || next.devices[0];
    const prop = device?.properties?.cur_current;
    if (prop && Number.isFinite(Number(prop.value))) {
      const current = Number(prop.value) / (10 ** Number(prop.scale || 0)) / 1000;
      $('#demo-current').value = String(current);
      $('#demo-current-value').textContent = `${current.toFixed(2)} A`;
      demoSliderInitialized = true;
    }
  }
  $('#nav-device-count').textContent = next.devices.length;
  renderTelemetry();
  ladderEditor.refresh(next.devices,next.runtime);
  renderLogs();
  renderDevices();
  renderSettings();
  updateControls();
  scheduleDeviceWatch();
}
function hasVirtualInputs() {
  if(editorMode==='fbd' || !ladderEditor.ladder)return program?.nodes?.some(n=>n.type==='VIRTUAL');
  const virtualIds=new Set(ladderEditor.ladder.tags.filter(t=>t.source==='virtual').map(t=>t.id));
  const references=value=>value && typeof value==='object' && Object.entries(value).some(([key,item])=>['tagId','valueTagId','resetTagId','downTagId'].includes(key)?virtualIds.has(item):references(item));
  return references(ladderEditor.ladder.rungs);
}
function updateControls() {
  if (!state) return;
  const running = !!state.runtime?.running;
  const offline = !$('#offline-banner').hidden;
  const testing = running && state.runtime.executionMode==='test';
  const liveTesting = running && state.runtime.executionMode==='live-test';
  const forcing = testing || liveTesting;
  const hasVirtual = hasVirtualInputs();
  const hasProgram = editorMode!=='fbd' && ladderEditor.ladder ? !!ladderEditor.ladder.rungs.length : !!program?.nodes?.length;
  const conflict=dirty&&(programConflict||(baseProgramRevision&&state.programRevision&&baseProgramRevision!==state.programRevision));
  conflictBanner.hidden=!conflict;
  $('#reload-program').disabled=offline;
  $('#run-program').hidden = running;
  $('#test-program').hidden = running;
  $('#live-test-program').hidden = running || state.mode!=='live';
  $('#stop-program').hidden = !running;
  $('#run-program').disabled = offline || !hasProgram || hasVirtual;
  $('#run-program').title = hasVirtual ? 'Use Test Run for simulated outputs or Live Test for real device outputs with virtual inputs.' : state.mode==='live' ? 'Run the program on real devices' : 'Run the demo devices';
  $('#test-program').disabled = offline || !hasProgram;
  $('#live-test-program').disabled = offline || !hasProgram || state.connection?.status!=='connected';
  $('#stop-program').disabled = offline;
  $('#save-program').disabled = running || offline || !dirty;
  $('#add-node').disabled = running || offline;
  $('#fit-canvas').disabled = running;
  $('#program-name').disabled = running;
  $('#import-program').disabled = running || offline;
  $('#new-program').disabled = running || offline;
  $('#settings-save').disabled = running || offline || !session.local;
  $('#settings-mode').disabled = running || !session.local;
  $('#refresh-scenes').disabled = offline || sceneLoading;
  $('#api-key').disabled = running || !session.local;
  $('#save-status').textContent = conflict ? 'Draft conflicts with server' : dirty ? 'Unsaved changes' : liveTesting ? 'Live Test · controls real devices' : testing ? 'Test Run · outputs simulated' : running ? 'Running on server' : 'Saved on server';
  $('#save-status').classList.toggle('dirty', dirty);
  $$('#inspector-content input, #inspector-content select, #inspector-content button').forEach(el => { if(!el.hasAttribute('data-virtual-force')&&!el.hasAttribute('data-physical-force'))el.disabled = running; });
  $$('[data-virtual-force]').forEach(el => { el.dataset.virtualBlocked=String(offline || !forcing); el.disabled = offline || !forcing || el.dataset.busy==='true' || el.dataset.virtualUnavailable==='true'; });
  $$('[data-physical-force]').forEach(el => { el.dataset.physicalBlocked=String(offline || !forcing); el.disabled = offline || !forcing || el.dataset.busy==='true' || el.dataset.physicalUnavailable==='true'; });
  $$('#device-list .property-command button').forEach(el => { el.disabled = running || el.dataset.offline === 'true'; el.title = running ? 'Stop the program before manual control.' : ''; });
  $$('#device-list .simulation-command button').forEach(el => { el.disabled = offline || state.mode !== 'demo'; });
  $$('[data-busy="true"]').forEach(el => { el.disabled = true; });
  $('#program-hint').textContent = liveTesting ? 'Live Test sends commands to real devices. Check Device feedback on the coil. Stop clears simulated forces and resets virtual inputs to their initial values; devices retain their last state.' : testing ? 'Test Run: force inputs in Force I/O; outputs are simulated. Device feedback shows the real reported value separately.' : running ? 'Program running on server. Stop it before editing.' : hasVirtual ? 'Test Run simulates outputs. Live Test controls real devices. Virtual inputs start at their configured initial values.' : 'Test Run previews output actions. Run controls the selected devices.';
}
function markDirty() { dirty = true; if(editorMode==='fbd' && program?.ladder){delete program.ladder;ladderEditor.ladder=null;} updateControls();scheduleDeviceWatch(); }
function selectView(view) {
  if (!['studio','devices','scenes','activity','settings'].includes(view)) return;
  currentView = view;
  updateEditorChrome();
  $$('.view').forEach(el => { el.hidden = el.id !== `view-${view}`; });
  $$('.nav-item').forEach(el => el.classList.toggle('active', el.dataset.view === view));
  $('#page-name').textContent = {studio:'Logic studio',devices:'Devices',scenes:'Scenes & Automations',activity:'Activity',settings:'Settings'}[view];
  if (view === 'devices') renderDevices(true);
  if (view === 'scenes') void loadSceneCatalog();
  if (view === 'activity') renderLogs(true);
  if (view === 'settings') renderSettings();
  window.scrollTo({top:0, behavior:'smooth'});
}
function renderSceneCatalog(){
  const data=sceneData,status=$('#scenes-status');
  $('#refresh-scenes').disabled=sceneLoading || !$('#offline-banner').hidden;
  $('#scene-home').disabled=sceneLoading || !data?.homes?.length;
  if(!data){status.textContent=sceneLoading?'Checking your Tuya connection…':'Scene data has not been loaded.';return;}
  $('#scene-home').innerHTML=data.homes?.length?data.homes.map(home=>`<option value="${esc(home.id)}" ${String(home.id)===String(data.homeId)?'selected':''}>${esc(home.name || home.id)}</option>`).join(''):'<option value="">No home loaded</option>';
  status.className=`notice${['unavailable','partial'].includes(data.status)?' warning':''}`;
  status.textContent=data.reason || (data.status==='available'?'Saved scenes loaded. This view does not execute or change them.':data.status==='demo'?'Switch to Tuya Live to read scenes from your phone app.':'Scene access is unavailable through the current connection.');
  if(data.checkedAt)status.append(document.createTextNode(` Last checked ${new Date(data.checkedAt).toLocaleTimeString()}.`));
  if(data.status==='demo'){$('#scenes-catalog').innerHTML='';return;}
  $('#scenes-catalog').innerHTML=[['scenes','Tap-to-Run'],['automations','Automations']].map(([key,title])=>{
    const group=data[key],available=group?.status==='available';
    const items=available && Array.isArray(group.items)?group.items:[];
    return `<section class="panel" style="padding:24px;min-width:0"><h2>${title} <small>${available?items.length:'—'}</small></h2>${!available?`<p>${esc(group?.reason || 'Not loaded. The current connection cannot read this list.')}</p><p><a href="https://developer.tuya.com/en/docs/developer/apply-cloud-api-key?id=Kff30z8sv62ah" target="_blank" rel="noopener noreferrer">Tuya Cloud connection requirements ↗</a></p>`:!items.length?'<p>No saved items were found in this home.</p>':items.map(item=>`<article style="padding:16px 0;border-top:1px solid var(--line)"><strong>${esc(item.name || 'Unnamed rule')}</strong>${typeof item.enabled==='boolean'?` <span class="badge">${item.enabled?'Enabled':'Disabled'}</span>`:''}${item.conditions!==undefined||item.actions!==undefined?`<details style="margin-top:12px"><summary>Conditions and actions</summary><pre style="white-space:pre-wrap;overflow-wrap:anywhere;max-height:320px;overflow:auto">${esc(JSON.stringify({...(item.conditions!==undefined?{conditions:item.conditions}:{}),...(item.actions!==undefined?{actions:item.actions}:{})},null,2))}</pre></details>`:''}</article>`).join('')}</section>`;
  }).join('');
}
async function loadSceneCatalog({refresh=false,homeId}={}){
  if(sceneLoading)return;
  const generation=++sceneRequest;
  sceneLoading=true;renderSceneCatalog();
  try{
    const params=new URLSearchParams();
    if(homeId)params.set('homeId',homeId);
    if(refresh)params.set('refresh','1');
    const result=await api('/api/scenes'+(params.size?'?'+params:''));
    if(generation===sceneRequest)sceneData=result;
  }catch(error){
    if(generation===sceneRequest)sceneData={status:'unavailable',homes:[],reason:error.message,scenes:{status:'unavailable'},automations:{status:'unavailable'}};
  }finally{if(generation===sceneRequest){sceneLoading=false;renderSceneCatalog();}}
}
$('#refresh-scenes').addEventListener('click',()=>void loadSceneCatalog({refresh:true,homeId:$('#scene-home').value}));
$('#scene-home').addEventListener('change',event=>void loadSceneCatalog({homeId:event.target.value}));
$$('[data-view]').forEach(el => el.addEventListener('click', () => selectView(el.dataset.view)));
window.addEventListener('beforeunload', event => { if (dirty) { event.preventDefault(); event.returnValue = ''; } });

function positionMissingNodes() {
  if (!program?.nodes) return;
  const columns = new Map();
  const ranks = new Map();
  function rank(node, path = new Set()) {
    if (ranks.has(node.id)) return ranks.get(node.id);
    if (path.has(node.id)) return 0;
    const nextPath = new Set(path).add(node.id);
    const upstream = (node.inputs || []).map(id => program.nodes.find(n => n.id === id)).filter(Boolean);
    const r = upstream.length ? Math.max(...upstream.map(n => rank(n, nextPath))) + 1 : 0;
    ranks.set(node.id, r); return r;
  }
  for (const node of program.nodes) {
    const col = rank(node);
    const row = columns.get(col) || 0;
    columns.set(col, row + 1);
    if (!Number.isFinite(node.x)) node.x = 35 + col * 219;
    if (!Number.isFinite(node.y)) node.y = 48 + row * 194 + (col ? 60 : 0);
  }
}
function arrangeNodes() {
  for (const node of program.nodes) { delete node.x; delete node.y; }
  positionMissingNodes(); markDirty(); renderNodes();
  const width = Math.max(520, ...program.nodes.map(n => n.x + 211));
  zoom = Math.max(.45, Math.min(1, ($('#canvas-scroll').clientWidth - 12) / width));
  resizeCanvas();
}
function resizeCanvas() {
  if (!program) return;
  const width = Math.max(540, ...program.nodes.map(n => n.x + 211));
  const height = Math.max(365, ...program.nodes.map(n => n.y + 215));
  $('#canvas-inner').style.width = `${width}px`;
  $('#canvas-inner').style.height = `${height}px`;
  $('#canvas-inner').style.transform = `scale(${zoom})`;
  $('#canvas-size').style.width = `${width * zoom}px`;
  $('#canvas-size').style.height = `${height * zoom}px`;
  $('#zoom-label').textContent = `${Math.round(zoom * 100)}%`;
  drawWires();
}
function nodeDescription(node) {
  const p = node.params || {};
  if (node.type === 'INPUT' || node.type === 'OUTPUT') {
    const device = state?.devices.find(d => d.id === p.deviceId);
    if (node.type === 'OUTPUT') {
      const mode = p.mode === 'value' ? 'Dynamic value · enabled' : p.mode === 'pulse' ? `Pulse ${fmt((p.durationMs || 1000) / 1000)} s · ${p.value ? 'ON → OFF' : 'OFF → ON'}` : p.mode === 'follow' ? 'Continuous · follow input' : `Once · ${typeof p.value === 'boolean' ? p.value ? 'ON' : 'OFF' : String(p.value)}`;
      return `${mode} · ${p.code || 'select property'}`;
    }
    return `${device?.name || p.deviceId || 'Select device'} · ${p.code || 'select property'}`;
  }
  if (['TON','TOF','PULSE','TONR'].includes(node.type)) return `Duration ${(Number(p.durationMs) || 0) / 1000} seconds`;
  if (node.type === 'BLINK') return `ON ${(p.onMs || 1000)/1000} s / OFF ${(p.offMs || 1000)/1000} s`;
  if (node.type === 'CONST') return `Constant · ${typeof p.value === 'boolean' ? 'boolean' : typeof p.value === 'number' ? 'number' : 'text'}`;
  if (node.type === 'VIRTUAL') return `Virtual input · initial ${fmt(node.params.defaultValue ?? false)}${node.params.unit?' '+node.params.unit:''}`;
  if (['COUNTER','CTD','CTUD'].includes(node.type)) return `Preset ${p.preset ?? 1} counts`;
  return types[node.type]?.description || node.type;
}
function renderNodes() {
  if (!program) return;
  const container = $('#nodes'); container.replaceChildren();
  $('#empty-program').hidden = program.nodes.length > 0;
  for (const node of program.nodes) {
    const meta = types[node.type] || types.AND;
    const card = document.createElement('div');
    card.className = `node ${meta.group}${selected === node.id ? ' selected' : ''}`;
    card.style.left = `${node.x}px`; card.style.top = `${node.y}px`;
    card.dataset.nodeId = node.id;
    card.tabIndex = 0; card.setAttribute('role','button');
    card.setAttribute('aria-label', `${node.type}: ${node.label || meta.label}. Select to edit.`);
    card.innerHTML = `<div class="node-head">${icon(meta.icon || 'blocks')}<span>${esc(node.type)}</span><small class="node-id">${esc(node.id)}</small></div><div class="node-body"><div class="node-label">${esc(node.label || meta.label)}</div><div class="node-description">${esc(nodeDescription(node))}</div><div class="node-value-row"><span class="node-value">—</span><span class="node-small-status">READY</span></div>${['TON','TOF','PULSE'].includes(node.type) ? '<div class="node-timer"><span></span></div>' : ''}</div>${meta.arity ? '<span class="node-port in"></span>' : ''}${node.type !== 'OUTPUT' ? '<span class="node-port out"></span>' : ''}`;
    card.addEventListener('click', () => chooseNode(node.id));
    card.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); chooseNode(node.id); } });
    card.addEventListener('pointerdown', event => dragNode(event, node, card));
    container.append(card);
  }
  resizeCanvas(); renderTelemetry();
}
function chooseNode(id) {
  if (selected === id) return;
  selected = id;
  $$('.node').forEach(el => el.classList.toggle('selected', el.dataset.nodeId === id));
  renderInspector();
}
function dragNode(event, node, card) {
  if (state?.runtime?.running || event.button !== 0) return;
  chooseNode(node.id);
  const startX = event.clientX, startY = event.clientY, x = node.x, y = node.y;
  let moved = false;
  card.setPointerCapture(event.pointerId);
  const move = e => {
    if (Math.abs(e.clientX-startX)+Math.abs(e.clientY-startY)<5 && !moved) return;
    moved = true; dragging = true;
    node.x = Math.max(15, Math.min(10000, Math.round(x + (e.clientX-startX)/zoom)));
    node.y = Math.max(15, Math.min(10000, Math.round(y + (e.clientY-startY)/zoom)));
    card.style.left = `${node.x}px`; card.style.top = `${node.y}px`;
    drawWires();
  };
  const finish = () => {
    card.removeEventListener('pointermove', move); card.removeEventListener('pointerup', finish); card.removeEventListener('pointercancel', finish);
    dragging = false;
    if (moved) { markDirty(); resizeCanvas(); }
  };
  card.addEventListener('pointermove', move); card.addEventListener('pointerup', finish); card.addEventListener('pointercancel', finish);
}
function drawWires() {
  if (!program) return;
  const runtime = new Map((state?.runtime?.nodes || []).map(n => [n.id,n]));
  const fragment = document.createDocumentFragment();
  for (const target of program.nodes) {
    for (const [index,id] of (target.inputs || []).entries()) {
      const source = program.nodes.find(n => n.id === id);
      if (!source) continue;
      const x1=source.x+174, y1=source.y+79, x2=target.x, y2=target.y+79 + (index-(target.inputs.length-1)/2)*8;
      const bend = Math.max(32, Math.abs(x2-x1)*.45);
      const path = document.createElementNS('http://www.w3.org/2000/svg','path');
      path.setAttribute('d',`M ${x1} ${y1} C ${x1+bend} ${y1} ${x2-bend} ${y2} ${x2} ${y2}`);
      const r = runtime.get(id);
      if (state?.runtime?.running && r?.valid === false) path.classList.add('invalid');
      else if (state?.runtime?.running && r?.value) path.classList.add('active');
      fragment.append(path);
    }
  }
  $('#wires').replaceChildren(fragment);
}

function refOptions(node, selectedId) {
  return '<option value="">Select source block…</option>' + program.nodes.filter(n=>n.id!==node.id && n.type!=='OUTPUT').map(n=>`<option value="${esc(n.id)}" ${n.id===selectedId?'selected':''}>${esc(n.id)} · ${esc(n.label || types[n.type]?.label || n.type)} (${esc(n.type)})</option>`).join('');
}
function deviceOptions(id) {
  const devices = state?.devices || [];
  const missing = id && !devices.some(d=>d.id===id) ? `<option value="${esc(id)}" selected>${esc(id)} · unavailable</option>` : '';
  return '<option value="">Select device…</option>'+missing+devices.map(d=>`<option value="${esc(d.id)}" ${d.id===id?'selected':''}>${esc(d.name)}${d.online?'':' · offline'}</option>`).join('');
}
function modelFor(device) {
  const known = new Map((Array.isArray(device?.model) ? device.model : []).map(p=>[p.code,p]));
  for (const [code,p] of Object.entries(device?.properties || {})) {
    if (!known.has(code)) known.set(code,{code,name:code,accessMode:p.writable?'rw':'ro',typeSpec:{type:p.type || (typeof p.value==='boolean'?'bool':typeof p.value==='number'?'value':'string'),unit:p.unit,scale:p.scale}});
  }
  return [...known.values()];
}
function propertyOptions(node) {
  const device = state?.devices.find(d=>d.id===node.params.deviceId);
  const properties = modelFor(device).filter(p=>node.type !== 'OUTPUT' || ['rw','wr','wo'].includes(p.accessMode));
  const missing = node.params.code && !properties.some(p=>p.code===node.params.code) ? `<option value="${esc(node.params.code)}" selected>${esc(node.params.code)} · unavailable</option>` : '';
  return '<option value="">Select property…</option>'+missing+properties.map(p=>`<option value="${esc(p.code)}" ${p.code===node.params.code?'selected':''}>${esc(propertyLabel(p))} · ${esc(p.code)}</option>`).join('');
}
function typedValueFields(node) {
  const value = node.params.value;
  let kind = typeof value === 'boolean' ? 'boolean' : typeof value === 'number' ? 'number' : 'string';
  const prop = node.type === 'OUTPUT' ? modelFor(state.devices.find(d=>d.id===node.params.deviceId)).find(p=>p.code===node.params.code) : null;
  if (prop?.typeSpec?.type === 'bool') kind='boolean';
  if (['value','integer','float','double'].includes(prop?.typeSpec?.type)) kind='number';
  const range=prop?.typeSpec?.range;
  const control = kind==='boolean' ? `<select data-param="value" data-kind="boolean"><option value="true" ${value===true?'selected':''}>TRUE / ON</option><option value="false" ${value!==true?'selected':''}>FALSE / OFF</option></select>` : Array.isArray(range) ? `<select data-param="value" data-kind="string">${range.map(v=>`<option value="${esc(v)}" ${v===value?'selected':''}>${esc(v)}</option>`).join('')}</select>` : `<input data-param="value" data-kind="${kind}" type="${kind==='number'?'number':'text'}" ${kind==='number'?'step="any"':''} value="${esc(value)}">`;
  return `${!prop ? `<label>Value type<select id="value-type"><option value="boolean" ${kind==='boolean'?'selected':''}>Boolean · TRUE / FALSE</option><option value="number" ${kind==='number'?'selected':''}>Number</option><option value="string" ${kind==='string'?'selected':''}>Text</option></select></label>` : ''}<label>${node.type==='OUTPUT'?(node.params.mode==='pulse'?'Value during pulse':'Action value (raw)'):'Value'}${control}</label>`;
}
function renderInspector() {
  $('#inspector-content').dataset.owner='fbd';
  const target = $('#inspector-content');
  const node = program?.nodes.find(n=>n.id===selected);
  if (!node) {
    target.innerHTML = `<div class="empty-inspector"><span data-icon="cursor"></span><h3>Select a block</h3><p>Configure inputs, parameters, and connections here.</p></div>`; fillIcons(target); return;
  }
  node.params ||= {}; node.inputs ||= [];
  const meta = types[node.type] || types.AND;
  let fields = `<span class="badge">${esc(node.type)} · ${esc(node.id)}</span><label>Block name<input id="node-label" maxlength="60" value="${esc(node.label || meta.label)}"></label>`;
  if (['INPUT','OUTPUT'].includes(node.type)) {
    fields += `<label>Devices<select id="node-device">${deviceOptions(node.params.deviceId)}</select></label><label>Property<select id="node-property">${propertyOptions(node)}</select></label>`;
    if (node.type === 'INPUT') fields += `<div class="input-row"><label>Multiplier (×)<input type="number" step="any" data-param="scale" value="${esc(node.params.scale ?? 1)}"></label><label>Offset (+)<input type="number" step="any" data-param="offset" value="${esc(node.params.offset ?? 0)}"></label></div><p class="field-help">Block value = raw value × multiplier + offset. Example: 2,500 mA × 0.001 = 2.5 A.</p>`;
  }
  if(node.type==='VIRTUAL'){
    const numeric=typeof node.params.defaultValue==='number';
    fields+=`<label>Input type<select id="virtual-input-type"><option value="boolean" ${numeric?'':'selected'}>Switch (boolean)</option><option value="number" ${numeric?'selected':''}>Analog value (number)</option></select></label>`;
    if(numeric)fields+=`<label>Initial value<input type="number" step="any" data-param="defaultValue" value="${esc(node.params.defaultValue)}"></label><label>Unit (optional)<input data-param="unit" maxlength="16" value="${esc(node.params.unit || '')}" placeholder="°C, %, bar…"></label>`;
    fields+='<p class="field-help">Test Run simulates outputs. Live Test controls real devices. Virtual inputs return to their initial value at start and Stop; real devices retain their last state.</p>';
    fields+=numeric?`<label>Force value${node.params.unit?' ('+esc(node.params.unit)+')':''}<input type="number" step="any" data-virtual-force="number" id="virtual-force-value" value="${esc(state.runtime?.nodes?.find(n=>n.id===node.id)?.value ?? node.params.defaultValue)}"></label><button type="button" data-virtual-force="number" id="virtual-force-apply">Apply value</button>`:'<div class="input-row"><button type="button" data-virtual-force="false" id="virtual-force-off">Force OFF</button><button type="button" data-virtual-force="true" id="virtual-force-on">Force ON</button></div>';
  }
  if (node.type === 'OUTPUT') {
    const prop=modelFor(state.devices.find(d=>d.id===node.params.deviceId)).find(p=>p.code===node.params.code);
    const nonBoolean=prop && prop.typeSpec?.type!=='bool';
    const adjustable=prop?.accessMode==='rw'&&['value','integer','float','double'].includes(prop.typeSpec?.type);
    fields += `<label>Output mode<select id="output-mode"><option value="trigger" ${!node.params.mode||node.params.mode==='trigger'?'selected':''}>Once on TRUE</option><option value="follow" ${node.params.mode==='follow'?'selected':''} ${nonBoolean?'disabled':''}>Continuous · follow input</option><option value="pulse" ${node.params.mode==='pulse'?'selected':''} ${nonBoolean?'disabled':''}>Pulse · timed output</option><option value="value" ${node.params.mode==='value'?'selected':''}>Dynamic value · enable + source</option><option value="adjust" ${node.params.mode==='adjust'?'selected':''} ${adjustable?'':'disabled'}>Increase/decrease once on TRUE</option></select></label>${nonBoolean?'<p class="field-help">Pulse and Continuous modes require a boolean ON/OFF property.</p>':''}`;
  }
  if (node.type === 'CONST' || (node.type === 'OUTPUT' && !['follow','value','adjust'].includes(node.params.mode))) fields += typedValueFields(node);
  if(node.type==='OUTPUT'&&node.params.mode==='adjust')fields+=`<label>Adjustment (raw units)<input data-param="delta" type="number" step="any" value="${esc(node.params.delta ?? 1)}"></label><p class="field-help">Positive adds; negative subtracts. Applied once on a rising TRUE, using fresh device feedback and its allowed range. Use Ladder diagram for values displayed in device units.</p>`;
  if (node.type === 'OUTPUT' && node.params.mode === 'pulse') fields += `<label>Pulse duration (seconds)<input id="output-pulse-duration" type="number" min="0.1" max="86400" step="0.1" value="${esc((node.params.durationMs ?? 1000)/1000)}"></label>`;
  if (['TON','TOF','PULSE','TONR'].includes(node.type)) fields += `<label>Duration (seconds)<input type="number" min="0" max="86400" step="0.1" id="node-duration" value="${esc((Number(node.params.durationMs)||0)/1000)}"></label><p class="field-help">${node.type==='TONR'?'Accumulates time while enabled. Reset clears the accumulated time.':node.type==='TON'?'Input must stay TRUE for the full duration. FALSE resets the timer.':node.type==='TOF'?'Output remains TRUE for the duration after input turns FALSE.':'A FALSE → TRUE transition starts one pulse.'}</p>`;
  if (node.type==='BLINK') fields += `<div class="input-row"><label>ON time (seconds)<input data-time-param="onMs" type="number" min="0.1" max="86400" step="0.1" value="${(node.params.onMs || 1000)/1000}"></label><label>OFF time (seconds)<input data-time-param="offMs" type="number" min="0.1" max="86400" step="0.1" value="${(node.params.offMs || 1000)/1000}"></label></div>`;
  if (['COUNTER','CTD','CTUD'].includes(node.type)) fields += `<label>Count preset<input type="number" min="1" step="1" data-param="preset" value="${esc(node.params.preset ?? 1)}"></label><p class="field-help">${node.type==='CTD'?'Load sets the count to the preset. Output is TRUE at zero.':'Output becomes TRUE when the count reaches the preset. Reset clears the count.'}</p>`;
  if (meta.arity) {
    fields += '<hr class="inspector-divider"><p class="inspector-subtitle">INPUT CONNECTIONS</p>';
    const count=node.type==='OUTPUT'?node.params.mode==='value'?2:1:Math.max(meta.arity,node.inputs.length);
    for(let i=0;i<count;i++) {
      const label = meta.ports?.[i] || (node.type==='OUTPUT' ? node.params.mode==='value'?['Enable (boolean)','Value source'][i]:'Trigger (boolean)' : count===1 ? 'Input source' : `Input ${String.fromCharCode(65+i)}`);
      fields += `<label>${esc(label)}<select data-input-index="${i}">${refOptions(node,node.inputs[i])}</select></label>`;
    }
    if(meta.variable) fields += `<div class="input-row"><button type="button" id="add-input" class="quiet-button">+ Input</button>${count>2?'<button type="button" id="remove-input" class="quiet-button">− Last input</button>':''}</div>`;
  }
  if (node.type==='OUTPUT') fields += node.params.mode==='follow' ? '<p class="field-help">Continuous: ON while the input is TRUE, OFF when FALSE. Commands are sent on changes, rather than every scan.</p>' : node.params.mode==='pulse' ? `<p class="field-help">Pulse: a FALSE → TRUE trigger sends ${node.params.value?'ON':'OFF'} for the duration, then returns to ${node.params.value?'OFF':'ON'}, even if the trigger remains TRUE. The initial value before the pulse is also ${node.params.value?'OFF':'ON'}. Active pulses are not retriggered.</p><p class="field-help">Timing follows the server clock; device response depends on the cloud connection. Stop or invalid data cancels subsequent commands and leaves the last device state unchanged.</p>` : '<p class="field-help">The action is sent once when the trigger becomes TRUE. FALSE rearms it. The action value uses the device property raw format.</p>';
  fields += '<div class="block-runtime"><span>Current value</span><strong id="inspector-value">—</strong></div><hr class="inspector-divider"><button type="button" id="delete-node" class="quiet-button delete-button">'+icon('trash')+'Delete block</button>';
  target.innerHTML = `<form id="node-form">${fields}</form>`;
  $('#node-form').addEventListener('submit',event=>event.preventDefault());
  for(const button of $$('button[data-virtual-force]',target))button.addEventListener('click',()=>action(button,()=>{
    if(button.dataset.virtualForce!=='number')return forceVirtualInput(node.id,button.dataset.virtualForce==='true');
    const value=$('#virtual-force-value').value;
    if(!value.trim()||!Number.isFinite(Number(value)))throw new Error('Enter a finite numeric value.');
    return forceVirtualInput(node.id,Number(value));
  }));
  $('#virtual-input-type')?.addEventListener('change',event=>{node.params.defaultValue=event.target.value==='number'?0:false;delete node.params.unit;markDirty();renderInspector();updateNodeCard(node);});
  $('#node-label').addEventListener('input',event=>{node.label=event.target.value;markDirty();updateNodeCard(node);});
  $('#node-device')?.addEventListener('change',event=>{
    node.params.deviceId=event.target.value;node.params.code='';
    if(node.type==='OUTPUT') node.params.value=false;
    markDirty();renderInspector();updateNodeCard(node);
  });
  $('#node-property')?.addEventListener('change',event=>{
    node.params.code=event.target.value;
    if(node.type==='OUTPUT') {
      const prop=modelFor(state.devices.find(d=>d.id===node.params.deviceId)).find(p=>p.code===node.params.code);
      node.params.value=prop?.typeSpec?.type==='bool'?false:prop?.typeSpec?.type==='enum'?prop.typeSpec.range?.[0] || '':prop?.typeSpec?.type==='value'?prop.typeSpec.min ?? 0:'';
    }
    markDirty();renderInspector();updateNodeCard(node);
  });
  $('#value-type')?.addEventListener('change',event=>{node.params.value=event.target.value==='boolean'?false:event.target.value==='number'?0:'';markDirty();renderInspector();updateNodeCard(node);});
  $('#output-mode')?.addEventListener('change',event=>{
    node.params.mode=event.target.value;
    node.inputs=node.params.mode==='value'?[node.inputs[0] || '',node.inputs[1] || '']:[node.inputs[0] || ''];
    if(node.params.mode==='pulse'){node.params.durationMs ??= 1000;if(typeof node.params.value!=='boolean')node.params.value=true;}
    if(node.params.mode==='adjust'){const prop=modelFor(state.devices.find(d=>d.id===node.params.deviceId)).find(p=>p.code===node.params.code);node.params.delta ||= prop?.typeSpec?.step || 1;}
    markDirty();renderInspector();updateNodeCard(node);
  });
  $('#output-pulse-duration')?.addEventListener('change',event=>{
    const seconds=Number(event.target.value);
    if(!event.target.value||!Number.isFinite(seconds)||seconds<0.1||seconds>86400){toast('Pulse duration must be 0.1–86,400 seconds.',true);renderInspector();return;}
    node.params.durationMs=Math.round(seconds*1000);markDirty();updateNodeCard(node);
  });
  $$('[data-param]',target).forEach(el=>el.addEventListener('change',()=>{
    if(el.type==='number' && (!el.value || !Number.isFinite(Number(el.value)))) {toast('Enter a valid number.',true);renderInspector();return;}
    const value=el.dataset.kind==='boolean'?el.value==='true':el.type==='number'?Number(el.value):el.value;
    node.params[el.dataset.param]=value; markDirty();updateNodeCard(node);
    if(node.type==='OUTPUT'&&node.params.mode==='pulse'&&el.dataset.param==='value')renderInspector();
  }));
  $('#node-duration')?.addEventListener('change',event=>{
    const seconds=Number(event.target.value);
    if(!event.target.value || !Number.isFinite(seconds) || seconds<0 || seconds>86400) {toast('Duration must be 0–86,400 seconds.',true);renderInspector();return;}
    node.params.durationMs=Math.round(seconds*1000);markDirty();updateNodeCard(node);
  });
  $$('[data-time-param]',target).forEach(el=>el.addEventListener('change',()=>{if(!el.value||!el.checkValidity()){toast('Duration must be 0.1–86,400 seconds.',true);renderInspector();return;}node.params[el.dataset.timeParam]=Math.round(Number(el.value)*1000);markDirty();updateNodeCard(node);}));
  $$('[data-input-index]',target).forEach(el=>el.addEventListener('change',()=>{node.inputs[Number(el.dataset.inputIndex)]=el.value;markDirty();drawWires();}));
  $('#add-input')?.addEventListener('click',()=>{if(node.inputs.length<2)node.inputs=Array.from({length:2},(_,i)=>node.inputs[i] || '');node.inputs.push('');markDirty();renderInspector();});
  $('#remove-input')?.addEventListener('click',()=>{node.inputs.pop();markDirty();renderInspector();drawWires();});
  $('#delete-node').addEventListener('click',()=>{
    program.nodes=program.nodes.filter(n=>n.id!==node.id);
    for(const n of program.nodes)n.inputs=(n.inputs||[]).map(id=>id===node.id?'':id);
    selected=null;markDirty();renderNodes();renderInspector();toast('Block deleted. Reconnect any disconnected inputs.');
  });
  updateControls();renderTelemetry();
}
function updateNodeCard(node) {
  const card=$$('.node').find(el=>el.dataset.nodeId===node.id);
  if(card){$('.node-label',card).textContent=node.label || types[node.type]?.label || node.type;$('.node-description',card).textContent=nodeDescription(node);}
  renderTelemetry();
}
function fmt(value, digits=2) {
  if(value===null || value===undefined) return '—';
  if(typeof value==='boolean') return value?'TRUE':'FALSE';
  if(typeof value==='number') return Number.isFinite(value) ? new Intl.NumberFormat('en-US',{maximumFractionDigits:digits}).format(value) : '—';
  return String(value);
}
function renderTelemetry() {
  if(!state) return;
  const runtime=state.runtime || {running:false,nodes:[]};
  const running=runtime.running;
  const online=state.devices.filter(d=>d.online).length;
  $('#metric-devices').innerHTML=`${online} <span>/ ${state.devices.length}</span>`;
  const currentDevice=state.devices.find(d=>Object.keys(d.properties || {}).some(code=>/current|cur_current/i.test(code)));
  const currentCode=Object.keys(currentDevice?.properties || {}).find(code=>/current|cur_current/i.test(code));
  const currentProp=currentDevice?.properties?.[currentCode];
  let current=null;
  if(currentProp?.valid && currentDevice.online) {
    const model=modelFor(currentDevice).find(p=>p.code===currentCode);
    const unit=currentProp.unit || model?.typeSpec?.unit || '';
    const scale=Number(currentProp.scale ?? model?.typeSpec?.scale ?? 0);
    current=Number(currentProp.value)/(10**scale);
    if(unit.toLowerCase()==='ma' || (!unit && /cur_current/i.test(currentCode))) current/=1000;
  }
  $('#metric-current').innerHTML=`${fmt(current)} <span>A</span>`;
  const timer=runtime.nodes?.find(n=>Number.isFinite(n.elapsedMs) && n.elapsedMs>0) || runtime.nodes?.find(n=>Number.isFinite(n.elapsedMs));
  const timerNode=program?.nodes.find(n=>n.id===timer?.id);
  const elapsed=running?Number(timer?.elapsedMs)||0:0;
  $('#metric-timer').innerHTML=`${(elapsed/1000).toFixed(1)} <span>s</span>`;
  $('#timer-percent').textContent=`${Math.min(100,Math.round(elapsed/(timerNode?.params?.durationMs || 1)*100))}%`;
  $('#metric-engine').textContent=runtime.error?'Fault':running?runtime.executionMode==='live-test'?'Live Test':runtime.executionMode==='test'?'Test Run':'Running':'Stopped';
  $('#engine-dot').className=`status-dot${runtime.error?' error':running?'':' idle'}`;
  $('#canvas-dot').className=`status-dot${runtime.error?' error':running?'':' idle'}`;
  $('#canvas-status').textContent=runtime.error?'PROGRAM FAULTED':running?runtime.executionMode==='live-test'?'LIVE TEST · REAL DEVICES':runtime.executionMode==='test'?'TEST RUN · OUTPUTS SIMULATED':'PROGRAM RUNNING':'PROGRAM STOPPED';
  renderTestOutputs();
  const connectionMessage=state.connection?.message || (state.mode==='demo'?'Simulation devices active':state.configured?'Tuya configured':'API key not configured');
  $('#footer-status').textContent=connectionMessage;
  $('#footer-dot').className=`status-dot${['error','disconnected'].includes(state.connection?.status)?' error':state.mode==='live'&&!state.configured?' warning':''}`;
  const demoDevice=state.devices.find(d=>d.id.startsWith('demo')) || state.devices[0];
  const switchProp=Object.entries(demoDevice?.properties || {}).find(([code,p])=>/switch/i.test(code)&&typeof p.value==='boolean');
  $('#demo-switch').textContent=switchProp?.[1]?.value?'Switch OFF':'Switch ON';
  $('#demo-switch').dataset.nextValue=String(!switchProp?.[1]?.value);
  $('#demo-online').checked=demoDevice?.online !== false;
  for(const card of $$('.node')) {
    const node=program.nodes.find(n=>n.id===card.dataset.nodeId);
    const status=runtime.nodes?.find(n=>n.id===node.id);
    const valueEl=$('.node-value',card), badge=$('.node-small-status',card);
    let value=status?.value;
    if(!running && node.type==='CONST')value=node.params.value;
    if(!running && node.type==='VIRTUAL')value=node.params.defaultValue ?? false;
    if(!running && node.type==='INPUT') {
      const p=state.devices.find(d=>d.id===node.params.deviceId)?.properties?.[node.params.code];
      value=p?.valid?(typeof p.value==='number'?p.value*(node.params.scale??1)+(node.params.offset??0):p.value):undefined;
    }
    valueEl.textContent=fmt(value);
    valueEl.className=`node-value${typeof value==='boolean'?` bool ${value?'on':'off'}`:''}`;
    const invalid=running&&status?.valid===false;
    card.classList.toggle('invalid',invalid);
    badge.textContent=invalid?'INVALID':!running?'READY':node.type==='COUNTER'?`${status?.count ?? 0} COUNT`:'LIVE';
    badge.classList.toggle('warning',invalid);
    badge.title=status?.error || '';
    const progress=$('.node-timer>span',card);
    if(progress)progress.style.width=`${running?Math.min(100,(status?.elapsedMs||0)/(node.params.durationMs||1)*100):0}%`;
  }
  const inspectorValue=$('#inspector-value');
  if(inspectorValue) {
    const r=runtime.nodes?.find(n=>n.id===selected);
    inspectorValue.textContent=r?.valid===false&&running?'Invalid':fmt(r?.value);
  }
  drawWires();
}

function renderTestOutputs() {
  const testing=state?.runtime?.executionMode==='test';
  $('#test-run-banner').hidden=!testing;
  $('#live-test-banner').hidden=state?.runtime?.executionMode!=='live-test';
  if(!testing)return;
  const outputs=state.runtime.testOutputs || [];
  const markup=outputs.length ? outputs.map(output=>{
    const device=state.devices.find(d=>d.id===output.deviceId);
    const property=modelFor(device).find(p=>p.code===output.code);
    const label=`${device?.name || output.deviceId} · ${propertyLabel(property || {code:output.code})}`;
    return `<div class="test-output"><span>${esc(label)}<small>${esc(output.code)} · simulated raw value</small></span><strong>${typeof output.value==='boolean'?(output.value?'ON':'OFF'):esc(output.value)}</strong></div>`;
  }).join('') : '<p class="field-help">Waiting for an output action. Watch the energized contacts and coil on the ladder.</p>';
  const target=$('#test-output-list');if(target.innerHTML!==markup)target.innerHTML=markup;
}

function renderDevices(force=false) {
  if(!state) return;
  const signature=JSON.stringify(state.devices);
  if(!force && (currentView!=='devices' || signature===lastDeviceSignature))return;
  if(!force && $('#device-list').contains(document.activeElement) && ['INPUT','SELECT'].includes(document.activeElement.tagName))return;
  lastDeviceSignature=signature;
  $('#devices-notice').textContent=state.mode==='demo'?'Simulation only. Use Set input to change sensor values, including while the program runs. Values are entered in the raw units shown. Manual output controls require the program to be stopped.':'Property values follow Tuya reports. Raw values and units help you verify your input/output mapping.';
  const target=$('#device-list');target.replaceChildren();
  if(!state.devices.length) {
    target.innerHTML='<div class="panel empty-state"><span data-icon="plug"></span><h3>No devices yet</h3><p>Connect your API key in Settings, then sync devices.</p><button class="button secondary" id="open-settings">Open settings</button></div>';
    fillIcons(target);$('#open-settings').addEventListener('click',()=>selectView('settings'));return;
  }
  for(const device of state.devices) {
    const card=document.createElement('article');card.className='panel device-card';
    card.innerHTML=`<div class="device-head"><span class="metric-icon">${icon('plug')}</span><div><h2>${esc(device.name)}</h2><small>${esc(device.id)}</small></div><span class="badge ${device.online?'':'amber'}">${device.online?'ONLINE':'OFFLINE'}</span></div>`;
    const props=modelFor(device);
    if(!props.length) {const text=document.createElement('p');text.className='muted';text.textContent='Properties are not available yet. Sync devices to load their models and status.';card.append(text);}
    for(const model of props) {
      const prop=device.properties?.[model.code];
      const spec=model.typeSpec || {};
      const writable=['rw','wr','wo'].includes(model.accessMode);
      const row=document.createElement('div');row.className='property-row';
      const scale=Number(prop?.scale ?? spec.scale ?? 0),unit=prop?.unit || spec.unit || '';
      const raw=prop?.value;
      const physical=typeof raw==='number' ? raw/(10**scale) : raw;
      const quality=propertyQuality(prop,device),timestamp=quality.observation;
      row.innerHTML=`<div><strong>${esc(propertyLabel(model))}</strong><small>${esc(model.code)}${typeof raw==='number'?` · raw ${esc(raw)} · scale ${esc(scale)}`:''}</small><small>${esc(timestamp)}${quality.valid?'':' · '+esc(quality.label)}</small></div><span class="property-value${prop?.valid===false?' invalid':''}">${esc(fmt(physical))}${unit?` <small>${esc(unit)}</small>`:''}</span>`;
      if(writable) {
        const controls=document.createElement('div');controls.className='property-command';
        let input;
        if(spec.type==='bool' || typeof raw==='boolean') {
          const button=document.createElement('button');button.className='button secondary small';button.textContent=raw?'OFF':'ON';button.disabled=!device.online || !!state.runtime?.running;button.dataset.offline=String(!device.online);
          button.addEventListener('click',()=>action(button,async()=>{await post('/api/control',{deviceId:device.id,code:model.code,value:!raw});await loadState();toast('Command sent. The server verifies the device state.');}));
          controls.append(button);
        } else {
          if(Array.isArray(spec.range)) {input=document.createElement('select');for(const v of spec.range){const option=document.createElement('option');option.value=v;option.textContent=v;option.selected=raw===v;input.append(option);}}
          else {input=document.createElement('input');input.type=['value','integer','float','double'].includes(spec.type)||typeof raw==='number'?'number':'text';input.value=raw??'';if(input.type==='number'){input.step=spec.step??'any';if(Number.isFinite(spec.min))input.min=spec.min;if(Number.isFinite(spec.max))input.max=spec.max;}}
          input.setAttribute('aria-label',`Raw value ${propertyLabel(model)}`);
          input.title='Raw value according to the device model';
          const button=document.createElement('button');button.className='button secondary small';button.textContent='Send';button.disabled=!device.online || !!state.runtime?.running;button.dataset.offline=String(!device.online);
          button.addEventListener('click',()=>action(button,async()=>{
            if(!input.checkValidity() || input.value==='')throw new Error('Enter a raw value within the property range.');
            const value=input.type==='number'?Number(input.value):input.value;
            await post('/api/control',{deviceId:device.id,code:model.code,value});await loadState();toast('Command sent. The server verifies the device state.');
          }));controls.append(input,button);
        }
        row.append(controls);
      }
      if(!writable && state.mode==='demo' && (['bool','boolean','value','integer','float','double','enum','string'].includes(spec.type) || ['number','boolean','string'].includes(typeof raw))) {
        const controls=document.createElement('div');controls.className='simulation-command';
        controls.dataset.simDeviceId=device.id;controls.dataset.simCode=model.code;
        const boolean=spec.type==='bool'||spec.type==='boolean'||typeof raw==='boolean';
        const numeric=['value','integer','float','double'].includes(spec.type)||typeof raw==='number';
        let input;
        if(boolean || Array.isArray(spec.range)) {
          input=document.createElement('select');
          for(const value of boolean?[true,false]:spec.range){const option=document.createElement('option');option.value=String(value);option.textContent=boolean?value?'TRUE':'FALSE':String(value);option.selected=raw===value;input.append(option);}
        } else {
          input=document.createElement('input');input.type=numeric?'number':'text';input.value=raw??'';
          if(numeric){input.step=spec.step??'any';if(Number.isFinite(spec.min))input.min=spec.min;if(Number.isFinite(spec.max))input.max=spec.max;input.required=true;}
        }
        input.setAttribute('aria-label',`Simulation raw value ${propertyLabel(model)}`);
        input.title='Simulated sensor value in raw device units';
        input.dataset.simCode=model.code;input.dataset.simDeviceId=device.id;
        const button=document.createElement('button');button.className='button secondary small';button.textContent='Set input';button.dataset.simCode=model.code;button.dataset.simDeviceId=device.id;
        button.addEventListener('click',()=>action(button,async()=>{
          if(!input.checkValidity())throw new Error('Enter a simulation value within the property range.');
          const value=boolean?input.value==='true':numeric?Number(input.value):input.value;
          await post('/api/demo',{deviceId:device.id,properties:{[model.code]:value}});
          await loadState();toast('Simulation input updated.');
        }));
        controls.append(input,button);row.append(controls);
      }
      card.append(row);
    }
    target.append(card);
  }
}
function renderLogs(force=false) {
  if(!state)return;
  const logs=state.logs || [];
  const signature=JSON.stringify(logs)+$('#log-filter').value;
  if(!force && signature===lastLogSignature)return;
  lastLogSignature=signature;
  const sorted=[...logs].sort((a,b)=>new Date(b.time)-new Date(a.time));
  const render=(target,items)=>{
    target.replaceChildren();
    if(!items.length){const empty=document.createElement('p');empty.className='empty-log';empty.textContent='No activity yet. Run a program to see execution events.';target.append(empty);return;}
    for(const log of items){
      const row=document.createElement('div');row.className=`log-row ${log.level==='error'?'error':log.level==='warn'?'warn':'info'}`;
      const time=new Date(log.time);const valid=Number.isFinite(time.getTime());
      row.innerHTML=`<time ${valid?`datetime="${esc(time.toISOString())}"`:''}>${esc(valid?time.toLocaleTimeString('en-US',{hour12:false}):'—')}</time><i class="status-dot ${log.level==='error'?'error':log.level==='warn'?'warning':''}"></i><span class="log-message">${esc(log.message)}</span><span class="log-level">${esc((log.level || 'info').toUpperCase())}</span>`;
      target.append(row);
    }
  };
  render($('#recent-logs'),sorted.slice(0,3));
  const filter=$('#log-filter').value;
  render($('#all-logs'),sorted.filter(log=>filter==='all'||log.level===filter));
}
function renderSettings() {
  if(!state)return;
  if(!settingsInitialized){$('#settings-mode').value=state.mode;settingsInitialized=true;}
  const connected=state.mode==='demo'||['connected','online','ready'].includes(state.connection?.status);
  const el=$('#connection-status');
  el.className=`notice ${connected?'success':state.configured?'warning':''}`;
  el.textContent=state.connection?.message || (state.configured?'API key saved.':'No API key yet. You can use simulation in the meantime.');
  $('#settings-local-notice').hidden=!!session.local;
  if(!session.local)$('#settings-local-notice').textContent=session.hosted?'This server manages its Tuya connection. Your phone and computer use the same saved programs and device connection.':'Enter your API key in a browser on the server laptop using its localhost address.';
  const addressHelp=$('#server-address-help');if(addressHelp)addressHelp.textContent=session.hosted?'Use this HTTPS address in the Android app or a browser on any computer.':'Use this address in the Android app when your phone and laptop share the same Wi-Fi network.';
  const uptimeHelp=$('#server-uptime-help');if(uptimeHelp)uptimeHelp.textContent=session.hosted?'The logic runs on this hosted server. Your phone and computer can be closed while a program is running.':'Keep your server powered on to run programs. Internet access requires HTTPS and a separately configured server.';
  const urls=state.server?.urls || [];
  $('#server-urls').replaceChildren();
  for(const url of urls){
    const row=document.createElement('div');row.className='server-url';
    const code=document.createElement('code');code.textContent=url;
    const button=document.createElement('button');button.type='button';button.className='quiet-button';button.textContent='Copy';
    button.addEventListener('click',()=>action(button,async()=>{
      if(navigator.clipboard?.writeText)await navigator.clipboard.writeText(url);
      else{const input=document.createElement('textarea');input.value=url;document.body.append(input);input.select();const ok=document.execCommand('copy');input.remove();if(!ok)throw new Error('Copy the displayed address manually.');}
      toast('Server address copied.');
    }));row.append(code,button);$('#server-urls').append(row);
  }
  if(!urls.length)$('#server-urls').textContent=location.origin;
}

async function saveProgram() {
  if(!program)throw new Error('No program loaded.');
  if(state.runtime?.running)throw new Error('Stop the program before saving changes.');
  if(editorMode!=='fbd' && ladderEditor.ladder)program=compileLadder(ladderEditor.serialize(),{id:program.id,name:$('#program-name').value});
  const missing=program.nodes.find(node=>(node.inputs || []).some(id=>!id));
  if(missing)throw new Error(`Connect all inputs on block ${missing.label || missing.id} first.`);
  const draftSignature=()=>JSON.stringify({mode:editorMode,name:$('#program-name').value,program,ladder:editorMode!=='fbd'?ladderEditor.serialize():null});
  const submittedDraft=draftSignature(),submittedRevision=baseProgramRevision;
  let saved;
  try{saved=await api('/api/program',{method:'PUT',headers:baseProgramRevision?{'If-Match':`"${baseProgramRevision}"`}:{},body:JSON.stringify(program)});}
  catch(error){if(error.code==='PROGRAM_CONFLICT'){dirty=true;programConflict=true;updateControls();}throw error;}
  if(draftSignature()!==submittedDraft){
    // The editor remains usable during Save. Preserve edits made while the
    // request was in flight, and prevent Run from starting an older draft.
    baseProgramRevision=saved.programRevision || null;
    lastProgramSignature=JSON.stringify(saved.program);
    if(state.programRevision===submittedRevision)state={...state,program:saved.program,programRevision:saved.programRevision};
    dirty=true;programConflict=false;updateControls();
    throw new Error('The submitted version was saved. Your newer edits are still unsaved; save them before starting the program.');
  }
  dirty=false;lastProgramSignature='';applyState(saved);toast('Program saved.');
}
async function downloadCurrentProgram(filename) {
  if(!program)throw new Error('No program loaded.');
  const draft=clone(program);draft.name=$('#program-name').value;
  let exported=draft;
  if(editorMode!=='fbd'&&ladderEditor.ladder){
    draft.ladder=ladderEditor.serialize();
    try{exported=compileLadder(draft.ladder,{id:draft.id,name:draft.name});}
    catch{exported={...draft,nodes:[],draft:true};}
  }
  const result=await post('/api/exports',exported);
  const link=document.createElement('a');link.href=result.url;link.download=filename;document.body.append(link);link.click();link.remove();
}
$('#export-draft').addEventListener('click',()=>action($('#export-draft'),async()=>downloadCurrentProgram('tuya-logic-draft.json')));
$('#reload-program').addEventListener('click',()=>action($('#reload-program'),async()=>{
  if(dirty&&!confirm('Discard your unsaved draft and load the latest server program? Export the draft first if you want to keep it.'))return;
  const latest=await api('/api/state');dirty=false;lastProgramSignature='';applyState(latest);toast('Latest server program loaded.');
}));
$('#auth-form').addEventListener('submit',async event=>{
  event.preventDefault();$('#auth-error').textContent='';
  const button=$('#auth-submit');button.disabled=true;
  try{
    const password=$('#auth-password').value;
    if(session.setupRequired && password!==$('#auth-confirm').value)throw new Error('The passwords do not match.');
    await post(session.setupRequired?'/api/setup':'/api/login',{password});
    $('#auth-password').value='';$('#auth-confirm').value='';
    session=await api('/api/session');await openStudio();
  }catch(error){$('#auth-error').textContent=error.message;}
  finally{button.disabled=false;}
});
$('#logout').addEventListener('click',()=>action($('#logout'),async()=>{if(dirty&&!confirm('You have unsaved changes. Sign out and discard them?'))return;await post('/api/logout');dirty=false;program=null;shuttingDown=true;await showAuth();}));
$('#program-name').addEventListener('input',event=>{if(program){program.name=event.target.value;dirty=true;updateControls();}});
$('#save-program').addEventListener('click',()=>action($('#save-program'),saveProgram));
$('#run-program').addEventListener('click',()=>action($('#run-program'),async()=>{if(dirty || (editorMode!=='fbd'&&ladderEditor.ladder&&!program.ladder))await saveProgram();await post('/api/run');await loadState();toast(state.mode==='demo'?'Simulation program running.':'Program running on Tuya devices.');}));
$('#test-program').addEventListener('click',()=>action($('#test-program'),async()=>{if(dirty || (editorMode!=='fbd'&&ladderEditor.ladder&&!program.ladder))await saveProgram();applyState(await post('/api/test-run'));toast('Test Run started. Use Force I/O to simulate inputs; no device commands are sent.');}));
$('#live-test-program').addEventListener('click',()=>action($('#live-test-program'),async()=>{if(dirty || (editorMode!=='fbd'&&ladderEditor.ladder&&!program.ladder))await saveProgram();applyState(await post('/api/live-test'));toast('Live Test started. Force I/O and ladder outputs now control real devices.');}));
$('#stop-program').addEventListener('click',()=>action($('#stop-program'),async()=>{const testMode=state.runtime?.executionMode;await post('/api/stop');await loadState();toast(testMode==='test'?'Test Run stopped. Simulated input forces cleared; virtual inputs reset to their initial values.':testMode==='live-test'?'Live Test stopped. Virtual inputs reset to their initial values; real devices retain their last state.':'Program stopped. The last output state is unchanged.');}));
for(const selector of ['#refresh','#refresh-devices'])$(selector).addEventListener('click',()=>action($(selector),async()=>{await post('/api/devices/refresh');await loadState();toast('Device data refreshed.');}));
$('#demo-current').addEventListener('input',event=>{$('#demo-current-value').textContent=`${Number(event.target.value).toFixed(2)} A`;});
$('#demo-apply').addEventListener('click',()=>action($('#demo-apply'),async()=>{await post('/api/demo',{current:Number($('#demo-current').value)});await loadState();toast(`Simulation current ${Number($('#demo-current').value).toFixed(2)} A.`);}));
$('#demo-switch').addEventListener('click',()=>action($('#demo-switch'),async()=>{await post('/api/demo',{switch:$('#demo-switch').dataset.nextValue==='true'});await loadState();}));
$('#demo-online').addEventListener('change',()=>action($('#demo-online'),async()=>{await post('/api/demo',{online:$('#demo-online').checked});await loadState();}));
$('#zoom-in').addEventListener('click',()=>{zoom=Math.min(1.5,zoom+.1);resizeCanvas();});
$('#zoom-out').addEventListener('click',()=>{zoom=Math.max(.35,zoom-.1);resizeCanvas();});
$('#fit-canvas').addEventListener('click',arrangeNodes);
$('#log-filter').addEventListener('change',()=>renderLogs(true));
$('#settings-form').addEventListener('submit',event=>{event.preventDefault();action($('#settings-save'),async()=>{
  const body={mode:$('#settings-mode').value};const key=$('#api-key').value.trim();if(key)body.apiKey=key;
  await post('/api/settings',body);$('#api-key').value='';settingsInitialized=false;await loadState();toast('Connection settings saved.');
});});
$('#export-program').addEventListener('click',()=>action($('#export-program'),async()=>{if(dirty)return downloadCurrentProgram('tuya-logic-draft.json');const link=document.createElement('a');link.href='/api/program';link.download='tuya-logic-program.json';document.body.append(link);link.click();link.remove();}));
$('#import-program').addEventListener('click',()=>$('#import-file').click());
$('#import-file').addEventListener('change',async event=>{
  const file=event.target.files?.[0];if(!file)return;
  try{
    if(file.size>1000000)throw new Error('Program file is too large (maximum 1 MB).');
    const imported=JSON.parse(await file.text());
    if(state?.runtime?.running)throw new Error('Stop the program before importing changes.');
    if(!imported||typeof imported!=='object'||!Array.isArray(imported.nodes)||imported.nodes.length>512)throw new Error('Invalid program format or more than 512 blocks.');
    if(!imported.nodes.every(n=>n&&typeof n.id==='string'&&types[n.type]&&Array.isArray(n.inputs)&&n.params&&typeof n.params==='object'))throw new Error('A block uses an unsupported format.');
    if(dirty&&!confirm('Replace unsaved changes with the imported program?'))return;
    program=clone(imported);program.name=String(program.name || 'Imported program');program.id=String(program.id || 'main');
    for(const n of program.nodes){if(!Number.isFinite(n.x)||n.x<0||n.x>10000)delete n.x;if(!Number.isFinite(n.y)||n.y<0||n.y>10000)delete n.y;}
    selected=program.nodes[0]?.id || null;positionMissingNodes();$('#program-name').value=program.name;dirty=true;editorMode=program.ladder?'ladder':'fbd';renderNodes();loadLadderRepresentation();updateControls();toast('Program imported. Check device mappings, then save to validate it.');
  }catch(error){toast(error.message || 'Cannot read the JSON file.',true);}finally{event.target.value='';}
});
$('#add-node').addEventListener('click',()=>$('#node-dialog').showModal());
$('#close-dialog').addEventListener('click',()=>$('#node-dialog').close());
$('#node-dialog').addEventListener('click',event=>{if(event.target===$('#node-dialog')){const rect=event.target.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)event.target.close();}});
for(const [type,meta] of Object.entries(types)){
  const button=document.createElement('button');button.className='library-button';button.innerHTML=`<strong>${esc(type)}</strong><small>${esc(meta.description)}</small>`;
  button.dataset.type=type;button.dataset.category=meta.category;button.dataset.search=`${type} ${meta.label} ${meta.description}`.toLowerCase();
  button.addEventListener('click',()=>{
    if(!program||state.runtime?.running)return;
    if(program.nodes.length>=512){toast('A program can contain up to 512 blocks.',true);return;}
    let index=1;while(program.nodes.some(n=>n.id===`${type.toLowerCase()}${index}`))index++;
    const firstDevice=state.devices[0];
    const params=type==='VIRTUAL'?{defaultValue:false}:type==='INPUT'?{deviceId:firstDevice?.id || '',code:'',scale:1,offset:0}:type==='CONST'?{value:0}:type==='OUTPUT'?{deviceId:firstDevice?.id || '',code:'',value:false}:['TON','TOF','PULSE','TONR'].includes(type)?{durationMs:30000}:['COUNTER','CTD','CTUD'].includes(type)?{preset:3}:type==='BLINK'?{onMs:1000,offMs:1000}:{};
    const node={id:`${type.toLowerCase()}${index}`,type,label:meta.label,inputs:Array(meta.arity).fill(''),params,x:Math.round($('#canvas-scroll').scrollLeft/zoom+45),y:Math.round($('#canvas-scroll').scrollTop/zoom+45)};
    const occupied=program.nodes.some(n=>Math.abs(n.x-node.x)<80&&Math.abs(n.y-node.y)<80);if(occupied){node.x+=50;node.y+=100;}
    program.nodes.push(node);selected=node.id;markDirty();renderNodes();renderInspector();$('#node-dialog').close();
    if(innerWidth<760)$('#inspector-content').scrollIntoView({behavior:'smooth',block:'nearest'});
  });$('#node-library').append(button);
}
let libraryCategory='All';
function filterLibrary(){const query=$('#node-search').value.toLowerCase();$$('#node-library .library-button').forEach(button=>{button.hidden=!(libraryCategory==='All'||button.dataset.category===libraryCategory)||!button.dataset.search.includes(query);});}
for(const name of ['All',...new Set(Object.values(types).map(meta=>meta.category))]){const button=document.createElement('button');button.className=`library-category${name==='All'?' active':''}`;button.textContent=name;button.addEventListener('click',()=>{libraryCategory=name;$$('#node-categories button').forEach(el=>el.classList.toggle('active',el===button));filterLibrary();});$('#node-categories').append(button);}
$('#node-search').addEventListener('input',filterLibrary);
for(const name of ['ladder','io','fbd'])$(`#mode-${name}`).addEventListener('click',()=>setEditorMode(name));
$('#new-program').addEventListener('click',()=>{
  if(state?.runtime?.running)return;
  if(program?.nodes?.length || dirty)if(!confirm('Create a new Ladder program? Export the current program first if you want to keep it. Unsaved changes will be discarded.'))return;
  const tags=ladderEditor.serialize()?.tags || [];
  program={id:`ladder-${Date.now().toString(36)}`,name:'New Ladder program',nodes:[],ladder:{version:1,tags,rungs:[]}};
  selected=null;dirty=true;editorMode='ladder';$('#program-name').value=program.name;ladderEditor.load(program.ladder);setEditorMode('ladder',true);updateControls();
});
$('#devices-add-device')?.addEventListener('click',()=>{selectView('studio');if(!ladderEditor.ladder){toast('Create a Ladder program first to map I/O tags.',true);return;}setEditorMode('io');ladderEditor.openDevicePicker();});
window.addEventListener('resize',resizeCanvas);
(async()=>{try{session=await api('/api/session');if(session.authenticated)await openStudio();else await showAuth();}catch(error){await showAuth();$('#auth-error').textContent='Cannot reach the server. Make sure your Tuya Logic server is running.';}})();
