// FBD editing uses the engine's ordered inputs. Geometry never creates a wire.
const NUMERIC = new Set(['ADD','SUB','MUL','DIV','MOD','ABS','MIN','MAX','CLAMP']);
const ORDERED = new Set(['GT','GTE','LT','LTE']);
const VARIABLE = new Set(['AND','OR','XOR','NAND','NOR','MIN','MAX']);
const ARITY = {INPUT:0,VIRTUAL:0,CONST:0,OUTPUT:1,SCHEDULE:1,NOT:1,R_TRIG:1,F_TRIG:1,ABS:1,TON:1,TOF:1,PULSE:1,BLINK:1,SELECT:3,CLAMP:3,CTUD:3};
const NS = 'http://www.w3.org/2000/svg';
const MIME = 'application/x-tuya-fbd-block';
const clone = value => structuredClone(value);
const clamp = value => Math.max(15, Math.min(10000, Math.round(value)));
const primitive = value => ['boolean','string'].includes(typeof value) || typeof value==='number' && Number.isFinite(value) ? typeof value : null;

export function fbdInputCount(node, types={}) {
  if(node.type==='OUTPUT') return node.params?.mode==='value' ? 2 : 1;
  const meta=types[node.type] || {};
  const count=meta.arity ?? ARITY[node.type] ?? 2;
  return meta.variable || VARIABLE.has(node.type) ? Math.min(100,Math.max(count,node.inputs?.length || 0)) : count;
}
function nodeMap(program) {
  if(!Array.isArray(program?.nodes) || program.nodes.length>512) throw new Error('A program supports up to 512 blocks.');
  const map=new Map(program.nodes.map(node=>[node.id,node]));
  if(map.size!==program.nodes.length) throw new Error('Block IDs must be unique.');
  return map;
}
function mappedType(node,devices) {
  const device=devices.find(device=>device.id===node.params?.deviceId);
  const property=device?.model?.find(property=>property.code===node.params?.code);
  const type=String(property?.typeSpec?.type || property?.type || '').toLowerCase();
  if(['bool','boolean'].includes(type)) return 'boolean';
  if(['value','integer','float','double','number'].includes(type)) return 'number';
  if(['enum','string','text'].includes(type)) return 'string';
  return primitive(device?.properties?.[node.params?.code]?.value) || null;
}
export function fbdValueType(program,id,devices=[]) {
  const map=nodeMap(program),seen=new Set();
  function infer(key) {
    if(seen.has(key)) return null;
    const node=map.get(key); if(!node) return null;
    seen.add(key);
    let result;
    if(node.type==='INPUT') result=mappedType(node,devices);
    else if(node.type==='CONST') result=primitive(node.params?.value);
    else if(node.type==='VIRTUAL') result=primitive(node.params?.defaultValue ?? false);
    else if(NUMERIC.has(node.type)) result='number';
    else if(node.type==='SELECT') {
      const a=infer(node.inputs?.[1]),b=infer(node.inputs?.[2]);
      result=a && b && a!==b ? null : a || b;
    } else if(node.type==='OUTPUT') result=null;
    else result='boolean';
    seen.delete(key);return result;
  }
  return infer(id);
}
function validateGraph(program,types,devices) {
  const map=nodeMap(program),visiting=new Set(),visited=new Set();
  function visit(id) {
    if(visiting.has(id)) throw new Error('This connection would create a cycle.');
    if(visited.has(id)) return;
    visiting.add(id);
    for(const input of map.get(id)?.inputs || []) if(map.has(input)) visit(input);
    visiting.delete(id);visited.add(id);
  }
  for(const node of program.nodes) visit(node.id);
  for(const node of program.nodes) {
    const values=(node.inputs || []).map(id=>fbdValueType(program,id,devices));
    for(let index=0;index<values.length;index++) {
      const source=map.get(node.inputs[index]);
      if(source?.type==='OUTPUT') throw new Error('Device output blocks cannot be used as a signal source.');
      if(!values[index]) continue;
      let expected;
      if(NUMERIC.has(node.type)||ORDERED.has(node.type)) expected='number';
      else if(['EQ','NEQ'].includes(node.type)) expected=values[1-index];
      else if(node.type==='SELECT') expected=index===0 ? 'boolean' : values[index===1?2:1];
      else if(node.type==='OUTPUT') expected=index===0 ? 'boolean' : mappedType(node,devices);
      else if(fbdInputCount(node,types)>0) expected='boolean';
      if(expected && values[index]!==expected) throw new Error(`${node.label || node.id}, input ${index+1}, requires ${expected}; the source is ${values[index]}.`);
    }
  }
}
function targetSlot(program,targetId,inputIndex,types) {
  const target=nodeMap(program).get(targetId);
  if(!target) throw new Error('The target block no longer exists.');
  if(!Number.isInteger(inputIndex)||inputIndex<0||inputIndex>=fbdInputCount(target,types)) throw new Error('Select a valid input port.');
  target.inputs=Array.from({length:fbdInputCount(target,types)},(_,i)=>target.inputs?.[i] || '');
  return target;
}
export function connectFbd(program,sourceId,targetId,inputIndex,{types={},devices=[]}={}) {
  const next=clone(program),source=nodeMap(next).get(sourceId);
  if(!source) throw new Error('The source block no longer exists.');
  if(source.type==='OUTPUT') throw new Error('Device output blocks cannot be used as a signal source.');
  if(sourceId===targetId) throw new Error('A block cannot connect to itself.');
  targetSlot(next,targetId,inputIndex,types).inputs[inputIndex]=sourceId;
  validateGraph(next,types,devices);return next;
}
export function disconnectFbd(program,targetId,inputIndex,{types={}}={}) {
  const next=clone(program);targetSlot(next,targetId,inputIndex,types).inputs[inputIndex]='';return next;
}
export function deleteFbdNode(program,nodeId) {
  const next=clone(program);if(!nodeMap(next).has(nodeId)) throw new Error('The block no longer exists.');
  next.nodes=next.nodes.filter(node=>node.id!==nodeId);
  for(const node of next.nodes) node.inputs=(node.inputs || []).map(id=>id===nodeId?'':id);
  return next;
}
export function moveFbdNode(program,nodeId,x,y) {
  if(!Number.isFinite(x)||!Number.isFinite(y)) throw new Error('Block positions must be finite numbers.');
  const next=clone(program),node=nodeMap(next).get(nodeId);
  if(!node) throw new Error('The block no longer exists.');
  node.x=clamp(x);node.y=clamp(y);return next;
}
export function addFbdNode(program,type,{types={},devices=[],x=45,y=45}={}) {
  if(!Number.isFinite(x)||!Number.isFinite(y)) throw new Error('Block positions must be finite numbers.');
  const next=clone(program),map=nodeMap(next),meta=types[type];
  if(!meta) throw new Error('Choose a supported block type.');
  if(next.nodes.length>=512) throw new Error('A program supports up to 512 blocks.');
  let serial=1;while(map.has(`${type.toLowerCase()}${serial}`))serial++;
  let params={};
  if(type==='INPUT')params={deviceId:devices[0]?.id || '',code:'',scale:1,offset:0};
  if(type==='OUTPUT')params={deviceId:devices[0]?.id || '',code:'',value:false};
  if(type==='CONST')params={value:0};
  if(type==='VIRTUAL')params={defaultValue:false};
  if(['TON','TOF','PULSE','TONR'].includes(type))params={durationMs:30000};
  if(['COUNTER','CTD','CTUD'].includes(type))params={preset:3};
  if(type==='BLINK')params={onMs:1000,offMs:1000};
  if(type==='SCHEDULE')params={start:'17:30',end:'05:30',timeZone:'Asia/Jakarta'};
  const node={id:`${type.toLowerCase()}${serial}`,type,label:meta.label,params,inputs:[],x:clamp(x),y:clamp(y)};
  node.inputs=Array(fbdInputCount(node,types)).fill('');next.nodes.push(node);return next;
}

export class FbdEditor {
  constructor(options) {
    Object.assign(this,options);this.types ||= {};this.listeners=[];this.pending=null;this.edge=null;this.dragCancel=null;this.cancelPortDrag=null;this.suppressClick=false;
    this.document=this.canvas.ownerDocument;
    this.listen(this.document,'keydown',event=>this.keydown(event));
    this.listen(this.nodes,'click',event=>{const card=event.target.closest?.('[data-node-id]');if(card&&!event.target.closest('[data-fbd-port]')){this.edge=null;this.pending=null;this.drawWires();}});
    this.listen(this.canvas,'click',event=>{if(event.target===this.canvas || event.target===this.nodes || event.target===this.wires){this.edge=null;this.pending=null;this.onSelect?.(null);this.drawWires();}});
    this.listen(this.canvas,'dragover',event=>{if(this.editable() && Array.from(event.dataTransfer?.types || []).includes(MIME)){event.preventDefault();event.dataTransfer.dropEffect='copy';}});
    this.listen(this.canvas,'drop',event=>{const type=event.dataTransfer?.getData(MIME);if(!type)return;event.preventDefault();if(!this.editable())return;const p=this.point(event.clientX,event.clientY);this.add(type,p.x,p.y);});
    this.renderPalette();
  }
  listen(element,event,listener,options) {element?.addEventListener(event,listener,options);this.listeners.push(()=>element?.removeEventListener(event,listener,options));}
  editable() {return Boolean(this.isActive?.() && this.canEdit?.());}
  commit(operation,change) {
    if(!this.editable())return false;
    try {const next=operation(this.getProgram());this.pending=null;this.edge=null;this.onCommit(next,change);return true;}
    catch(error){this.onError?.(error.message);return false;}
  }
  point(clientX,clientY) {const rect=this.canvas.getBoundingClientRect(),zoom=this.getZoom?.() || 1;return {x:(clientX-rect.left)/zoom,y:(clientY-rect.top)/zoom};}
  portName(node,index) {return this.types[node.type]?.ports?.[index] || (node.type==='OUTPUT'?(index===0?'Enable':'Value'):fbdInputCount(node,this.types)===1?'Input':`Input ${index+1}`);}
  decorate() {
    const program=this.getProgram();if(!program)return;
    // A new render can represent a different program with reused block IDs.
    this.cancelPortDrag?.();this.dragCancel?.();this.pending=null;this.edge=null;
    const map=new Map(program.nodes.map(node=>[node.id,node]));
    for(const card of this.nodes.querySelectorAll('[data-node-id]')) {
      const node=map.get(card.dataset.nodeId);if(!node)continue;
      card.querySelectorAll('.node-port,[data-fbd-port]').forEach(port=>port.remove());
      card.classList.add('fbd-node');card.setAttribute('role','group');
      const count=fbdInputCount(node,this.types);
      card.style.minHeight=`${Math.max(160,64+count*28)}px`;
      for(let index=0;index<count;index++)this.createPort(card,node,'input',index,count);
      if(node.type!=='OUTPUT')this.createPort(card,node,'output',0,count);
    }
    this.refresh();
  }
  createPort(card,node,kind,index,count) {
    const port=this.document.createElement('button');port.type='button';port.className=`fbd-port fbd-port-${kind}`;
    port.dataset.fbdPort=kind;port.dataset.fbdNode=node.id;
    if(kind==='input')port.dataset.fbdInput=String(index);else port.dataset.fbdOutput=node.id;
    const name=kind==='input'?this.portName(node,index):'Output';
    port.setAttribute('aria-label',`${node.label || node.id}: ${name}. Select another port to connect.`);port.title=`${name} · click or drag to connect`;
    port.style.top=kind==='input'?`${64+index*28}px`:`${Math.max(79,64+(count-1)*14)}px`;
    const label=this.document.createElement('span');label.className='fbd-port-label';label.textContent=kind==='input'?name:'OUT';port.append(label);
    port.addEventListener('pointerdown',event=>this.portPointerDown(event,port));
    port.addEventListener('click',event=>{event.stopPropagation();if(this.suppressClick){this.suppressClick=false;return;}this.pickPort(port);});
    port.addEventListener('keydown',event=>{if(['Enter',' '].includes(event.key)){event.stopPropagation();event.preventDefault();this.pickPort(port);}});
    card.append(port);
  }
  portData(port) {return {kind:port.dataset.fbdPort,nodeId:port.dataset.fbdNode,index:Number(port.dataset.fbdInput || 0)};}
  pickPort(port) {
    if(!this.editable())return;
    const current=this.portData(port),pending=this.pending;
    if(pending && pending.kind!==current.kind) {
      const source=pending.kind==='output'?pending:current,target=pending.kind==='input'?pending:current;
      this.commit(program=>connectFbd(program,source.nodeId,target.nodeId,target.index,{types:this.types,devices:this.getDevices?.() || []}),{kind:'connect',sourceId:source.nodeId,targetId:target.nodeId,inputIndex:target.index});
    } else {this.pending=pending?.nodeId===current.nodeId&&pending.kind===current.kind&&pending.index===current.index?null:current;this.edge=null;this.drawWires();}
  }
  portPointerDown(event,port) {
    event.stopPropagation();if(event.button!==0 || !this.editable())return;
    this.cancelPortDrag?.();
    const startX=event.clientX,startY=event.clientY,origin=this.portData(port);let moved=false;
    const move=e=>{if(e.pointerId!==event.pointerId)return;if(!this.editable()){cancel();return;}if(Math.abs(e.clientX-startX)+Math.abs(e.clientY-startY)>5){moved=true;this.pending=origin;this.drawWires();this.drawPreview(origin,e.clientX,e.clientY);}};
    const finish=e=>{if(e.pointerId!==event.pointerId)return;cleanup();if(!moved)return;this.suppressClick=true;setTimeout(()=>{this.suppressClick=false;},0);const target=this.document.elementFromPoint(e.clientX,e.clientY)?.closest('[data-fbd-port]');if(e.type==='pointerup'&&target&&this.portData(target).kind!==origin.kind){this.pending=origin;this.pickPort(target);}else{this.pending=null;this.drawWires();}};
    const cleanup=()=>{this.document.removeEventListener('pointermove',move);this.document.removeEventListener('pointerup',finish);this.document.removeEventListener('pointercancel',finish);this.cancelPortDrag=null;};
    const cancel=()=>{cleanup();this.pending=null;this.drawWires();};
    this.cancelPortDrag=cancel;
    this.document.addEventListener('pointermove',move);this.document.addEventListener('pointerup',finish);this.document.addEventListener('pointercancel',finish);
  }
  findPort(nodeId,kind,index=0) {return Array.from(this.nodes.querySelectorAll('[data-fbd-port]')).find(port=>port.dataset.fbdNode===nodeId&&port.dataset.fbdPort===kind&&(kind==='output'||Number(port.dataset.fbdInput)===index));}
  layoutPorts() {
    for(const card of this.nodes.querySelectorAll('[data-node-id]')) {
      const inputs=Array.from(card.querySelectorAll('[data-fbd-port="input"]'));
      const top=Math.max(145,(card.querySelector('.node-head')?.offsetHeight || 0)+(card.querySelector('.node-body')?.offsetHeight || 0)+20);
      card.style.minHeight=`${top+Math.max(1,inputs.length)*28}px`;
      inputs.forEach((port,index)=>{port.style.top=`${top+index*28}px`;});
      const output=card.querySelector('[data-fbd-port="output"]');
      if(output)output.style.top=`${top+Math.max(0,inputs.length-1)*14}px`;
    }
  }
  portPoint(port) {const rect=port.getBoundingClientRect();return this.point(rect.left+rect.width/2,rect.top+rect.height/2);}
  path(a,b) {const bend=Math.max(45,Math.abs(b.x-a.x)*.45);return `M ${a.x} ${a.y} C ${a.x+bend} ${a.y}, ${b.x-bend} ${b.y}, ${b.x} ${b.y}`;}
  svgPath(d,className) {const path=this.document.createElementNS(NS,'path');path.setAttribute('d',d);path.setAttribute('class',className);return path;}
  drawPreview(origin,x,y) {const port=this.findPort(origin.nodeId,origin.kind,origin.index);if(!port)return;const a=this.portPoint(port),b=this.point(x,y);this.wires.append(this.svgPath(origin.kind==='output'?this.path(a,b):this.path(b,a),'fbd-wire-preview'));}
  drawWires() {
    this.layoutPorts();
    this.wires.replaceChildren();this.wires.removeAttribute('aria-hidden');
    for(const port of this.nodes.querySelectorAll('[data-fbd-port]')){const data=this.portData(port);port.classList.toggle('fbd-port-pending',Boolean(this.pending&&data.nodeId===this.pending.nodeId&&data.kind===this.pending.kind&&data.index===this.pending.index));}
    const program=this.getProgram();if(!program)return;
    const runtime=new Map((this.getRuntime?.()?.nodes || []).map(node=>[node.id,node]));
    for(const target of program.nodes) for(const [index,sourceId] of (target.inputs || []).entries()) {
      const sourcePort=this.findPort(sourceId,'output'),targetPort=this.findPort(target.id,'input',index);if(!sourcePort||!targetPort)continue;
      const d=this.path(this.portPoint(sourcePort),this.portPoint(targetPort)),value=runtime.get(sourceId);
      const selected=this.edge?.targetId===target.id&&this.edge?.inputIndex===index;
      const line=this.svgPath(d,`wire fbd-wire${selected?' fbd-wire-selected':''}${value?.valid===false?' invalid':value?.value===true?' active':''}`);this.wires.append(line);
      const hit=this.svgPath(d,'fbd-wire-hit');hit.dataset.fbdWire=`${target.id}:${index}`;hit.dataset.fbdTarget=target.id;hit.dataset.fbdInput=String(index);hit.tabIndex=0;hit.setAttribute('role','button');hit.setAttribute('aria-label',`${sourceId} to ${target.label || target.id}, ${this.portName(target,index)}. Select wire; Delete disconnects.`);
      const select=event=>{event.stopPropagation();this.pending=null;this.edge={targetId:target.id,inputIndex:index};this.onSelect?.(null);this.drawWires();};
      hit.addEventListener('click',select);hit.addEventListener('keydown',event=>{if(['Enter',' '].includes(event.key)){event.preventDefault();select(event);}});this.wires.append(hit);
    }
  }
  refresh() {
    const enabled=this.editable();
    if(!enabled){this.pending=null;this.cancelPortDrag?.();this.dragCancel?.();}
    this.canvas.classList.toggle('fbd-editable',enabled);
    for(const port of this.nodes.querySelectorAll('[data-fbd-port]'))port.disabled=!enabled;
    for(const button of this.palette?.querySelectorAll('[data-fbd-type]') || []){button.disabled=!enabled;button.draggable=enabled;}
    this.drawWires();
  }
  keydown(event) {
    if(!this.isActive?.())return;
    if(event.key==='Escape'){this.pending=null;this.edge=null;this.cancelPortDrag?.();this.dragCancel?.();this.drawWires();return;}
    if(event.key!=='Delete'||!this.editable()||event.target.closest?.('input,textarea,select,[contenteditable="true"],dialog'))return;
    const edge=this.edge,node=this.nodes.querySelector('.node.selected')?.dataset.nodeId;
    if(!edge&&!node)return;event.preventDefault();
    if(edge)this.commit(program=>disconnectFbd(program,edge.targetId,edge.inputIndex,{types:this.types}),{kind:'disconnect',...edge});
    else this.commit(program=>deleteFbdNode(program,node),{kind:'delete',nodeId:node});
  }
  handleNodePointerDown(event,node,card) {
    if(event.target.closest?.('[data-fbd-port],button,input,select,textarea') || event.button!==0 || !this.isActive?.())return;
    this.edge=null;this.pending=null;this.onSelect?.(node.id);if(!this.editable())return;
    const original=this.getProgram(),start={x:event.clientX,y:event.clientY},position={x:node.x,y:node.y};let moved=false;
    const move=e=>{if(e.pointerId!==event.pointerId)return;if(!this.editable()){cancel();return;}if(!moved&&Math.abs(e.clientX-start.x)+Math.abs(e.clientY-start.y)<5)return;moved=true;this.onDragState?.(true);position.x=clamp(node.x+(e.clientX-start.x)/(this.getZoom?.() || 1));position.y=clamp(node.y+(e.clientY-start.y)/(this.getZoom?.() || 1));card.style.left=`${position.x}px`;card.style.top=`${position.y}px`;this.drawWires();};
    const cleanup=()=>{this.document.removeEventListener('pointermove',move);this.document.removeEventListener('pointerup',finish);this.document.removeEventListener('pointercancel',cancel);this.dragCancel=null;this.onDragState?.(false);};
    const cancel=()=>{cleanup();card.style.left=`${node.x}px`;card.style.top=`${node.y}px`;this.drawWires();};
    const finish=e=>{if(e.pointerId!==event.pointerId)return;cleanup();if(moved && original===this.getProgram() && this.editable())this.commit(program=>moveFbdNode(program,node.id,position.x,position.y),{kind:'move',nodeId:node.id});else{card.style.left=`${node.x}px`;card.style.top=`${node.y}px`;this.drawWires();}};
    this.dragCancel=cancel;this.document.addEventListener('pointermove',move);this.document.addEventListener('pointerup',finish);this.document.addEventListener('pointercancel',cancel);
  }
  add(type,x,y) {
    const nextId={};const success=this.commit(program=>{const next=addFbdNode(program,type,{types:this.types,devices:this.getDevices?.() || [],x,y});nextId.id=next.nodes.at(-1).id;return next;},{kind:'add',type});if(success)this.onSelect?.(nextId.id);
  }
  renderPalette() {
    if(!this.palette)return;this.palette.replaceChildren();
    const title=this.document.createElement('strong');title.textContent='Function blocks';
    const help=this.document.createElement('p');help.className='fbd-palette-help';help.textContent='Drag a block onto the canvas, or tap to add. Connect OUT to an input. Select a wire and press Delete to disconnect.';
    this.palette.append(title,help);
    const categories=[...new Set(Object.values(this.types).map(meta=>meta.category || 'Blocks'))];
    for(const category of categories){const group=this.document.createElement('details');group.open=['I/O','Virtual','Logic'].includes(category);const heading=this.document.createElement('summary');heading.textContent=category;group.append(heading);
      for(const [type,meta] of Object.entries(this.types)){if((meta.category || 'Blocks')!==category)continue;const button=this.document.createElement('button');button.type='button';button.className='fbd-palette-block';button.dataset.fbdType=type;button.textContent=`${type} · ${meta.label}`;button.title=meta.description || '';button.draggable=true;button.addEventListener('dragstart',event=>{if(!this.editable()){event.preventDefault();return;}event.dataTransfer.setData(MIME,type);event.dataTransfer.effectAllowed='copy';});button.addEventListener('click',()=>{const zoom=this.getZoom?.() || 1;this.add(type,(this.scroll?.scrollLeft || 0)/zoom+65,(this.scroll?.scrollTop || 0)/zoom+65);});group.append(button);}this.palette.append(group);
    }
  }
  destroy() {this.cancelPortDrag?.();this.dragCancel?.();this.listeners.forEach(remove=>remove());this.listeners=[];this.pending=null;this.edge=null;}
}
