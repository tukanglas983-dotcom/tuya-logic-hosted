import {validateSchedule} from './schedule.js';
// Explicit, directed Ladder connections. Positions never infer electrical logic.
import {compileLadderV1} from './ladder.js';
const clone=value=>JSON.parse(JSON.stringify(value));
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const finite=value=>typeof value==='number'&&Number.isFinite(value);
const primitive=value=>typeof value==='boolean'||typeof value==='string'&&value.length<=2000||finite(value);
const math=new Set(['ADD','SUB','MUL','DIV','MOD','ABS','MIN','MAX','CLAMP','SELECT']);
const comparisons=new Set(['GT','GTE','LT','LTE','EQ','NEQ']);
const boolean=new Set(['AND','OR','XOR','NAND','NOR']);
const unary=new Set(['NOT','R_TRIG','F_TRIG','TON','TOF','PULSE','BLINK','SCHEDULE']);
const stateful=new Set(['TONR','COUNTER','CTD','CTUD','LATCH','SR']);
const fail=message=>{throw new Error(message);};
function id(value,label='Element ID'){if(typeof value!=='string'||!/^[A-Za-z][A-Za-z0-9_-]{0,23}$/.test(value))fail(`${label} must start with a letter and contain at most 24 letters, digits, underscores or hyphens.`);return value;}
function point(value){if(!plain(value)||!finite(value.x)||!finite(value.y)||Math.abs(value.x)>100000||Math.abs(value.y)>100000)fail('Network positions and wire points must contain finite coordinates within ±100000.');}
const minimumOperands=type=>type==='ABS'?1:['CLAMP','SELECT'].includes(type)?3:boolean.has(type)?1:2;
const operandCount=node=>{
  if(!math.has(node.type)&&!comparisons.has(node.type)&&!boolean.has(node.type))return 0;
  const count=Math.max(minimumOperands(node.type),node.operands?.length||0,...Object.keys(node.bindings||{}).filter(k=>/^operand\d+$/.test(k)).map(k=>Number(k.slice(7))+1));
  if(!Number.isSafeInteger(count)||count>99)fail('A function supports at most 99 explicit operands.');return count;
};

export function networkPorts(node){
  const power=(id,direction,multiple=false)=>({id,direction,kind:'power',dataType:'boolean',multiple});
  const data=(id,direction,dataType='primitive')=>({id,direction,kind:'data',dataType,multiple:false});
  if(node.nodeType==='rail')return [power('powerOut','out')];
  if(node.nodeType==='junction')return [power('powerIn','in',true),power('powerOut','out')];
  if(node.nodeType==='contact')return [power('powerIn','in'),power('powerOut','out'),data('result','out','boolean'),...(node.kind==='COMPARE'?[data('value','in')]:[])];
  if(node.nodeType==='coil')return [power('powerIn','in'),...(node.mode==='value'?[data('value','in')]:[])];
  if(node.nodeType!=='block')fail('Unknown network element type.');
  if(![math,comparisons,boolean,unary,stateful].some(types=>types.has(node.type)))fail(`Unsupported network instruction: ${node.type}.`);
  const result=[power('powerIn','in'),power('powerOut','out'),data('result','out',math.has(node.type)?node.type==='SELECT'?'primitive':'number':'boolean')];
  for(let i=0;i<operandCount(node);i++)result.push(data('operand'+i,'in',boolean.has(node.type)?'boolean':node.type==='SELECT'?(i===0?'boolean':'primitive'):['EQ','NEQ'].includes(node.type)?'primitive':'number'));
  if(stateful.has(node.type))result.push(data('reset','in','boolean'));
  if(node.type==='CTUD')result.push(data('down','in','boolean'));
  return result;
}

function localBinding(node,port){
  const direct=node.bindings?.[port];let legacy;
  if(/^operand\d+$/.test(port))legacy=node.operands?.[Number(port.slice(7))];
  else if(port==='reset'&&node.resetTagId)legacy={tagId:node.resetTagId};
  else if(port==='down'&&node.downTagId)legacy={tagId:node.downTagId};
  else if(port==='value'&&node.nodeType==='coil')legacy=node.source;
  else if(port==='value'&&node.nodeType==='contact')legacy=node.valueTagId?{tagId:node.valueTagId}:Object.hasOwn(node,'value')?{value:node.value}:undefined;
  if(direct!=null&&legacy!=null)fail(`Input ${node.id}.${port} has two local bindings.`);
  return direct??legacy;
}

function normalizeNetwork(source,{draft=false}={}){
  if(!plain(source)||source.version!==2||!Array.isArray(source.tags)||!Array.isArray(source.rungs)||source.tags.length>512||source.rungs.length>64)fail('A version 2 Ladder network supports up to 512 tags and 64 rungs.');
  const ladder=clone(source),rungs=new Set();let count=0,edgesCount=0;
  if(!draft)ladder.tags=compileLadderV1({version:1,tags:ladder.tags,rungs:[]}).ladder.tags;
  else {const tags=new Set();for(const tag of ladder.tags){if(!plain(tag))fail('Invalid network tag.');id(tag.id,'Tag ID');if(tags.has(tag.id))fail(`Duplicate tag: ${tag.id}.`);tags.add(tag.id);}}
  for(const rung of ladder.rungs){
    if(!plain(rung))fail('Invalid network rung.');id(rung.id,'Rung ID');if(rungs.has(rung.id))fail(`Duplicate rung: ${rung.id}.`);rungs.add(rung.id);
    rung.name=rung.name??rung.id;if(typeof rung.name!=='string'||!rung.name.trim()||rung.name.length>160)fail('A rung name must contain 1–160 characters.');
    if(!Array.isArray(rung.nodes)||!Array.isArray(rung.edges))fail('Network rungs require nodes and edges arrays.');
    count+=rung.nodes.length;edgesCount+=rung.edges.length;if(count>512||edgesCount>2048)fail('A Ladder network supports up to 512 elements and 2048 wires.');
    const nodes=new Map(),ports=new Map(),edgeIds=new Set(),drivers=new Map(),dependencies=new Map();
    for(const node of rung.nodes){
      if(!plain(node))fail('Invalid network element.');id(node.id);if(nodes.has(node.id))fail(`Duplicate network element: ${node.id}.`);
      point(node.position);if(node.operands!==undefined&&(!Array.isArray(node.operands)||node.operands.length>99))fail('Function operands must be an array of at most 99 bindings.');
      if(node.bindings!==undefined&&!plain(node.bindings))fail('Function bindings must be an object.');
      if(node.nodeType==='contact'&&!['NO','NC','COMPARE'].includes(node.kind))fail('Select a supported contact kind.');
      const list=networkPorts(node);if(list.length>104)fail('Too many function ports.');
      nodes.set(node.id,node);ports.set(node.id,new Map(list.map(port=>[port.id,port])));dependencies.set(node.id,[]);
      for(const key of Object.keys(node.bindings||{})){const port=ports.get(node.id).get(key);if(!port||port.direction!=='in'||port.kind!=='data')fail(`Unknown binding port ${node.id}.${key}.`);}
      for(const port of list.filter(port=>port.direction==='in'&&port.kind==='data'))localBinding(node,port.id);
    }
    for(const edge of rung.edges){
      if(!plain(edge))fail('Invalid network wire.');id(edge.id,'Wire ID');if(edgeIds.has(edge.id))fail(`Duplicate wire: ${edge.id}.`);edgeIds.add(edge.id);
      if(!plain(edge.from)||!plain(edge.to))fail('A wire needs explicit source and destination ports.');
      const from=ports.get(edge.from.nodeId)?.get(edge.from.port),to=ports.get(edge.to.nodeId)?.get(edge.to.port);
      if(!from||!to)fail(`Wire ${edge.id} references a missing element or port.`);
      if(from.direction!=='out'||to.direction!=='in'||from.kind!==to.kind)fail(`Wire ${edge.id} must connect an output to a compatible input port.`);
      if(from.dataType!=='primitive'&&to.dataType!=='primitive'&&from.dataType!==to.dataType)fail(`Wire ${edge.id} has incompatible data types.`);
      const key=edge.to.nodeId+'.'+edge.to.port,previous=drivers.get(key)||[];
      if(previous.length&&!to.multiple)fail(`Input ${key} already has a wire. Use a junction to merge power paths.`);
      if(previous.some(item=>item.from.nodeId===edge.from.nodeId&&item.from.port===edge.from.port))fail(`Duplicate connection into ${key}.`);
      previous.push(edge);drivers.set(key,previous);dependencies.get(edge.to.nodeId).push(edge.from.nodeId);
      if(to.kind==='data'&&localBinding(nodes.get(edge.to.nodeId),edge.to.port)!=null)fail(`Input ${key} cannot have both a wire and a local binding.`);
      if(edge.waypoints===undefined)edge.waypoints=[];
      if(!Array.isArray(edge.waypoints)||edge.waypoints.length>128)fail('A wire supports up to 128 waypoints.');edge.waypoints.forEach(point);
    }
    const active=new Set(),done=new Set();
    const visit=nodeId=>{if(active.has(nodeId))fail(`Cycle detected at ${nodeId}.`);if(done.has(nodeId))return;active.add(nodeId);for(const upstream of dependencies.get(nodeId))visit(upstream);active.delete(nodeId);done.add(nodeId);};
    for(const nodeId of nodes.keys())visit(nodeId);
    if(!draft){
      const powerEdges=rung.edges.filter(edge=>edge.from.port==='powerOut'),reachable=new Set(),useful=new Set();
      const walk=(nodeId,set,reverse)=>{if(set.has(nodeId))return;set.add(nodeId);for(const edge of powerEdges)if((reverse?edge.to.nodeId:edge.from.nodeId)===nodeId)walk(reverse?edge.from.nodeId:edge.to.nodeId,set,reverse);};
      for(const node of rung.nodes){if(node.nodeType==='rail')walk(node.id,reachable,false);if(node.nodeType==='coil')walk(node.id,useful,true);}
      if(!rung.nodes.length||!rung.nodes.some(node=>node.nodeType==='rail')||!rung.nodes.some(node=>node.nodeType==='coil'))fail(`${rung.name} needs a rail and an output coil.`);
      for(const node of rung.nodes){
        if(!reachable.has(node.id)||!useful.has(node.id))fail(`Element ${node.id} is disconnected from a rail-to-coil power path.`);
        if(node.nodeType!=='rail'&&!drivers.get(node.id+'.powerIn')?.length)fail(`Connect the power input of ${node.id}.`);
      }
    }
  }
  return ladder;
}

export function validateNetwork(source,{draft=false}={}){const ladder=normalizeNetwork(source,{draft});if(!draft)compileNormalized(ladder,{});return ladder;}
export function compileNetwork(source,options={}){return compileNormalized(normalizeNetwork(source),options);}

function compileNormalized(ladder,{id:programId='ladder-program',name='Ladder program'}={}){
  const nodes=[],types=new Map(),ids=new Set(),tags=new Map(ladder.tags.map(tag=>[tag.id,tag])),inputs=new Map(),written=new Set(),networkMap={};
  const add=(id,type,refs=[],params={},label=type)=>{
    if(type==='SCHEDULE')params=validateSchedule(params);
    if(ids.has(id))fail(`Duplicate compiled element: ${id}.`);if(nodes.length>=512)fail('The compiled ladder exceeds 512 logic blocks.');
    const ts=refs.map(ref=>types.get(ref)),many=boolean.has(type)||['MIN','MAX'].includes(type),arity=['CONST','INPUT','VIRTUAL'].includes(type)?0:unary.has(type)||type==='ABS'?1:['CLAMP','SELECT','CTUD'].includes(type)?3:type==='OUTPUT'&&params.mode==='value'?2:type==='OUTPUT'?1:2;
    if(many?refs.length<2||refs.length>100:refs.length!==arity)fail(`Incorrect input count for ${type}.`);
    if(math.has(type)&&type!=='SELECT'||['GT','GTE','LT','LTE'].includes(type)){if(ts.some(t=>t!=='number'))fail(`${type} requires numeric operands.`);}
    else if(['EQ','NEQ'].includes(type)){if(ts[0]!==ts[1])fail(`${type} requires matching operand types.`);}
    else if(type==='SELECT'){if(ts[0]!=='boolean'||ts[1]!==ts[2])fail('SELECT requires a boolean condition and matching value types.');}
    else if(!['CONST','INPUT','VIRTUAL'].includes(type)&&ts.slice(0,type==='OUTPUT'&&params.mode==='value'?1:undefined).some(t=>t!=='boolean'))fail(`${type} requires boolean operands.`);
    if(['TON','TOF','PULSE','TONR'].includes(type)&&(!Number.isSafeInteger(params.durationMs)||params.durationMs<0))fail(`${type} duration must be an integer >= 0 milliseconds.`);
    if(type==='BLINK'&&(!['onMs','offMs'].every(key=>Number.isSafeInteger(params[key])&&params[key]>=100)||!Number.isSafeInteger(params.onMs+params.offMs)))fail('BLINK periods must be valid integer durations of at least 100 milliseconds.');
    if(['COUNTER','CTD','CTUD'].includes(type)&&(!Number.isSafeInteger(params.preset)||params.preset<1))fail('Counter preset must be a positive integer.');
    ids.add(id);types.set(id,type==='CONST'?typeof params.value:type==='SELECT'?ts[1]:math.has(type)?'number':'boolean');nodes.push({id,type,label,inputs:refs,params});return id;
  };
  const constant=(id,value)=>{if(!primitive(value))fail('A constant must be a finite number, boolean, or text of at most 2000 characters.');return add(id,'CONST',[],{value},(typeof value==='string'?JSON.stringify(value):String(value)).slice(0,160));};
  const tagFor=tagId=>tags.get(tagId)||fail(`Map the I/O tag ${tagId||'(not selected)'} before saving.`);
  const input=tagId=>{const tag=tagFor(tagId);if(tag.direction!=='input')fail(`Use a readable input tag for ${tag.name}.`);if(!inputs.has(tagId)){const ref=tag.source==='virtual'?add('tag_'+tagId,'VIRTUAL',[],{defaultValue:tag.dataType==='number'?tag.defaultValue:false,...(tag.unit!==undefined?{unit:tag.unit}:{})},tag.name):add('tag_'+tagId,'INPUT',[],{deviceId:tag.deviceId,code:tag.code,scale:tag.scale,offset:tag.offset},`${tag.address} · ${tag.name}`);inputs.set(tagId,ref);types.set(ref,tag.dataType);}return inputs.get(tagId);};
  for(const rung of ladder.rungs){
    const byId=new Map(rung.nodes.map(node=>[node.id,node])),compiled=new Set(),map=networkMap[rung.id]={nodes:{},edges:{}},prefix='ld_'+rung.id+'_';
    const incoming=(nodeId,port)=>rung.edges.filter(edge=>edge.to.nodeId===nodeId&&edge.to.port===port);
    const edgeRef=edge=>{compileNode(edge.from.nodeId);const ref=map.nodes[edge.from.nodeId][edge.from.port];if(!ref)fail(`Missing compiled port ${edge.from.nodeId}.${edge.from.port}.`);map.edges[edge.id]=ref;return ref;};
    const binding=(node,port,key)=>{
      const edges=incoming(node.id,port);if(edges.length)return edgeRef(edges[0]);
      const value=localBinding(node,port);if(!plain(value))fail(`Connect or bind ${node.id}.${port} before saving.`);
      const keys=Object.keys(value);if(keys.length!==1)fail(`Choose exactly one tag or constant for ${node.id}.${port}.`);
      if(keys[0]==='tagId')return input(value.tagId);
      if(keys[0]==='value')return constant(key,value.value);
      fail(`Invalid binding for ${node.id}.${port}; use an explicit result wire for function references.`);
    };
    function compileNode(nodeId){
      if(compiled.has(nodeId))return;const node=byId.get(nodeId),base=prefix+nodeId,resultMap=map.nodes[nodeId]={};
      if(node.nodeType==='rail'){resultMap.powerOut=constant(base,true);compiled.add(nodeId);return;}
      const sources=incoming(nodeId,'powerIn').map(edgeRef);let flow=sources.length===1?sources[0]:add(base+'_join','OR',sources);resultMap.powerIn=flow;
      if(node.nodeType==='junction')resultMap.powerOut=flow;
      else if(node.nodeType==='contact'){
        const tag=tagFor(node.tagId),ref=input(node.tagId);let predicate;
        if(['NO','NC'].includes(node.kind)){if(tag.dataType!=='boolean')fail('NO and NC contacts require boolean input tags.');predicate=node.kind==='NC'?add(base+'_predicate','NOT',[ref]):ref;}
        else {if(!comparisons.has(node.operator))fail('Select a supported comparison operator.');predicate=add(base+'_predicate',node.operator,[ref,binding(node,'value',base+'_value')]);}
        resultMap.predicate=predicate;resultMap.result=predicate;resultMap.powerOut=add(base,'AND',[flow,predicate],{},tag.address);
      }else if(node.nodeType==='block'){
        const params=node.params??{};if(!plain(params))fail('Instruction parameters must be an object.');let refs,result;
        if(math.has(node.type)||comparisons.has(node.type)){refs=Array.from({length:operandCount(node)},(_,i)=>binding(node,'operand'+i,base+'_v'+i));result=add(base,node.type,refs,params);if(comparisons.has(node.type))flow=add(base+'_gate','AND',[flow,result]);}
        else if(boolean.has(node.type)){refs=[flow,...Array.from({length:operandCount(node)},(_,i)=>binding(node,'operand'+i,base+'_v'+i))];flow=result=add(base,node.type,refs,params);}
        else if(unary.has(node.type))flow=result=add(base,node.type,[flow],params);
        else {refs=node.type==='CTUD'?[flow,binding(node,'down',base+'_down'),binding(node,'reset',base+'_reset')]:[flow,binding(node,'reset',base+'_reset')];flow=result=add(base,node.type,refs,params);}
        resultMap.result=result;resultMap.powerOut=flow;
      }else if(node.nodeType==='coil'){
        const tag=tagFor(node.tagId),mode=node.mode||'follow';if(tag.direction!=='output')fail('Select a writable output tag for the coil.');
        const physical=tag.deviceId+'\0'+tag.code;if(written.has(physical))fail(`Only one coil may write ${tag.name}.`);written.add(physical);
        if(!['trigger','follow','pulse','value','adjust'].includes(mode))fail('Select a supported output execution mode.');
        if(['follow','pulse'].includes(mode)&&tag.dataType!=='boolean')fail('Continuous and Pulse require a boolean output.');
        const params={deviceId:tag.deviceId,code:tag.code,mode};
        if(['trigger','pulse'].includes(mode)){if(!primitive(node.value)||typeof node.value!==tag.dataType)fail('The output action value must match its tag type.');params.value=node.value;}
        if(mode==='pulse'){if(!Number.isSafeInteger(node.durationMs)||node.durationMs<100||node.durationMs>86400000)fail('Pulse duration must be 100–86400000 milliseconds.');params.durationMs=node.durationMs;}
        if(mode==='adjust'){if(tag.dataType!=='number'||!finite(node.delta)||node.delta===0)fail('Adjustment requires a numeric output and a finite nonzero delta.');params.delta=node.delta;}
        const refs=[flow];if(mode==='value'){const value=binding(node,'value',base+'_value');if(types.get(value)!==tag.dataType)fail('The dynamic output source type must match its output tag.');refs.push(value);resultMap.value=value;}
        resultMap.result=add(base,'OUTPUT',refs,params,`${tag.address} · ${tag.name}`);
      }
      compiled.add(nodeId);
    }
    for(const node of rung.nodes)compileNode(node.id);
    for(const edge of rung.edges)edgeRef(edge);
  }
  if(typeof programId!=='string'||!programId.trim()||programId.length>80||typeof name!=='string'||!name.trim()||name.length>160)fail('Invalid Ladder program name or ID.');
  return {id:programId,name,nodes,ladder,networkMap};
}

export function migrateLadderToNetwork(source,{allowIncomplete=false}={}){
  if(source?.version===2)return validateNetwork(source,{draft:allowIncomplete});
  if(!plain(source)||source.version!==1||!Array.isArray(source.tags)||!Array.isArray(source.rungs))fail('Unsupported Ladder migration source.');
  if(!allowIncomplete)compileLadderV1(source);
  const network={...clone(source),version:2,rungs:[]};
  for(const old of source.rungs){
    if(!Array.isArray(old.branches)||old.blocks!==undefined&&!Array.isArray(old.blocks))fail('Invalid legacy rung.');
    const rung={...clone(old),id:old.id,name:old.name??old.id,nodes:[],edges:[]},used=new Set([...old.branches.map(branch=>branch.id),...old.branches.flatMap(branch=>(branch.contacts||[]).map(contact=>contact.id)),...(old.blocks||[]).map(block=>block.id)]);delete rung.branches;delete rung.blocks;delete rung.coil;let edgeIndex=0;
    const unique=base=>{let candidate=base,index=1;while(used.has(candidate))candidate=base+(index++);used.add(candidate);return candidate;};
    const rail=unique('rail'),join=unique('join'),coil=unique('coil');
    const wire=(from,port,to,target)=>rung.edges.push({id:'wire'+(++edgeIndex),from:{nodeId:from,port},to:{nodeId:to,port:target},waypoints:[]});
    rung.nodes.push({id:rail,nodeType:'rail',position:{x:40,y:100}});
    const maxContacts=Math.max(0,...old.branches.map(branch=>branch.contacts?.length||0));
    rung.nodes.push({id:join,nodeType:'junction',position:{x:260+maxContacts*180,y:100}});
    for(const [branchIndex,branch]of old.branches.entries()){
      if(!Array.isArray(branch.contacts))fail('Invalid legacy branch.');let previous=rail;
      for(const [index,contact]of branch.contacts.entries()){rung.nodes.push({...clone(contact),nodeType:'contact',position:{x:220+index*180,y:100+branchIndex*140}});wire(previous,'powerOut',contact.id,'powerIn');previous=contact.id;}
      rung.nodes.push({id:branch.id,nodeType:'junction',position:{x:210+maxContacts*180,y:100+branchIndex*140}});wire(previous,'powerOut',branch.id,'powerIn');wire(branch.id,'powerOut',join,'powerIn');
    }
    let previous=join;
    for(const [index,block]of (old.blocks||[]).entries()){
      const node={...clone(block),nodeType:'block',position:{x:440+maxContacts*180+index*200,y:100}};
      if(stateful.has(block.type)&&!block.resetTagId)node.bindings={...(node.bindings||{}),reset:{value:false}};
      if(block.type==='CTUD'&&!block.downTagId)node.bindings={...(node.bindings||{}),down:{value:false}};
      rung.nodes.push(node);wire(previous,'powerOut',node.id,'powerIn');previous=node.id;
    }
    rung.nodes.push({...clone(old.coil||{tagId:'',mode:'follow',value:false}),id:coil,nodeType:'coil',position:{x:480+maxContacts*180+(old.blocks||[]).length*200,y:100}});wire(previous,'powerOut',coil,'powerIn');
    for(const node of rung.nodes){
      for(const [index,operand]of (node.operands||[]).entries())if(operand?.blockId){wire(operand.blockId,'result',node.id,'operand'+index);node.operands[index]=null;}
      if(node.nodeType==='coil'&&node.source?.blockId){wire(node.source.blockId,'result',node.id,'value');delete node.source;}
    }
    network.rungs.push(rung);
  }
  return validateNetwork(network,{draft:allowIncomplete});
}
