// Shared daily schedule rules; runtime time is supplied by the server engine.
const formatters=new Map();
function minuteOfDay(value,label){
  if(typeof value!=='string'||!/^([01]\d|2[0-3]):[0-5]\d$/.test(value))throw new Error(label+' must use 24-hour HH:MM format.');
  return Number(value.slice(0,2))*60+Number(value.slice(3));
}
function formatter(timeZone){
  if(typeof timeZone!=='string'||!timeZone||timeZone!==timeZone.trim()||timeZone.length>100)throw new Error('Select a valid schedule time zone.');
  if(formatters.has(timeZone))return formatters.get(timeZone);
  let result;try{result=new Intl.DateTimeFormat('en-GB-u-nu-latn',{timeZone,hour:'2-digit',minute:'2-digit',hourCycle:'h23'});}catch{throw new Error('Unknown schedule time zone: '+timeZone+'.');}
  // A small shared cache avoids creating formatters on each PLC scan.
  if(formatters.size>=64)formatters.delete(formatters.keys().next().value);
  formatters.set(timeZone,result);return result;
}
export function validateSchedule(params){
  if(!params||typeof params!=='object'||Array.isArray(params))throw new Error('Set daily schedule parameters.');
  const start=minuteOfDay(params.start,'Schedule start'),end=minuteOfDay(params.end,'Schedule end');
  if(start===end)throw new Error('Schedule start and end must be different.');
  formatter(params.timeZone);return {start:params.start,end:params.end,timeZone:params.timeZone};
}
export function scheduleActive(params,wallEpochMs){
  if(typeof wallEpochMs!=='number'||!Number.isFinite(wallEpochMs)||!Number.isFinite(new Date(wallEpochMs).getTime()))throw new Error('The server wall clock is invalid.');
  const start=minuteOfDay(params.start,'Schedule start'),end=minuteOfDay(params.end,'Schedule end');
  if(start===end)throw new Error('Schedule start and end must be different.');
  const parts=formatter(params.timeZone).formatToParts(wallEpochMs),hour=Number(parts.find(part=>part.type==='hour')?.value),minute=Number(parts.find(part=>part.type==='minute')?.value);
  if(!Number.isInteger(hour)||hour<0||hour>23||!Number.isInteger(minute)||minute<0||minute>59)throw new Error('The server local time could not be read.');
  const current=hour*60+minute;return start<end?current>=start&&current<end:current>=start||current<end;
}
