import {propertyLabel,hasNonLatinLetters,propertyQuality,featureHelp} from './property-labels.js';
import {migrateLadderToNetwork} from './ladder-network.js';
import {LadderCanvas} from './ladder-canvas.js';
import {validateSchedule} from './schedule.js';
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const copy = value => JSON.parse(JSON.stringify(value));
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
export function dailyScheduleDefaults(){return {start:'17:30',end:'05:30',timeZone:'Asia/Jakarta'};}
export function dailyScheduleFields(params={}){
  const p={...dailyScheduleDefaults(),...params};
  return '<div class="input-row"><label>Start time<input type="time" step="60" required data-schedule-param="start" value="'+esc(p.start)+'"></label><label>End time<input type="time" step="60" required data-schedule-param="end" value="'+esc(p.end)+'"></label></div><label>Time zone<input type="text" required maxlength="80" list="daily-schedule-zones" data-schedule-param="timeZone" value="'+esc(p.timeZone)+'" placeholder="Asia/Jakarta"></label><datalist id="daily-schedule-zones"><option value="Asia/Jakarta">WIB (UTC+7)</option><option value="Asia/Makassar">WITA (UTC+8)</option><option value="Asia/Jayapura">WIT (UTC+9)</option><option value="UTC">UTC</option></datalist><p class="field-help">Every day in the selected time zone. Overnight ranges cross midnight. The start time is included; the end time is excluded. Output is TRUE only while enabled and inside this window.</p>';
}
export function updateDailySchedule(params,key,value){
  if(!['start','end','timeZone'].includes(key))throw new Error('Unknown schedule setting.');
  return validateSchedule({...dailyScheduleDefaults(),...params,[key]:value.trim()});
}
const timerTypes = ['TON','TOF','PULSE','TONR'];
const countTypes = ['COUNTER','CTD','CTUD'];
const primitiveTypes={bool:'boolean',boolean:'boolean',value:'number',integer:'number',float:'number',double:'number',enum:'string',string:'string'};
const operandCounts = {ADD:2,SUB:2,MUL:2,DIV:2,MOD:2,ABS:1,MIN:2,MAX:2,CLAMP:3,SELECT:3,GT:2,GTE:2,LT:2,LTE:2,EQ:2,NEQ:2,AND:1,OR:1,XOR:1,NAND:1,NOR:1};
const glyphs = {
  NO:'<path d="M0 20h21m8 0h21M21 7v26m8-26v26"/>',
  NC:'<path d="M0 20h21m8 0h21M21 7v26m8-26v26M17 34 33 6"/>',
  coil:'<path d="M0 20h16m18 0h16M21 6c-12 8-12 20 0 28M29 6c12 8 12 20 0 28"/>'
};
function propertyModel(device) {
  const props = new Map((device?.model || []).map(p=>[p.code,p]));
  for(const [code,p] of Object.entries(device?.properties || {})) if(!props.has(code))props.set(code,{code,name:code,accessMode:p.writable?'rw':'ro',typeSpec:{type:p.type || (typeof p.value==='boolean'?'bool':typeof p.value==='number'?'value':'string'),unit:p.unit,scale:p.scale}});
  return [...props.values()];
}
function primitive(type, value) {return type==='boolean'?value==='true':type==='number'?Number(value):value;}
function valueText(value) {return typeof value==='boolean'?value?'TRUE':'FALSE':typeof value==='number'?new Intl.NumberFormat('en-US',{maximumFractionDigits:3}).format(value):String(value ?? '—');}
function deviceValueText(value,property,feature) {
  if(typeof value==='boolean')return value?'ON':'OFF';
  if(typeof value==='number'&&Number.isFinite(value)){
    const scale=Number(property?.scale ?? feature?.typeSpec?.scale ?? 0),factor=10**(Number.isInteger(scale)&&scale>=0&&scale<=15?scale:0),unit=property?.unit ?? feature?.typeSpec?.unit ?? '';
    return new Intl.NumberFormat('en-US',{maximumFractionDigits:6}).format(value/factor)+(unit?' '+unit:'');
  }
  if(value===undefined||value===null)return 'Unknown';
  if(typeof value==='object'){try{return JSON.stringify(value);}catch{return 'Unsupported value';}}
  return String(value);
}
export function deriveCoilFeedback({device,property,feature,output,feedback,running=false,executionMode=null,mapped=true}={}) {
  const quality=propertyQuality(property,device),hasValue=property&&Object.hasOwn(property,'value')&&property.value!==undefined&&property.value!==null;
  const writeOnly=['wr','wo'].includes(feature?.accessMode),fresh=!!device?.online&&quality.valid&&!!hasValue&&!writeOnly;
  const reason=!mapped?'unmapped':device?.online===false?'offline':writeOnly?'writeonly':!device||!hasValue?'missing':quality.reason==='fresh'&&!fresh?'missing':quality.reason;
  const qualityLabels={unmapped:'Unmapped',offline:'Offline',disconnected:'Disconnected',readfailed:'Read failed',stale:'Stale',missing:'Unknown',writeonly:'No readback'};
  const actualValue=hasValue?property.value:undefined,actualText=deviceValueText(actualValue,property,feature),qualityLabel=qualityLabels[reason] || 'Unknown';
  const deviceText=fresh?actualText:qualityLabel+(hasValue&&!writeOnly?' · last '+actualText:'');
  const logicValue=typeof output?.enabled==='boolean'?output.enabled:typeof output?.value==='boolean'?output.value:null;
  const logicText=!running?'Stopped':!output||output.valid===false||logicValue===null?'Unknown':logicValue?'ON':'OFF';
  const desired=feedback&&Object.hasOwn(feedback,'desiredValue'),desiredText=desired?deviceValueText(feedback.desiredValue,property,feature):'—';
  const matches=desired&&(typeof actualValue==='number'&&typeof feedback.desiredValue==='number'?Math.abs(actualValue-feedback.desiredValue)<=1e-9*Math.max(1,Math.abs(actualValue),Math.abs(feedback.desiredValue)):actualValue===feedback.desiredValue);
  let commandText='Idle',commandKind='idle';
  if(feedback?.commandState==='simulated'){commandText='Simulated';commandKind='simulated';}
  else if(feedback?.commandState==='failed'){commandText='Failed';commandKind='failed';}
  else if(feedback?.commandState==='cancelled'){commandText='Cancelled';commandKind='cancelled';}
  else if(feedback?.commandState==='pending'){commandText='Sending…';commandKind='pending';}
  else if(feedback?.commandState==='confirmed'){
    if(!fresh){commandText=qualityLabel;commandKind='unverified';}
    else if(desired&&!matches){commandText='Mismatch';commandKind='mismatch';}
    else{commandText='Confirmed';commandKind='confirmed';}
  }else if(executionMode==='test'&&running){commandText='Simulated';commandKind='simulated';}
  return {logicText,logicOn:running&&output?.valid!==false&&logicValue===true,deviceText,actualValue,actualText,actualFresh:fresh,qualityLabel:fresh?'Fresh cloud data':qualityLabel,observation:quality.observation,desiredText,hasDesired:!!desired,commandText,commandKind,commandError:feedback?.commandError || ''};
}

export class LadderEditor {
  constructor({container,inspector,toolbox,types,onChange,onError,onMapping,onInspector,onVirtualInput,onPhysicalInput}) {
    this.container=container;this.inspector=inspector;this.toolbox=toolbox;this.types=types;this.onChange=onChange;this.onError=onError;this.onMapping=onMapping;this.onInspector=onInspector;this.onVirtualInput=onVirtualInput;this.onPhysicalInput=onPhysicalInput;
    this.ladder=null;this.devices=[];this.runtime={running:false,nodes:[]};this.selection=null;this.mode='ladder';this.counter=0;this.pendingCoilDevices=new Map();this.pendingContactDevices=new Map();
    this.paletteExpanded=new Set();this.paletteQuery='';this.placement=null;this.paletteSignature='';this.paletteDragging=false;this.workbench=null;this.toolboxQuery='';this.toolboxCategory='All';this.virtualPending=new Set();this.virtualPanelSignature='';this.virtualDrafts=new Map();this.physicalPending=new Set();this.physicalDrafts=new Map();this.forceFeatures=new Map();this.physicalPanelSignature='';
    this.graph=new LadderCanvas(this);
  }
  uid(prefix) {let id;do{id=`${prefix}-${Date.now().toString(36)}-${++this.counter}`;}while(JSON.stringify(this.ladder).includes(`"${id}"`));return id;}
  load(ladder) {this.ladder=ladder?copy(ladder):null;if(this.ladder?.version===1){try{this.ladder=migrateLadderToNetwork(this.ladder,{allowIncomplete:true});}catch(error){this.onError?.('This draft remains in the legacy layout: '+error.message);}}this.selection=null;this.pendingCoilDevices.clear();this.pendingContactDevices.clear();this.graph.pendingWire=null;this.clearPlacement();this.render();this.onInspector?.('instructions');}
  serialize() {return this.ladder?copy(this.ladder):null;}
  handleKeyDown(event) {
    if(this.ladder?.version===2&&this.graph.handleKeyDown(event))return true;
    if(!['Delete','Backspace'].includes(event.key)||event.defaultPrevented||event.repeat||event.isComposing||event.ctrlKey||event.altKey||event.metaKey||event.shiftKey)return false;
    if(!this.ladder||!this.selection||this.runtime.running||this.placement||this.paletteDragging)return false;
    if(!this.container.isConnected||this.container.closest('[hidden]')||!this.container.getClientRects().length)return false;
    const doc=this.container.ownerDocument,target=event.target,active=doc.activeElement;
    const editable=element=>element?.isContentEditable||element?.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"]),[role="textbox"]');
    if(editable(target)||editable(active))return false;
    if([...doc.querySelectorAll('dialog[open],[role="dialog"][aria-modal="true"]')].some(dialog=>!dialog.closest('[hidden]')&&dialog.getClientRects().length))return false;
    const inEditor=element=>element===doc||element===doc.body||element===doc.documentElement||this.container.contains(element)||this.inspector.contains(element);
    if(target&&!inEditor(target))return false;
    if(active&&!inEditor(active))return false;
    if(!this.deleteSelection())return false;
    event.preventDefault();event.stopPropagation();return true;
  }
  deleteSelection() {
    if(!this.ladder||!this.selection||this.runtime.running)return false;
    if(this.ladder.version===2&&this.selection.kind!=='tag')return this.graph.deleteSelection();
    const selection=this.selection,rung=this.ladder.rungs.find(r=>r.id===selection.rungId);
    const clearCoil=target=>{target.coil={deviceId:'',tagId:'',mode:'follow',value:false};this.pendingCoilDevices.delete(target.id);};
    if(selection.kind==='tag'){
      const index=this.ladder.tags.findIndex(tag=>tag.id===selection.id);if(index<0)return false;
      if(!confirm('Delete this I/O tag? Elements using it must be remapped before saving.'))return false;
      const [tag]=this.ladder.tags.splice(index,1);
      for(const item of this.ladder.rungs){
        if(this.ladder.version===2){for(const node of item.nodes)if(node.tagId===tag.id){node.tagId='';node.deviceId ||= tag.deviceId;}continue;}
        for(const branch of item.branches)for(const contact of branch.contacts)if(contact.tagId===tag.id){contact.tagId='';contact.deviceId ||= tag.deviceId;}
        if(item.coil?.tagId===tag.id)clearCoil(item);
      }
      // Reference tags deliberately remain unresolved. Falling back to a
      // constant, FALSE reset, or another output would change the program.
    }else{
      if(!rung)return false;
      if(selection.kind==='contact'){
        const branch=rung.branches.find(b=>b.id===selection.branchId),index=branch?.contacts.findIndex(c=>c.id===selection.id) ?? -1;if(index<0)return false;
        branch.contacts.splice(index,1);this.pendingContactDevices.delete(selection.id);
        if(!branch.contacts.length&&rung.branches.length>1)rung.branches=rung.branches.filter(item=>item!==branch);
      }else if(selection.kind==='block'){
        const index=(rung.blocks || []).findIndex(b=>b.id===selection.id);if(index<0)return false;
        rung.blocks.splice(index,1);
        // Keep dependent block IDs unresolved so Save requires a replacement.
      }else if(selection.kind==='coil'){
        if(selection.id!==`${rung.id}:coil`||!rung.coil)return false;
        const coil=rung.coil,assigned=coil.tagId||coil.deviceId||this.pendingCoilDevices.get(rung.id)||coil.mode&&coil.mode!=='follow'||coil.value!==undefined&&coil.value!==false||Object.keys(coil).some(key=>!['deviceId','tagId','mode','value'].includes(key));
        if(!assigned)return false;clearCoil(rung);
      }else if(selection.kind==='rung'){
        if(selection.id!==rung.id)return false;
        if(!confirm('Delete this rung and its elements?'))return false;
        this.ladder.rungs.splice(this.ladder.rungs.indexOf(rung),1);this.pendingCoilDevices.delete(rung.id);
        for(const branch of rung.branches)for(const contact of branch.contacts)this.pendingContactDevices.delete(contact.id);
      }else return false;
    }
    this.selection=null;this.clearPlacement();this.changed();this.onInspector?.('instructions');return true;
  }
  changed() {
    // Commit immediately, but let the browser finish its change/blur sequence
    // before replacing a focused form. Synthetic change events can otherwise
    // trigger a second native change while innerHTML removes the input.
    this.onChange?.();if(this.selection)this.onInspector?.('properties');
    if(this.pendingRender)return;
    this.pendingRender=setTimeout(()=>{this.pendingRender=null;if(!this.container.hidden)this.render();},0);
  }
  setMode(mode) {this.mode=mode;this.render();}
  refresh(devices,runtime) {
    this.devices=devices || [];this.runtime=runtime || {running:false,nodes:[]};
    if(this.runtime.running&&this.placement)this.clearPlacement();
    if(this.runtime.running)this.graph.pendingWire=null;
    this.renderDevicePalette();
    $$('[data-ladder-edit]',this.container).forEach(el=>el.disabled=!!this.runtime.running||el.dataset.unsupported==='true');
    $$('[data-movable]',this.container).forEach(el=>el.draggable=!this.runtime.running);
    $$('[data-port]',this.container).forEach(el=>el.disabled=!!this.runtime.running);
    if(this.inspector.dataset.owner==='ladder')$$('input,select,button',this.inspector).filter(el=>!el.hasAttribute('data-virtual-force')).forEach(el=>el.disabled=!!this.runtime.running);
    this.renderVirtualPanel();this.renderPhysicalPanel();this.refreshVirtualControls();this.refreshPhysicalControls();this.telemetry();
  }
  tag(id) {return this.ladder?.tags.find(t=>t.id===id);}
  virtualState(tag) {return (this.runtime.virtualInputs || []).find(input=>input.id===`tag_${tag?.id}`);}
  virtualButton(tag) {
    if(tag.dataType==='number')return `<div class="virtual-number-control"><span data-virtual-current="${esc(tag.id)}">—</span><div><input type="number" step="any" aria-label="Force ${esc(this.tagName(tag))}" data-virtual-value="${esc(tag.id)}" data-virtual-force="tag_${esc(tag.id)}" value="${esc(this.virtualDrafts.get(tag.id) ?? this.virtualState(tag)?.value ?? tag.defaultValue ?? 0)}"><button type="button" data-virtual-apply="${esc(tag.id)}" data-virtual-force="tag_${esc(tag.id)}">Apply</button></div></div>`;
    return `<button type="button" class="virtual-toggle" role="switch" aria-checked="false" aria-label="Toggle ${esc(this.tagName(tag))}" data-virtual-toggle="${esc(tag.id)}" data-virtual-force="tag_${esc(tag.id)}"><span aria-hidden="true"></span><strong>OFF</strong></button>`;
  }
  virtualHelp(tag) {return '<p class="virtual-input-help">Local forced '+(tag?.dataType==='number'?'numeric':'boolean')+' input. Test Run simulates output actions; Live Test sends output actions to real devices. Each start and stop resets this input to '+(tag?.dataType==='number'?esc(tag.defaultValue ?? 0)+(tag.unit?' '+esc(tag.unit):''):'OFF')+'. Stopping Live Test leaves physical outputs in their last actual state. Normal Run requires device inputs.</p>';}
  virtualFields(tag) {return `<span class="virtual-input-badge">VIRTUAL · FORCED INPUT</span><label>Virtual input name<input id="ladder-virtual-name" value="${esc(this.tagName(tag))}" maxlength="80"></label>${tag.dataType==='number'?`<div class="input-row"><label>Start / reset value<input id="ladder-virtual-default" type="number" step="any" value="${esc(tag.defaultValue ?? 0)}"></label><label>Unit<input id="ladder-virtual-unit" value="${esc(tag.unit || '')}" maxlength="16" placeholder="°C"></label></div>`:''}<div class="virtual-inspector-force"><span>${esc(tag.address)} · ${tag.dataType==='number'?'Analog value':'Boolean input'}</span>${this.virtualButton(tag)}</div>${this.virtualHelp(tag)}`;}
  createVirtualTag(dataType='boolean') {
    if(this.ladder.tags.length>=512)throw new Error('The program has reached the 512 I/O tag limit.');
    let number=0;const address=n=>dataType==='number'?`VA${n}`:`V${n}.0`;while(this.ladder.tags.some(tag=>String(tag.address || '').trim().toUpperCase()===address(number)))number++;
    const tag={id:this.uid('virtual'),name:`Virtual ${dataType==='number'?'analog input':'switch'} ${number+1}`,address:address(number),direction:'input',source:'virtual',dataType,scale:1,offset:0};if(dataType==='number'){tag.defaultValue=0;tag.unit='';}this.ladder.tags.push(tag);return tag;
  }
  ensureForcePanel() {
    if(!this.palette)return false;
    if(!this.forcePanel){this.forcePanel=document.createElement('section');this.forcePanel.id='ladder-force-io';this.forcePanel.className='ladder-force-io';this.forcePanel.innerHTML='<div class="force-panel-heading"><strong>Force I/O</strong><span data-force-mode>STOPPED</span></div><p class="force-panel-status"></p>';this.palette.insertBefore(this.forcePanel,$('.palette-content',this.palette));}
    const active=this.runtime.running&&['test','live-test'].includes(this.runtime.executionMode),live=active&&this.runtime.executionMode==='live-test';$('[data-force-mode]',this.forcePanel).textContent=live?'REAL DEVICES':active?'SIMULATED':'STOPPED';$('.force-panel-status',this.forcePanel).textContent=live?'Live Test sends commands to real devices. Feedback comes from the device.':active?'Test Run overrides inputs locally. No hardware commands.':'Start Test Run or Live Test to force inputs.';this.forcePanel.classList.toggle('live-test',live);return true;
  }
  renderVirtualPanel() {
    if(!this.ensureForcePanel())return;
    if(!this.virtualPanel){this.virtualPanel=document.createElement('section');this.virtualPanel.id='ladder-virtual-panel';this.virtualPanel.className='ladder-virtual-panel';this.virtualPanel.setAttribute('aria-label','Virtual inputs');this.forcePanel.append(this.virtualPanel);}
    const tags=(this.ladder?.tags || []).filter(tag=>tag.source==='virtual'),signature=JSON.stringify(tags.map(tag=>[tag.id,tag.name,tag.address,tag.dataType,tag.unit,tag.defaultValue]));this.virtualPanel.hidden=!tags.length;
    if(signature!==this.virtualPanelSignature){this.virtualPanelSignature=signature;this.virtualPanel.innerHTML='<div class="virtual-panel-heading"><strong>Virtual inputs</strong><span data-virtual-mode>VIRTUAL</span></div><div class="virtual-switch-list">'+tags.map(tag=>`<div class="virtual-switch-row${tag.dataType==='number'?' numeric':''}"><span><strong>${esc(this.tagName(tag))}</strong><small>${esc(tag.address)}${tag.unit?' · '+esc(tag.unit):''}</small></span>${this.virtualButton(tag)}</div>`).join('')+'</div>';this.bindVirtualControls(this.virtualPanel);}
    this.forcePanel.hidden=!tags.length&&!this.usedInputDevices().length;
  }
  bindVirtualControls(root) {
    $$('[data-virtual-toggle]',root).forEach(button=>button.onclick=()=>{if(!button.disabled)this.forceVirtualInput(button.dataset.virtualToggle);});
    $$('[data-virtual-value]',root).forEach(input=>input.oninput=()=>this.virtualDrafts.set(input.dataset.virtualValue,input.value));
    $$('[data-virtual-apply]',root).forEach(button=>button.onclick=()=>{if(button.disabled)return;const input=$$('[data-virtual-value]',root).find(item=>item.dataset.virtualValue===button.dataset.virtualApply);if(!input?.value||!input.checkValidity()||!Number.isFinite(Number(input.value))){this.onError?.('Enter a finite numeric input value.');return;}this.forceVirtualInput(button.dataset.virtualApply,Number(input.value));});
  }
  refreshVirtualControls() {
    for(const root of [this.virtualPanel,this.inspector?.dataset?.owner==='ladder'?this.inspector:null].filter(Boolean)){
      for(const button of $$('[data-virtual-force]',root)){
        const id=button.dataset.virtualToggle || button.dataset.virtualApply || button.dataset.virtualValue,tag=this.tag(id),entry=this.virtualState(tag),value=entry?.value ?? (tag?.dataType==='number'?tag.defaultValue ?? 0:false),testing=this.runtime.running&&['test','live-test'].includes(this.runtime.executionMode),busy=this.virtualPending.has(tag?.id),unavailable=!entry||tag?.source!=='virtual'||typeof this.onVirtualInput!=='function';
        button.dataset.busy=String(busy);button.dataset.virtualUnavailable=String(unavailable);button.disabled=!testing||busy||unavailable||button.dataset.virtualBlocked==='true';if(button.dataset.virtualToggle){button.setAttribute('aria-checked',String(value===true));button.classList.toggle('on',value===true);$('strong',button).textContent=value===true?'ON':'OFF';}button.title=busy?'Updating virtual input…':!testing?'Start Test Run or Live Test to force this input.':unavailable?'This input is not used by the running program.':'Force '+this.tagName(tag);
      }
      for(const current of $$('[data-virtual-current]',root)){const tag=this.tag(current.dataset.virtualCurrent);current.textContent='Current: '+valueText(this.virtualState(tag)?.value ?? tag?.defaultValue ?? 0)+(tag?.unit?' '+tag.unit:'');}
    }
  }
  async forceVirtualInput(tagId,explicitValue) {
    const tag=this.tag(tagId),entry=this.virtualState(tag);
    const blocked=[this.virtualPanel,this.inspector?.dataset?.owner==='ladder'?this.inspector:null].filter(Boolean).some(root=>$$('[data-virtual-force]',root).some(button=>(button.dataset.virtualToggle || button.dataset.virtualApply || button.dataset.virtualValue)===tagId&&button.dataset.virtualBlocked==='true'));
    if(blocked||!this.runtime.running||!['test','live-test'].includes(this.runtime.executionMode)||!entry||tag?.source!=='virtual'||this.virtualPending.has(tagId)||typeof this.onVirtualInput!=='function')return false;
    const value=tag.dataType==='number'?explicitValue:entry.value!==true;if(tag.dataType==='number'&&(typeof value!=='number'||!Number.isFinite(value)))return false;
    this.virtualPending.add(tagId);this.refreshVirtualControls();
    try{await this.onVirtualInput(entry.id,value);return true;}catch(error){this.onError?.(error.message || 'Unable to update this virtual input.');return false;}finally{this.virtualPending.delete(tagId);this.refreshVirtualControls();}
  }
  usedInputDevices() {
    const used=new Map(),add=tag=>{if(tag?.direction==='input'&&tag.source!=='virtual'&&tag.deviceId){const item=used.get(tag.deviceId) || {deviceId:tag.deviceId,codes:[]};if(tag.code&&!item.codes.includes(tag.code))item.codes.push(tag.code);used.set(tag.deviceId,item);}};
    const walk=value=>{if(!value||typeof value!=='object')return;for(const [key,item] of Object.entries(value)){if(['tagId','valueTagId','resetTagId','downTagId'].includes(key))add(this.tag(item));else if(typeof item==='object')walk(item);}};
    for(const rung of this.ladder?.rungs || []){walk(rung);for(const branch of rung.branches || [])for(const contact of branch.contacts || [])if(contact.deviceId&&!used.has(contact.deviceId))used.set(contact.deviceId,{deviceId:contact.deviceId,codes:[]});}
    return [...used.values()];
  }
  forceModel(deviceId,code) {
    const device=this.devices.find(item=>item.id===deviceId),feature=propertyModel(device).find(item=>item.code===code),spec=feature?.typeSpec || {},kind=primitiveTypes[spec.type],scale=Number(spec.scale || 0),factor=10**(Number.isInteger(scale)&&scale>=0&&scale<=15?scale:0),property=device?.properties?.[code];
    const forced=(this.runtime.inputForces || []).find(item=>item.deviceId===deviceId&&item.code===code),feedback=(this.runtime.inputForceFeedback || []).find(item=>item.deviceId===deviceId&&item.code===code);
    const actual=deriveCoilFeedback({device,property,feature,feedback,mapped:true}),active=!!this.runtime.running&&['test','live-test'].includes(this.runtime.executionMode),live=this.runtime.executionMode==='live-test';
    const outputConflict=(this.ladder?.rungs || []).some(rung=>(this.ladder.version===2?rung.nodes.filter(n=>n.nodeType==='coil'):[rung.coil]).some(coil=>{const tag=this.tag(coil?.tagId);return tag?.deviceId===deviceId&&tag.code===code;}));
    const reason=!active?'Start Test Run or Live Test to force inputs.':!feature?'Select an available feature.':!kind?'This data format cannot be forced.':['wr','wo'].includes(feature.accessMode)?'Write-only features cannot be used as inputs.':live&&feature.accessMode!=='rw'?'Read-only feature: simulate it in Test Run.':live&&outputConflict?'This feature is controlled by a program output.':live&&!actual.actualFresh?'Fresh online device feedback is required.':typeof this.onPhysicalInput!=='function'?'Force I/O is unavailable.':'';
    return {device,feature,spec,kind,factor,property,forced,feedback,actual,active,live,reason,key:JSON.stringify([deviceId,code])};
  }
  physicalValueField(model) {
    const {spec,kind,factor,key,property,forced}=model,raw=forced?.value ?? property?.value,initial=this.physicalDrafts.get(key) ?? (kind==='number'?(Number.isFinite(raw)?raw/factor:(spec.min ?? 0)/factor):raw ?? (spec.range?.[0] || ''));
    if(kind==='boolean')return '<button type="button" class="physical-toggle" data-force-toggle data-physical-force>Force ON</button>';
    const field=spec.type==='enum'?`<select data-force-value data-physical-force aria-label="Forced option">${(spec.range || []).map(value=>`<option value="${esc(value)}" ${String(value)===String(initial)?'selected':''}>${esc(value)}</option>`).join('')}</select>`:kind==='number'?`<input type="number" data-force-value data-physical-force aria-label="Forced value${spec.unit?' in '+esc(spec.unit):''}" step="${esc(Number.isFinite(spec.step)?spec.step/factor:'any')}" ${Number.isFinite(spec.min)?'min="'+esc(spec.min/factor)+'"':''} ${Number.isFinite(spec.max)?'max="'+esc(spec.max/factor)+'"':''} value="${esc(initial)}">`:`<input type="text" data-force-value data-physical-force aria-label="Forced text" ${Number.isInteger(spec.maxlen)?'maxlength="'+spec.maxlen+'"':''} value="${esc(initial)}">`;
    return `<div class="physical-value-control">${field}<button type="button" data-force-apply data-physical-force>Apply</button></div>${kind==='number'?`<small class="force-value-unit">${esc(spec.unit || 'Numeric value')}${Number.isFinite(spec.min)&&Number.isFinite(spec.max)?' · '+esc(spec.min/factor)+'–'+esc(spec.max/factor):''}${factor!==1?' · sends value × '+esc(factor)+' in device raw units':''}</small>`:''}`;
  }
  renderPhysicalPanel() {
    if(!this.ensureForcePanel())return;
    if(!this.physicalPanel){this.physicalPanel=document.createElement('section');this.physicalPanel.id='ladder-physical-inputs';this.physicalPanel.className='physical-input-list';this.forcePanel.append(this.physicalPanel);}
    const used=this.usedInputDevices();this.physicalPanel.hidden=!used.length;this.forcePanel.hidden=!used.length&&!(this.ladder?.tags || []).some(tag=>tag.source==='virtual');
    const models=used.map(item=>{const device=this.devices.find(d=>d.id===item.deviceId),features=propertyModel(device).filter(p=>!['wr','wo'].includes(p.accessMode));let code=this.forceFeatures.get(item.deviceId);if(!features.some(p=>p.code===code))code=item.codes.find(c=>features.some(p=>p.code===c)) || features.find(p=>primitiveTypes[p.typeSpec?.type]==='boolean')?.code || features[0]?.code || '';this.forceFeatures.set(item.deviceId,code);return {deviceId:item.deviceId,device,features,code};});
    const signature=JSON.stringify(models.map(item=>[item.deviceId,item.device?.name,item.features,item.code]));if(signature===this.physicalPanelSignature)return;this.physicalPanelSignature=signature;
    const blocked=$$('[data-physical-force]',this.physicalPanel).some(el=>el.dataset.physicalBlocked==='true');
    this.physicalPanel.innerHTML=models.map(({deviceId,device,features,code})=>{const model=this.forceModel(deviceId,code);return `<section class="physical-input-card" data-force-device="${esc(deviceId)}"><strong class="force-device-name">${esc(device?.name || deviceId)}</strong><label>Feature<select data-force-feature aria-label="Feature for ${esc(device?.name || deviceId)}">${features.map(p=>`<option value="${esc(p.code)}" ${p.code===code?'selected':''}>${esc(propertyLabel(p))} · ${esc(p.code)}${!primitiveTypes[p.typeSpec?.type]?' · unsupported':''}</option>`).join('') || '<option value="">No readable features</option>'}</select></label><div class="force-feedback"><span data-force-actual></span><span data-force-effective></span><span class="coil-command" data-force-command></span></div>${this.physicalValueField(model)}<button type="button" class="force-release" data-force-release data-physical-force hidden>Release override</button><small data-force-reason></small></section>`;}).join('');
    for(const card of $$('[data-force-device]',this.physicalPanel)){
      const deviceId=card.dataset.forceDevice,selector=$('[data-force-feature]',card);selector.onchange=()=>{this.forceFeatures.set(deviceId,selector.value);this.physicalPanelSignature='';this.renderPhysicalPanel();this.refreshPhysicalControls();};
      const input=$('[data-force-value]',card);if(input){const preserve=()=>this.physicalDrafts.set(JSON.stringify([deviceId,selector.value]),input.value);input.oninput=preserve;input.onchange=preserve;}
      $('[data-force-toggle]',card)?.addEventListener('click',()=>{const model=this.forceModel(deviceId,selector.value);this.forcePhysicalInput(deviceId,selector.value,(model.live?model.property?.value:model.forced?.value ?? model.property?.value)!==true);});
      $('[data-force-apply]',card)?.addEventListener('click',()=>{const model=this.forceModel(deviceId,selector.value);if(!input||!input.checkValidity()||(model.kind==='number'&&(!input.value||!Number.isFinite(Number(input.value))))){this.onError?.('Enter a valid value within the feature range.');return;}const value=model.kind==='number'?Math.round(Number(input.value)*model.factor*1e9)/1e9:input.value;this.forcePhysicalInput(deviceId,selector.value,value);});
      $('[data-force-release]',card).onclick=()=>this.forcePhysicalInput(deviceId,selector.value,undefined,true);
      if(blocked)$$('[data-physical-force]',card).forEach(el=>el.dataset.physicalBlocked='true');
    }
  }
  refreshPhysicalControls() {
    if(!this.physicalPanel)return;
    for(const card of $$('[data-force-device]',this.physicalPanel)){
      const deviceId=card.dataset.forceDevice,code=$('[data-force-feature]',card).value,model=this.forceModel(deviceId,code),busy=this.physicalPending.has(model.key),forced=model.active&&!model.live?model.forced:null;
      const actual=$('[data-force-actual]',card);actual.textContent='Device: '+model.actual.deviceText;actual.title=model.actual.observation;actual.classList.toggle('actual-fresh',model.actual.actualFresh);
      $('[data-force-effective]',card).textContent=forced?'Simulated input: '+deviceValueText(forced.value,model.property,model.feature):model.live?'Real device feedback drives the ladder.':'Input follows device until overridden.';
      const command=$('[data-force-command]',card);command.textContent=forced?'Simulated':model.feedback?model.actual.commandText:'No force';command.dataset.status=forced?'simulated':model.actual.commandKind;command.title=model.actual.commandError;
      $('[data-force-reason]',card).textContent=model.actual.commandError || model.reason;
      for(const control of $$('[data-physical-force]',card)){control.dataset.physicalUnavailable=String(!!model.reason);control.dataset.busy=String(busy);control.disabled=!!model.reason||busy||control.dataset.physicalBlocked==='true';}
      const toggle=$('[data-force-toggle]',card);if(toggle)toggle.textContent=busy?'Sending…':'Force '+((model.live?model.property?.value:forced?.value ?? model.property?.value)===true?'OFF':'ON');
      const release=$('[data-force-release]',card);release.hidden=!forced||model.live;release.disabled=release.disabled||!forced||model.live;
    }
  }
  async forcePhysicalInput(deviceId,code,value,release=false) {
    const model=this.forceModel(deviceId,code),card=this.physicalPanel&&$$('[data-force-device]',this.physicalPanel).find(item=>item.dataset.forceDevice===deviceId),blocked=card&&$$('[data-physical-force]',card).some(el=>el.dataset.physicalBlocked==='true');
    if(blocked||model.reason||this.physicalPending.has(model.key)||release&&(model.live||!model.forced))return false;
    if(!release&&(model.kind==='number'&&(typeof value!=='number'||!Number.isFinite(value))||model.kind==='boolean'&&typeof value!=='boolean'||model.kind==='string'&&typeof value!=='string'))return false;
    this.physicalPending.add(model.key);this.refreshPhysicalControls();
    try{await this.onPhysicalInput({deviceId,code,...(release?{release:true}:{value})});return true;}catch(error){this.onError?.(error.message || 'Unable to force this input.');return false;}finally{this.physicalPending.delete(model.key);this.refreshPhysicalControls();}
  }
  ensureDeviceWorkspace() {
    if(!this.workbench){
      this.workbench=document.createElement('div');this.workbench.className='ladder-workbench';
      this.palette=document.createElement('aside');this.palette.id='ladder-device-palette';this.palette.className='ladder-device-palette';this.palette.setAttribute('aria-label','Device palette');
      this.palette.innerHTML='<div class="palette-heading"><div><span class="eyebrow">DEVICE LIBRARY</span><h3>Devices <span id="ladder-palette-count">0</span></h3></div><button type="button" id="ladder-palette-toggle" class="icon-button" aria-label="Collapse device palette" aria-expanded="true">−</button></div><div class="palette-content"><label class="palette-search-label"><span>Search devices or features</span><input type="search" id="ladder-device-search" placeholder="Search devices or features…" autocomplete="off"></label><p class="palette-help">Drag a device onto a rung. Click its contact or coil to choose a feature.</p><div id="ladder-placement-status" class="placement-status" hidden><span></span><button type="button" id="ladder-palette-cancel">Cancel</button></div><div id="ladder-palette-devices" class="palette-device-list"></div></div>';
      this.stage=document.createElement('div');this.stage.className='ladder-editor-area';
      this.workbench.append(this.palette,this.stage);
      $('#ladder-device-search',this.palette).addEventListener('input',event=>{this.paletteQuery=event.target.value;this.paletteSignature='';this.renderDevicePalette();});
      $('#ladder-palette-cancel',this.palette).onclick=()=>this.clearPlacement();
      $('#ladder-palette-toggle',this.palette).onclick=()=>{const collapsed=this.palette.classList.toggle('collapsed');const button=$('#ladder-palette-toggle',this.palette);button.textContent=collapsed?'+':'−';button.setAttribute('aria-expanded',String(!collapsed));button.setAttribute('aria-label',collapsed?'Expand device palette':'Collapse device palette');};
      this.palette.addEventListener('keydown',event=>{if(event.key==='Escape'){this.clearPlacement();event.preventDefault();}});
      this.workbench.addEventListener('keydown',event=>{if(event.key==='Escape'){this.clearPlacement();event.preventDefault();}});
    }
    if(!this.container.contains(this.workbench))this.container.replaceChildren(this.workbench);
    this.renderDevicePalette();
  }
  readableFeatures(device) {return propertyModel(device).filter(p=>!['wr','wo'].includes(p.accessMode)&&primitiveTypes[p.typeSpec?.type]&&(['ro','rw'].includes(p.accessMode)||Object.hasOwn(device?.properties || {},p.code)));}
  instructionItems() {
    return [
      {type:'VIRTUAL',label:'Virtual switch',description:'Forced ON/OFF input for Test Run or Live Test. Starts OFF.',category:'Virtual'},
      {type:'VIRTUAL_NUMBER',label:'Virtual analog input',description:'Editable numeric input, such as temperature. Set its name, unit and reset value.',category:'Virtual'},
      {type:'NO',label:'Normally open contact',description:'Conducts when the selected input is TRUE. Add in series for AND.',category:'Contacts'},
      {type:'NC',label:'Normally closed contact',description:'Conducts when the selected input is FALSE.',category:'Contacts'},
      ...(this.ladder?.version===2?[]:[{type:'PARALLEL',label:'Parallel branch (OR)',description:'Add an alternate current path beside the existing contacts.',category:'Contacts'}]),
      ...(this.ladder?.version===2?[{type:'JUNCTION',label:'Connection point (optional)',description:'Wire joins are created automatically. Add a point here only to organize your wiring.',category:'Wiring'},{type:'RAIL',label:'Power rail',description:'Supply TRUE to an explicitly connected path.',category:'Wiring'},{type:'COIL',label:'Output coil',description:'Add an output, choose its device and draw a power connection.',category:'Wiring'}]:[]),
      ...Object.entries(this.types).filter(([type])=>!['INPUT','OUTPUT','CONST','VIRTUAL'].includes(type)).map(([type,meta])=>({type,...meta,
        description:['AND','OR','XOR','NAND','NOR'].includes(type)?`${type}: combine the rung state with another boolean operand.`:meta.description}))
    ];
  }
  renderToolbox() {
    if(!this.toolbox)return;
    if(!$('#ladder-instruction-search',this.toolbox)){
      this.toolbox.innerHTML='<label class="palette-search-label"><span>Search instructions</span><input type="search" id="ladder-instruction-search" placeholder="Contact, timer, AND…" autocomplete="off"></label><p class="palette-help">Drag an instruction onto the ladder, or select it and tap a target. Click a placed symbol to configure it.</p><div class="instruction-categories"></div><div id="ladder-instruction-list"></div>';
      $('#ladder-instruction-search',this.toolbox).oninput=event=>{this.toolboxQuery=event.target.value;this.renderInstructionList();};
      this.toolbox.addEventListener('keydown',event=>{if(event.key==='Escape'){this.clearPlacement();event.preventDefault();}});
      this.renderInstructionList();
    }
    this.updatePlacementUI();
  }
  renderInstructionList() {
    if(!this.toolbox)return;
    const items=this.instructionItems(),categories=$('.instruction-categories',this.toolbox),list=$('#ladder-instruction-list',this.toolbox);categories.replaceChildren();list.replaceChildren();
    for(const category of ['All',...new Set(items.map(item=>item.category || 'Other'))]){
      const button=document.createElement('button');button.type='button';button.textContent=category;button.className=`instruction-category${this.toolboxCategory===category?' active':''}`;
      button.onclick=()=>{this.toolboxCategory=category;this.renderInstructionList();};categories.append(button);
    }
    const query=this.toolboxQuery.trim().toLowerCase();
    for(const item of items){
      if(this.toolboxCategory!=='All'&&item.category!==this.toolboxCategory)continue;if(!`${item.type} ${item.label} ${item.description}`.toLowerCase().includes(query))continue;
      const button=document.createElement('button');button.type='button';button.className='instruction-source'+(['VIRTUAL','VIRTUAL_NUMBER'].includes(item.type)?' virtual-source':'');button.dataset.paletteInstruction=item.type;
      const symbol=['VIRTUAL','VIRTUAL_NUMBER'].includes(item.type)?'<span>V</span>':['NO','NC'].includes(item.type)?`<svg viewBox="0 0 50 40" aria-hidden="true">${glyphs[item.type]}</svg>`:item.type==='PARALLEL'?'<span aria-hidden="true">⊏⊐</span>':`<span>${esc(item.type)}</span>`;
      button.innerHTML=`<b>${symbol}</b><span><strong>${esc(item.label || item.type)}</strong><small>${esc(item.description)}</small></span>`;
      button.title=item.description;this.bindPaletteSource(button,{instruction:item.type});list.append(button);
    }
    if(!list.children.length)list.innerHTML='<p class="palette-empty">No matching instructions.</p>';this.updatePlacementUI();
  }
  renderDevicePalette() {
    if(!this.palette)return;
    const running=!!this.runtime.running;
    const signature=JSON.stringify([this.paletteQuery,running,this.devices.map(d=>[d.id,d.name,d.online,propertyModel(d).map(p=>[p.code,p.name,p.accessMode,p.typeSpec?.type])]),[...this.paletteExpanded]]);
    if(signature===this.paletteSignature||this.paletteDragging){this.updatePlacementUI();return;}
    this.paletteSignature=signature;
    $('#ladder-palette-count',this.palette).textContent=this.devices.length;
    const target=$('#ladder-palette-devices',this.palette);target.replaceChildren();const query=this.paletteQuery.trim().toLowerCase();
    for(const device of this.devices){
      const properties=propertyModel(device),deviceMatch=`${device.name} ${device.id}`.toLowerCase().includes(query);
      const matching=properties.filter(p=>`${propertyLabel(p)} ${p.code}`.toLowerCase().includes(query));
      if(query&&!deviceMatch&&!matching.length)continue;
      const section=document.createElement('section');section.className='palette-device';
      const readable=this.readableFeatures(device),writable=this.writableFeatures(device);
      const header=document.createElement('div');header.className='palette-device-header';
      const button=document.createElement('button');button.type='button';button.className='palette-device-source';button.dataset.paletteDevice=device.id;button.dataset.ladderEdit='';
      button.innerHTML=`<span class="palette-device-icon" aria-hidden="true">▦</span><span><strong>${esc(device.name)}</strong><small><i class="status-dot ${device.online?'':'idle'}"></i>${device.online?'Online':'Offline'} · ${readable.length} in / ${writable.length} out</small></span>`;
      button.title='Drag onto a rung, or select then click a contact area or output coil';this.bindPaletteSource(button,{deviceId:device.id},!readable.length&&!writable.length);
      const expand=document.createElement('button');expand.type='button';expand.className='palette-expand';expand.dataset.deviceExpand=device.id;
      const expanded=this.paletteExpanded.has(device.id)||!!query;expand.textContent=expanded?'−':'+';expand.setAttribute('aria-label',`${expanded?'Hide':'Show'} features for ${device.name}`);expand.setAttribute('aria-expanded',String(expanded));
      expand.onclick=()=>{if(this.paletteExpanded.has(device.id))this.paletteExpanded.delete(device.id);else this.paletteExpanded.add(device.id);this.paletteSignature='';this.renderDevicePalette();};
      header.append(button,expand);section.append(header);
      if(expanded){const list=document.createElement('div');list.className='palette-feature-list';
        for(const property of query&&!deviceMatch?matching:properties){const input=readable.some(p=>p.code===property.code),output=writable.some(p=>p.code===property.code),supported=input||output;const feature=document.createElement('button');feature.type='button';feature.className=`palette-feature${supported?'':' unsupported'}`;feature.dataset.paletteFeature=property.code;feature.dataset.deviceId=device.id;feature.dataset.ladderEdit='';
          feature.innerHTML=`<span><strong>${esc(propertyLabel(property))}</strong><small>${esc(property.code)}</small></span><em>${supported?[input?'IN':'',output?'OUT':''].filter(Boolean).join(' / '):'UNSUPPORTED'}</em>`;
          feature.title=supported?`${propertyLabel(property)} — ${input?'readable input':''}${input&&output?' and ':''}${output?'writable output':''}. Drag or select, then choose a target.`:'This data type cannot be used in PLC logic.';
          this.bindPaletteSource(feature,{deviceId:device.id,code:property.code},!supported);list.append(feature);
        }section.append(list);}
      target.append(section);
    }
    if(!target.children.length)target.innerHTML=`<p class="palette-empty">${this.devices.length?'No matching devices or features.':'No devices yet. Connect your Tuya account in Settings, then sync devices.'}</p>`;
    this.updatePlacementUI();
  }
  bindPaletteSource(element,payload,unsupported=false) {
    element.disabled=unsupported||!!this.runtime.running;element.draggable=!element.disabled;element.dataset.unsupported=String(unsupported);
    element.onclick=()=>{if(this.runtime.running||unsupported)return;this.placement=payload;this.updatePlacementUI();};
    element.addEventListener('dragstart',event=>{if(this.runtime.running||unsupported){event.preventDefault();return;}this.paletteDragging=true;this.placement=payload;event.dataTransfer.effectAllowed='copy';event.dataTransfer.setData('application/x-tuya-logic-device',JSON.stringify(payload));this.updatePlacementUI();});
    element.addEventListener('dragend',()=>{this.paletteDragging=false;this.clearPlacement();this.paletteSignature='';this.renderDevicePalette();});
  }
  bindMoveSource(element,selection) {
    element.dataset.movable='true';element.draggable=!this.runtime.running;
    element.addEventListener('dragstart',event=>{
      if(this.runtime.running){event.preventDefault();return;}
      event.stopPropagation();this.selection={...selection};this.paletteDragging=true;this.placement={moving:{...selection}};
      event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('application/x-tuya-logic-device',JSON.stringify(this.placement));
      this.renderInspector();this.highlightSelection();this.onInspector?.('properties');this.updatePlacementUI();
    });
    element.addEventListener('dragend',()=>{this.paletteDragging=false;this.clearPlacement();this.renderDevicePalette();});
  }
  moveSelection() {
    if(this.runtime.running||!this.selection||!['contact','block'].includes(this.selection.kind))return false;
    this.placement={moving:{...this.selection}};this.updatePlacementUI();return true;
  }
  clearPlacement() {this.placement=null;this.clearDropHighlights();this.updatePlacementUI();}
  updatePlacementUI() {
    const status=this.palette&&$('#ladder-placement-status',this.palette);
    if(status){status.hidden=!this.placement;if(this.placement){const device=this.devices.find(d=>d.id===this.placement.deviceId),property=propertyModel(device).find(p=>p.code===this.placement.code),instruction=this.instructionItems().find(item=>item.type===this.placement.instruction);$('span',status).textContent=this.placement.moving?'Move selected '+(this.placement.moving.kind==='block'?'function':'contact')+': tap a highlighted destination.':this.placement.wireRungId?'Connect to the join handle on the same rung to add a parallel OR path.':instruction?instruction.label+' selected. Tap a highlighted ladder target.':(property?propertyLabel(property):device?.name || 'Device')+' selected. Tap a rung input area or output coil.';}}
    for(const root of [this.palette,this.toolbox].filter(Boolean))$$('[data-palette-device],[data-palette-feature],[data-palette-instruction]',root).forEach(el=>{const deviceId=el.dataset.paletteDevice || el.dataset.deviceId;const selected=!!this.placement&&(el.dataset.paletteInstruction?el.dataset.paletteInstruction===this.placement.instruction:!this.placement.instruction&&this.placement.deviceId===deviceId&&(el.dataset.paletteFeature || undefined)===this.placement.code);el.classList.toggle('selected',selected);el.toggleAttribute('data-selected',selected);el.setAttribute('aria-pressed',String(selected));el.disabled=!!this.runtime.running||el.dataset.unsupported==='true';el.draggable=!el.disabled;});
    if(this.stage)$$('[data-drop-kind]',this.stage).forEach(el=>{const possible=this.placement&&this.canPlace(this.placement,el.dataset.dropKind,el.dataset.dropRung);el.classList.toggle('placement-target',!!possible);el.classList.toggle('placement-invalid',!!this.placement&&!possible);el.dataset.dropDisabled=String(!!this.runtime.running||!!this.placement&&!possible);el.removeAttribute('aria-disabled');});
    if(this.stage)for(const row of $$('.ladder-rung',this.stage)){
      const preview=$('[data-wire-preview]',row);if(!preview)continue;
      const visible=this.placement?.wireRungId===row.dataset.rungId;preview.toggleAttribute('hidden',!visible);
      if(visible){const network=$('.ladder-network',row).getBoundingClientRect(),start=$('[data-wire-start]',row).getBoundingClientRect(),end=$('[data-wire-end]',row).getBoundingClientRect();preview.setAttribute('viewBox',`0 0 ${network.width} ${network.height}`);$('path',preview).setAttribute('d',`M ${start.left+start.width/2-network.left} ${start.top+start.height/2-network.top} V ${network.height-4} H ${end.left+end.width/2-network.left} V ${end.top+end.height/2-network.top}`);}
    }
  }
  canPlace(payload,kind,rungId) {
    if(this.ladder?.version===2)return this.graph.canPlace(payload,kind,rungId);
    if(this.runtime.running||!payload||!this.ladder)return false;
    if(payload.wireRungId)return kind==='parallel'&&(!rungId||rungId===payload.wireRungId);
    if(payload.moving)return payload.moving.kind==='contact'?['input','parallel','new-rung'].includes(kind):payload.moving.kind==='block'&&['function','new-rung'].includes(kind);
    if(payload.instruction){if(['NO','NC','VIRTUAL','VIRTUAL_NUMBER'].includes(payload.instruction))return ['input','parallel','new-rung'].includes(kind);if(payload.instruction==='PARALLEL')return ['input','parallel'].includes(kind);return !!this.types[payload.instruction]&&!['INPUT','OUTPUT','CONST','VIRTUAL'].includes(payload.instruction)&&['function','new-rung'].includes(kind);}
    if(kind==='function')return false;
    const device=this.devices.find(d=>d.id===payload.deviceId);if(!device)return false;
    const features=kind==='output'?this.writableFeatures(device):this.readableFeatures(device);
    return payload.code?features.some(p=>p.code===payload.code):features.length>0;
  }
  clearDropHighlights() {if(!this.stage)return;$$('.drop-over,.drop-invalid',this.stage).forEach(el=>el.classList.remove('drop-over','drop-invalid'));$$('.ladder-drop-preview',this.stage).forEach(el=>el.remove());}
  bindDropTarget(element,target) {
    element.dataset.dropKind=target.kind;if(target.rungId)element.dataset.dropRung=target.rungId;if(target.branchId)element.dataset.dropBranch=target.branchId;
    if(element.tagName!=='BUTTON'){element.tabIndex=0;element.setAttribute('role','button');}
    element.setAttribute('aria-label',target.kind==='output'?'Drop or place an output device here':target.kind==='function'?'Drop or place a function instruction here':target.kind==='parallel'?'Drop a device or contact here to add a full parallel OR branch':target.kind==='new-rung'?'Drop or place an input device or instruction to create a rung':'Drop or place a device or contact instruction here');
    const resolve=event=>{const resolved={...target};const rung=this.ladder.rungs.find(r=>r.id===target.rungId);if(target.kind==='input'){const branch=rung?.branches.find(b=>b.id===target.branchId),contact=event.target.closest('[data-contact-id]');if(contact&&branch){const index=branch.contacts.findIndex(c=>c.id===contact.dataset.contactId);resolved.index=index+(event.clientX>contact.getBoundingClientRect().left+contact.getBoundingClientRect().width/2?1:0);}else resolved.index=branch?.contacts.length || 0;}else if(target.kind==='function'){const block=event.target.closest('[data-block-id]');resolved.index=block?(rung?.blocks || []).findIndex(b=>b.id===block.dataset.blockId)+(event.clientX>block.getBoundingClientRect().left+block.getBoundingClientRect().width/2?1:0):(rung?.blocks || []).length;}return resolved;};
    element.addEventListener('dragover',event=>{if(!this.placement)return;event.stopPropagation();this.clearDropHighlights();const valid=this.canPlace(this.placement,target.kind,target.rungId);element.classList.add(valid?'drop-over':'drop-invalid');if(!valid){event.dataTransfer.dropEffect='none';return;}event.preventDefault();event.dataTransfer.dropEffect=this.placement.moving?'move':'copy';if(['input','function'].includes(target.kind)&&this.placement.instruction!=='PARALLEL'){const resolved=resolve(event),preview=document.createElement('span');preview.className='ladder-drop-preview';preview.textContent=target.kind==='input'?'Insert contact':'Insert function';const elements=$$(target.kind==='input'?'[data-contact-id]':'[data-block-id]',element);element.insertBefore(preview,elements[resolved.index] || (target.kind==='input'?$('.contact-add',element):null));}});
    element.addEventListener('dragleave',event=>{if(!element.contains(event.relatedTarget))this.clearDropHighlights();});
    element.addEventListener('drop',event=>{event.preventDefault();event.stopPropagation();const payload=this.placement;if(!payload)return;this.placePayload(payload,resolve(event));});
    element.addEventListener('click',event=>{if(!this.placement)return;event.preventDefault();event.stopPropagation();this.placePayload(this.placement,resolve(event));},true);
    element.addEventListener('keydown',event=>{if(this.placement&&event.target===element&&['Enter',' '].includes(event.key)){event.preventDefault();event.stopPropagation();this.placePayload(this.placement,{...target});}});
  }
  placePayload(payload,target) {
    if(payload.moving)this.placeMovedElement(payload,target);
    else if(payload.wireRungId){if(payload.wireRungId!==target.rungId){this.onError?.('Connect the handles on the same rung to add a parallel path.');return;}this.placeInstruction({instruction:'PARALLEL'},target);}
    else if(payload.instruction)this.placeInstruction(payload,target);
    else this.placeDevice(payload,target);
  }
  placeMovedElement(payload,target) {
    if(!this.canPlace(payload,target.kind,target.rungId)){this.onError?.(this.runtime.running?'Stop the program before moving elements.':'Choose a highlighted target for this element.');return;}
    try{
      const selection=payload.moving,sourceRung=this.ladder.rungs.find(r=>r.id===selection.rungId),sourceBranch=sourceRung?.branches.find(b=>b.id===selection.branchId);
      const sourceItems=selection.kind==='contact'?sourceBranch?.contacts:sourceRung?.blocks,from=sourceItems?.findIndex(item=>item.id===selection.id) ?? -1;
      if(from<0){this.clearPlacement();return;}
      let destinationRung=this.ladder.rungs.find(r=>r.id===target.rungId),destinationBranch=destinationRung?.branches.find(b=>b.id===target.branchId);
      if(target.kind==='new-rung'){
        if(this.ladder.rungs.length>=64)throw new Error('A ladder program can contain up to 64 rungs.');
        destinationRung={id:this.uid('rung'),name:`Rung ${this.ladder.rungs.length+1}`,branches:[{id:this.uid('branch'),contacts:[]}],blocks:[],coil:{deviceId:'',tagId:'',mode:'follow',value:false}};destinationBranch=destinationRung.branches[0];
      }else if(!destinationRung)throw new Error('The destination rung is no longer available.');
      if(destinationRung!==sourceRung){
        const destinationIds=new Set([destinationRung.id,...destinationRung.branches.flatMap(branch=>[branch.id,...branch.contacts.map(contact=>contact.id)]),...(destinationRung.blocks || []).map(block=>block.id)]);
        if(destinationIds.has(selection.id))throw new Error('This rung already contains an element with the same ID. Keep the element in its original rung or recreate it here.');
        if(selection.kind==='block'&&(sourceItems[from].operands || []).some(operand=>operand.blockId))throw new Error('This function uses another function in its current rung. Remap those operands to constants or I/O tags before moving it to another rung.');
      }
      if(selection.kind==='contact'){
        if(target.kind==='parallel'){
          const removesBranch=sourceRung===destinationRung&&sourceBranch.contacts.length===1&&sourceRung.branches.length>1;
          if(destinationRung.branches.length>=16&&!removesBranch)throw new Error('A rung supports up to 16 parallel branches.');
          destinationBranch=destinationRung.branches.length===1&&!destinationRung.branches[0].contacts.length?destinationRung.branches[0]:{id:this.uid('branch'),contacts:[]};
        }
        if(!destinationBranch)throw new Error('The destination branch is no longer available.');
        if(destinationBranch!==sourceBranch&&destinationBranch.contacts.length>=32)throw new Error('A branch supports up to 32 series contacts.');
      }
      const destinationItems=selection.kind==='contact'?destinationBranch.contacts:(destinationRung.blocks ||= []);
      let index=Math.min(target.index ?? destinationItems.length,destinationItems.length);if(destinationItems===sourceItems&&from<index)index--;
      if(destinationItems===sourceItems&&from===index){this.clearPlacement();this.select(selection);return;}
      const [element]=sourceItems.splice(from,1);destinationItems.splice(index,0,element);
      if(target.kind==='new-rung')this.ladder.rungs.push(destinationRung);
      if(target.kind==='parallel'&&!destinationRung.branches.includes(destinationBranch))destinationRung.branches.push(destinationBranch);
      if(selection.kind==='contact'&&!sourceBranch.contacts.length&&sourceRung.branches.length>1)sourceRung.branches=sourceRung.branches.filter(b=>b!==sourceBranch);
      else if(selection.kind==='contact'&&!sourceBranch.contacts.length&&sourceRung!==destinationRung)sourceBranch.contacts.push({id:this.uid('contact'),deviceId:'',tagId:'',kind:'NO',operator:'GT',value:0});
      this.selection={kind:selection.kind,id:element.id,rungId:destinationRung.id,...(selection.kind==='contact'?{branchId:destinationBranch.id}:{})};
      this.clearPlacement();this.changed();
    }catch(error){this.onError?.(error.message);this.clearDropHighlights();}
  }
  makeFunction(type) {
    const params=type==='SCHEDULE'?dailyScheduleDefaults():timerTypes.includes(type)?{durationMs:1000}:countTypes.includes(type)?{preset:3}:type==='BLINK'?{onMs:1000,offMs:1000}:{};
    const block={id:this.uid('fn'),type,params};if(operandCounts[type])block.operands=Array.from({length:operandCounts[type]},(_,index)=>({value:['AND','OR','XOR','NAND','NOR'].includes(type)||type==='SELECT'&&index===0?false:0}));return block;
  }
  parallelBranch(rung) {
    if(rung.branches.length===1&&!rung.branches[0].contacts.length)return rung.branches[0];
    if(rung.branches.length>=16)throw new Error('A rung supports up to 16 parallel branches.');
    const branch={id:this.uid('branch'),contacts:[]};rung.branches.push(branch);return branch;
  }
  placeInstruction(payload,target) {
    if(this.ladder?.version===2){this.graph.place(payload,target);return;}
    if(!this.canPlace(payload,target.kind,target.rungId)){this.onError?.(this.runtime.running?'Stop the program before placing instructions.':'Choose a highlighted target for this instruction.');this.clearDropHighlights();return;}
    try{
      if(['VIRTUAL','VIRTUAL_NUMBER'].includes(payload.instruction)&&this.ladder.tags.length>=512)throw new Error('The program has reached the 512 I/O tag limit.');
      let rung=this.ladder.rungs.find(r=>r.id===target.rungId);
      if(target.kind==='new-rung'){
        if(this.ladder.rungs.length>=64)throw new Error('A ladder program can contain up to 64 rungs.');
        rung={id:this.uid('rung'),name:'Rung '+(this.ladder.rungs.length+1),branches:[{id:this.uid('branch'),contacts:[]}],blocks:[],coil:{tagId:'',mode:'follow',value:false}};this.ladder.rungs.push(rung);
      }
      if(!rung)throw new Error('The destination rung is no longer available.');
      if(payload.instruction==='PARALLEL'){
        const branch=this.parallelBranch(rung),contact={id:this.uid('contact'),deviceId:'',tagId:'',kind:'NO',operator:'GT',value:0};
        branch.contacts.push(contact);this.selection={kind:'contact',id:contact.id,rungId:rung.id,branchId:branch.id};
      }else if(['NO','NC','VIRTUAL','VIRTUAL_NUMBER'].includes(payload.instruction)){
        let branch=target.kind==='new-rung'?rung.branches[0]:rung.branches.find(b=>b.id===target.branchId);
        if(target.kind==='parallel')branch=this.parallelBranch(rung);
        if(!branch)throw new Error('The destination branch is no longer available.');if(branch.contacts.length>=32)throw new Error('A branch supports up to 32 series contacts.');
        const virtual=['VIRTUAL','VIRTUAL_NUMBER'].includes(payload.instruction)?this.createVirtualTag(payload.instruction==='VIRTUAL_NUMBER'?'number':'boolean'):null;
        const contact={id:this.uid('contact'),deviceId:'',tagId:virtual?.id || '',kind:virtual?(virtual.dataType==='number'?'COMPARE':'NO'):payload.instruction,operator:'GT',value:0};branch.contacts.splice(Math.min(target.index ?? branch.contacts.length,branch.contacts.length),0,contact);this.selection={kind:'contact',id:contact.id,rungId:rung.id,branchId:branch.id};
      }else{const block=this.makeFunction(payload.instruction);(rung.blocks ||= []).splice(Math.min(target.index ?? rung.blocks.length,rung.blocks.length),0,block);this.selection={kind:'block',id:block.id,rungId:rung.id};}
      this.clearPlacement();this.changed();
    }catch(error){this.onError?.(error.message);this.clearDropHighlights();}
  }
  placeDevice(payload,target) {
    if(this.ladder?.version===2){this.graph.place(payload,target);return;}
    if(!this.canPlace(payload,target.kind,target.rungId)){this.onError?.(this.runtime.running?'Stop the program before placing devices.':target.kind==='output'?'This feature is not a writable output.':'This feature is not a readable input.');this.clearDropHighlights();return;}
    try{
      const device=this.devices.find(d=>d.id===payload.deviceId),features=target.kind==='output'?this.writableFeatures(device):this.readableFeatures(device),feature=payload.code?features.find(p=>p.code===payload.code):features[0];
      let rung=this.ladder.rungs.find(r=>r.id===target.rungId);
      if(target.kind==='new-rung'&&this.ladder.rungs.length>=64)throw new Error('A ladder program can contain up to 64 rungs.');
      if(target.kind==='output'){
        if(!rung)throw new Error('The destination rung is no longer available.');
        if(payload.code)this.selectOutputFeature(rung,device,feature);else rung.coil={deviceId:device.id,tagId:'',mode:'follow',value:false};
        this.pendingCoilDevices.delete(rung.id);this.selection={kind:'coil',id:`${rung.id}:coil`,rungId:rung.id};
      }else{
        let branch=rung?.branches.find(b=>b.id===target.branchId);if(target.kind==='input'&&!branch)throw new Error('The destination branch is no longer available.');if(branch?.contacts.length>=32)throw new Error('A branch supports up to 32 series contacts.');
        if(target.kind==='parallel'){if(!rung)throw new Error('The destination rung is no longer available.');if(rung.branches.length>=16)throw new Error('A rung supports up to 16 parallel branches.');}
        const tag=payload.code?this.ensurePropertyTag(device,feature,'input'):null;
        if(target.kind==='new-rung'){rung={id:this.uid('rung'),name:`Rung ${this.ladder.rungs.length+1}`,branches:[{id:this.uid('branch'),contacts:[]}],blocks:[],coil:{tagId:'',mode:'follow',value:false}};branch=rung.branches[0];this.ladder.rungs.push(rung);}
        if(target.kind==='parallel')branch=this.parallelBranch(rung);
        const contact={id:this.uid('contact'),deviceId:device.id,tagId:tag?.id || '',kind:!tag||tag.dataType==='boolean'?'NO':'COMPARE',operator:tag?.dataType==='string'?'EQ':'GT',value:tag?.dataType==='string'?'':0};branch.contacts.splice(Math.min(target.index ?? branch.contacts.length,branch.contacts.length),0,contact);this.selection={kind:'contact',id:contact.id,rungId:rung.id,branchId:branch.id};
      }
      this.clearPlacement();this.changed();
    }catch(error){this.onError?.(error.message);this.clearDropHighlights();}
  }
  tagName(tag) {
    if(!tag)return '';
    if(tag.source==='virtual')return tag.name || 'Virtual switch';
    if(tag.name&&!hasNonLatinLetters(tag.name))return tag.name;
    const device=this.devices.find(d=>d.id===tag.deviceId),property=propertyModel(device).find(p=>p.code===tag.code);
    return [device?.name,propertyLabel(property || {code:tag.code})].filter(Boolean).join(' · ');
  }
  readTag(tag) {
    if(tag?.source==='virtual'){const value=this.virtualState(tag)?.value ?? (tag.dataType==='number'?tag.defaultValue ?? 0:false);return {value,valid:true,quality:{valid:true,label:'Local forced input',shortLabel:valueText(value),observation:'Virtual input · resets to '+valueText(tag.dataType==='number'?tag.defaultValue ?? 0:false)+' · Test Run or Live Test'}};}
    const device=this.devices.find(d=>d.id===tag?.deviceId),p=device?.properties?.[tag?.code];
    const forced=this.runtime.running&&this.runtime.executionMode==='test'&&tag?.direction==='input'?(this.runtime.inputForces || []).find(item=>item.deviceId===tag.deviceId&&item.code===tag.code):null;
    if(forced){const value=typeof forced.value==='number'?forced.value*(tag.scale ?? 1)+(tag.offset ?? 0):forced.value;return {value,valid:true,forced:true,quality:{valid:true,label:'Simulated input override',shortLabel:valueText(value),observation:'Test Run override · actual device value is unchanged'}};}
    const quality=propertyQuality(device?.online===false?{...p,qualityReason:'offline',valid:false}:p,device),valid=!!device?.online&&quality.valid;
    const value=typeof p?.value==='number'?p.value*(tag.scale ?? 1)+(tag.offset ?? 0):p?.value;
    return {value,valid,quality};
  }
  contactFeedback(tag) {
    const state=this.readTag(tag),unit=tag?.unit?' '+tag.unit:'',switchValue=tag?.dataType==='boolean'&&(tag.source==='virtual'||/^switch|switch$/i.test(tag.code||'')),format=value=>(switchValue&&typeof value==='boolean'?(value?'ON':'OFF'):valueText(value))+unit;
    const source=tag?.source==='virtual'?'VIRTUAL':state.forced?'SIM':state.valid?'LIVE':'UNKNOWN';
    const text=state.valid?source+' · '+format(state.value):state.quality.shortLabel;
    let actualText='',actualObservation='';
    if(state.forced){
      const device=this.devices.find(item=>item.id===tag?.deviceId),property=device?.properties?.[tag?.code];
      const raw=property?.value,hasValue=['boolean','string'].includes(typeof raw)||typeof raw==='number'&&Number.isFinite(raw),actual=typeof raw==='number'?raw*(tag.scale??1)+(tag.offset??0):raw;
      const quality=propertyQuality(device?.online===false?{...property,qualityReason:'offline',valid:false}:!hasValue?{...property,qualityReason:'missing',valid:false}:property,device);
      const fresh=!!device?.online&&quality.valid&&hasValue;
      actualText='Device: '+(fresh?format(actual):quality.shortLabel+(hasValue?' · last '+format(actual):''));actualObservation=quality.observation;
    }
    return {text,source,actualText,title:[state.quality.label,state.quality.observation,actualText,actualObservation].filter(Boolean).join(' · '),valid:state.valid,forced:!!state.forced};
  }
  tagOptions(selected='',filter=t=>t.direction==='input',empty='Select I/O tag…') {
    const tags=this.ladder?.tags.filter(filter) || [];
    return `<option value="">${esc(empty)}</option>`+(selected&&!tags.some(t=>t.id===selected)?`<option value="${esc(selected)}" selected>Missing I/O tag — select a replacement</option>`:'')+tags.map(t=>`<option value="${esc(t.id)}" ${t.id===selected?'selected':''}>${esc(t.address)} · ${esc(this.tagName(t))} (${esc(t.dataType)}${t.source==='virtual'?' · virtual test':''})</option>`).join('');
  }
  select(selection) {this.selection=selection;this.renderInspector();this.highlightSelection();this.onInspector?.(selection?'properties':'instructions');}
  highlightSelection() {
    const selection=this.selection,ids=selection?.kind==='multi'?new Set(selection.nodeIds||[]):null;
    $$('[data-element-id]',this.container).forEach(el=>{
      const selected=ids?el.closest('[data-network-rung]')?.dataset.networkRung===selection.rungId&&ids.has(el.dataset.elementId):el.dataset.elementId===selection?.id;
      el.classList.toggle('selected',selected);
      el.classList.toggle('multi-selected',!!ids&&!!el.dataset.networkNode&&selected);
    });
  }
  render() {
    if(this.pendingRender){clearTimeout(this.pendingRender);this.pendingRender=null;}
    if(!this.ladder){this.container.innerHTML='<div class="empty-state"><h3>No ladder diagram</h3><p>Create a new Ladder program or open the existing Function Blocks view.</p></div>';return;}
    if(this.mode==='io'){this.renderMapping();this.renderInspector();return;}
    if(this.ladder.version===2){this.graph.render();return;}
    this.ensureDeviceWorkspace();this.renderToolbox();
    this.stage.innerHTML='<div class="ladder-toolbar"><div><strong>Ladder diagram</strong><small>Drop inputs on the left · Drop outputs on a coil</small></div><div><button class="button secondary small" id="ladder-map-io">I/O mapping</button><button class="button small" id="ladder-add-rung" data-ladder-edit>+ Rung</button></div></div><div class="ladder-scroll" id="ladder-scroll"><div id="ladder-rungs" class="ladder-rungs"></div></div><div class="ladder-legend"><span><i></i>Energized</span><span>NO — normally open</span><span>NC — normally closed</span><span>Click a symbol to edit its device and feature</span></div>';
    $('#ladder-map-io',this.container).onclick=()=>this.onMapping?.();
    $('#ladder-add-rung',this.container).onclick=()=>this.addRung();
    const target=$('#ladder-rungs',this.container);
    this.ladder.rungs.forEach((rung,index)=>{
      const row=document.createElement('section');row.className='ladder-rung';row.dataset.rungId=rung.id;
      row.innerHTML=`<div class="rung-heading"><button class="rung-select" data-element-id="${esc(rung.id)}"><span>${String(index+1).padStart(3,'0')}</span><strong>${esc(rung.name || `Rung ${index+1}`)}</strong></button><div class="rung-actions"><button class="quiet-button add-branch" data-ladder-edit>+ Parallel branch</button><button class="quiet-button add-function" data-ladder-edit>+ Function</button></div></div><div class="ladder-network"><div class="ladder-branches"></div><div class="ladder-functions"></div><div class="coil-wire"></div><div class="ladder-coil-wrap"></div></div>`;
      $('.rung-select',row).onclick=()=>this.select({kind:'rung',id:rung.id,rungId:rung.id});
      $('.add-branch',row).onclick=()=>{if(this.runtime.running)return;rung.branches.push({id:this.uid('branch'),contacts:[]});this.changed();};
      $('.add-function',row).onclick=()=>this.openFunctionLibrary(rung);
      const branches=$('.ladder-branches',row);
      rung.branches.forEach((branch,branchIndex)=>{
        const line=document.createElement('div');line.className='ladder-branch';line.dataset.branchId=branch.id;
        for(const contact of branch.contacts){
          const tag=this.tag(contact.tagId),pendingDevice=this.devices.find(d=>d.id===contact.deviceId),button=document.createElement('button');button.className='ladder-contact';button.dataset.elementId=contact.id;button.dataset.contactId=contact.id;if(tag?.source==='virtual'){button.classList.add('virtual-contact');button.dataset.virtualContact=tag.id;}
          button.innerHTML=`<small>${esc(tag?tag.address+(tag.source==='virtual'?' · V':''):(pendingDevice?'DEVICE':'UNMAPPED'))}</small>${contact.kind==='COMPARE'?`<span class="compare-symbol">${esc({GT:'>',GTE:'≥',LT:'<',LTE:'≤',EQ:'=',NEQ:'≠'}[contact.operator] || '>')} ${esc(contact.valueTagId?this.tag(contact.valueTagId)?.address || '?':valueText(contact.value))}</span>`:`<svg viewBox="0 0 50 40" aria-hidden="true">${glyphs[contact.kind] || glyphs.NO}</svg>`}<strong>${esc(tag?this.tagName(tag):pendingDevice?.name || 'Select input')}</strong><em class="contact-live">${tag?'—':'Choose feature'}</em>`;
          button.title=tag?this.tagName(tag)+' · '+tag.code:(pendingDevice?.name || 'Input contact')+' · choose a readable feature';button.onclick=()=>{this.select({kind:'contact',id:contact.id,rungId:rung.id,branchId:branch.id});if(tag?.source==='virtual'&&tag.dataType==='boolean'&&this.runtime.running&&['test','live-test'].includes(this.runtime.executionMode))void this.forceVirtualInput(tag.id);};this.bindMoveSource(button,{kind:'contact',id:contact.id,rungId:rung.id,branchId:branch.id});line.append(button);
        }
        const add=document.createElement('button');add.className='contact-add';add.dataset.ladderEdit='';add.textContent='+';add.title='Add series contact';add.setAttribute('aria-label',`Add contact to rung ${index+1}, branch ${branchIndex+1}`);add.onclick=()=>this.addContact(rung,branch);line.append(add);
        if(rung.branches.length>1){const remove=document.createElement('button');remove.className='branch-remove';remove.dataset.ladderEdit='';remove.textContent='×';remove.title='Remove branch';remove.onclick=()=>{rung.branches=rung.branches.filter(b=>b.id!==branch.id);this.selection=null;this.changed();};line.append(remove);}
        this.bindDropTarget(line,{kind:'input',rungId:rung.id,branchId:branch.id});branches.append(line);
      });
      for(const block of rung.blocks || []){
        const button=document.createElement('button');button.className='ladder-function';button.dataset.elementId=block.id;button.dataset.blockId=block.id;
        const p=block.params || {};const description=block.type==='SCHEDULE'?`Daily ${p.start || '17:30'}–${p.end || '05:30'} · ${p.timeZone || 'Asia/Jakarta'}`:timerTypes.includes(block.type)?`${valueText((p.durationMs || 0)/1000)} s`:countTypes.includes(block.type)?`PV ${p.preset || 1}`:block.type==='BLINK'?`${(p.onMs || 1000)/1000}s / ${(p.offMs || 1000)/1000}s`:'FUNCTION';
        button.innerHTML=`<small>${esc(block.type)}</small><strong>${esc(this.types[block.type]?.label || block.type)}</strong><span>${esc(description)}</span><em class="block-live">—</em>`;button.onclick=()=>this.select({kind:'block',id:block.id,rungId:rung.id});this.bindMoveSource(button,{kind:'block',id:block.id,rungId:rung.id});$('.ladder-functions',row).append(button);
      }
      this.bindDropTarget($('.ladder-functions',row),{kind:'function',rungId:rung.id});
      const wireStart=document.createElement('button');wireStart.type='button';wireStart.className='ladder-wire-handle wire-start';wireStart.dataset.wireStart=rung.id;wireStart.dataset.ladderEdit='';wireStart.textContent='●';wireStart.title='Drag to the join handle to add a full parallel OR path';wireStart.setAttribute('aria-label','Start a parallel OR wire');this.bindPaletteSource(wireStart,{wireRungId:rung.id});$('.ladder-network',row).append(wireStart);
      const wireEnd=document.createElement('button');wireEnd.type='button';wireEnd.className='ladder-wire-handle wire-end';wireEnd.dataset.wireEnd=rung.id;wireEnd.dataset.ladderEdit='';wireEnd.textContent='●';wireEnd.title='Join a full parallel OR path here';this.bindDropTarget(wireEnd,{kind:'parallel',rungId:rung.id});branches.append(wireEnd);
      const wirePreview=document.createElementNS('http://www.w3.org/2000/svg','svg');wirePreview.classList.add('ladder-wire-preview');wirePreview.dataset.wirePreview=rung.id;wirePreview.setAttribute('aria-hidden','true');wirePreview.setAttribute('hidden','');wirePreview.append(document.createElementNS('http://www.w3.org/2000/svg','path'));$('.ladder-network',row).append(wirePreview);
      const parallel=document.createElement('button');parallel.type='button';parallel.className='ladder-parallel-drop';parallel.dataset.parallelRung=rung.id;parallel.dataset.ladderEdit='';parallel.innerHTML='<strong>⊏⊐ Add parallel OR path</strong><span>Drop a device or move a contact here · Each complete branch is OR</span>';this.bindDropTarget(parallel,{kind:'parallel',rungId:rung.id});parallel.onclick=event=>{if(!event.defaultPrevented&&!this.placement)this.placeInstruction({instruction:'PARALLEL'},{kind:'parallel',rungId:rung.id});};row.append(parallel);
      $('.ladder-coil-wrap',row).append(this.createOutputElement(rung));target.append(row);
    });
    const blank=document.createElement('button');blank.type='button';blank.id='ladder-blank-drop';blank.className='ladder-blank-drop';blank.innerHTML=`<strong>${this.ladder.rungs.length?'+ Drop an input device to add a rung':'Drag your first device here'}</strong><span>Or select a device in the library, then tap here. Choose its feature in the right panel.</span>`;this.bindDropTarget(blank,{kind:'new-rung'});target.append(blank);
    this.renderInspector();this.highlightSelection();this.refresh(this.devices,this.runtime);
  }
  hasOutputElement(rung) {return !!(rung.coil?.tagId || rung.coil?.deviceId || this.pendingCoilDevices.get(rung.id));}
  createOutputElement(rung) {
    const element=document.createElement('button');element.type='button';
    if(!this.hasOutputElement(rung)){
      element.className='ladder-output-slot';element.dataset.outputSlot=rung.id;element.dataset.ladderEdit='';element.dataset.elementId=`${rung.id}:output-slot`;
      element.innerHTML='<span aria-hidden="true">+</span><strong>Drop output</strong>';
      element.title='Output removed or not added. Drop a device here, or click to choose an output.';
      element.setAttribute('aria-label','Add output to '+(rung.name || rung.id));
      element.onclick=()=>this.select({kind:'output-slot',id:`${rung.id}:output-slot`,rungId:rung.id});
    }else{
      const tag=this.tag(rung.coil?.tagId),pendingDevice=this.devices.find(d=>d.id===(rung.coil?.deviceId || this.pendingCoilDevices.get(rung.id))),mode=rung.coil?.mode || 'follow';
      element.className='ladder-coil';element.dataset.elementId=`${rung.id}:coil`;element.dataset.coilId=rung.id;
      element.innerHTML=`<small>${esc(tag?.address || (pendingDevice?'DEVICE':'UNMAPPED'))}</small><span class="coil-glyph"><svg viewBox="0 0 50 40" aria-hidden="true">${glyphs.coil}</svg><b>${mode==='pulse'?'P':mode==='trigger'?'A':mode==='value'?'V':mode==='adjust'?(rung.coil.delta<0?'−':'+'):''}</b></span><strong>${esc(tag?this.tagName(tag):pendingDevice?.name || 'Choose output feature')}</strong><span class="coil-feedback"><span data-coil-logic>Logic: Stopped</span><span data-coil-device>Device: Unknown</span><span class="command-badge" data-coil-command>Idle</span><span class="coil-observed" data-coil-observed>Not yet checked</span></span>`;
      element.onclick=()=>this.select({kind:'coil',id:`${rung.id}:coil`,rungId:rung.id});
    }
    this.bindDropTarget(element,{kind:'output',rungId:rung.id});return element;
  }
  addRung() {
    if(this.ladder?.version===2){try{const rung=this.graph.addRung();if(rung){this.selection={kind:'rung',id:rung.id,rungId:rung.id};this.graph.changed();}}catch(error){this.onError?.(error.message);}return;}
    if(this.runtime.running)return;
    if(this.ladder.rungs.length>=64){this.onError?.('A ladder program can contain up to 64 rungs.');return;}
    const id=this.uid('rung');
    this.ladder.rungs.push({id,name:`Rung ${this.ladder.rungs.length+1}`,branches:[{id:this.uid('branch'),contacts:[]}],blocks:[],coil:{deviceId:'',tagId:'',mode:'follow',value:false}});
    this.selection={kind:'rung',id,rungId:id};this.changed();
  }
  addContact(rung,branch) {
    if(this.runtime.running)return;
    const tag=this.ladder.tags.find(t=>t.direction==='input'),id=this.uid('contact');
    branch.contacts.push({id,tagId:tag?.id || '',kind:tag?.dataType==='number'||tag?.dataType==='string'?'COMPARE':'NO',operator:tag?.dataType==='string'?'EQ':'GT',value:tag?.dataType==='string'?'':0});
    this.selection={kind:'contact',id,rungId:rung.id,branchId:branch.id};this.changed();
  }
  openFunctionLibrary(rung) {
    if(this.runtime.running)return;
    const dialog=document.createElement('dialog');dialog.className='ladder-library-dialog';
    dialog.innerHTML='<div class="dialog-header"><div><span class="eyebrow">LADDER FUNCTION LIBRARY</span><h2>Add function</h2></div><button class="icon-button close-library" aria-label="Close">×</button></div><input class="library-search" type="search" placeholder="Search timers, counters, math…" aria-label="Search ladder functions"><div class="library-category-tabs"></div><div class="node-library"></div>';
    const functions=Object.entries(this.types).filter(([type])=>!['INPUT','OUTPUT','CONST','VIRTUAL'].includes(type));
    let category='All';const render=()=>{const query=$('.library-search',dialog).value.toLowerCase();const grid=$('.node-library',dialog);grid.replaceChildren();for(const [type,meta] of functions){if(category!=='All'&&meta.category!==category)continue;if(!`${type} ${meta.label} ${meta.description}`.toLowerCase().includes(query))continue;const button=document.createElement('button');button.className='library-button';button.innerHTML=`<strong>${esc(type)}</strong><small>${esc(meta.description)}</small>`;button.onclick=()=>{if(this.runtime.running)return;if(this.ladder.version===2){dialog.close();this.graph.place({instruction:type},{kind:'graph',rungId:rung.id,x:350,y:100});return;}const block=this.makeFunction(type);(rung.blocks ||= []).push(block);this.selection={kind:'block',id:block.id,rungId:rung.id};dialog.close();this.changed();};grid.append(button);}if(!grid.children.length)grid.innerHTML='<p class="field-help">No matching functions.</p>';};
    for(const name of ['All',...new Set(functions.map(([,meta])=>meta.category))]){const button=document.createElement('button');button.className=`library-category${name==='All'?' active':''}`;button.textContent=name;button.onclick=()=>{category=name;$$('.library-category',dialog).forEach(el=>el.classList.toggle('active',el===button));render();};$('.library-category-tabs',dialog).append(button);}
    $('.library-search',dialog).oninput=render;$('.close-library',dialog).onclick=()=>dialog.close();dialog.onclose=()=>dialog.remove();document.body.append(dialog);render();dialog.showModal();
  }
  renderMapping() {
    this.container.innerHTML='<div class="ladder-toolbar"><div><strong>I/O mapping</strong><small>Add a device to import all available inputs and outputs.</small></div><div><button class="button primary small" id="ladder-add-device" data-ladder-edit>+ Add device</button><button class="quiet-button" id="ladder-add-tag" data-ladder-edit>+ Manual tag</button></div></div><p class="mapping-hint">Devices come from your authorized Tuya account. Pair new hardware in Tuya Smart / Smart Life, then sync devices here.</p><div id="ladder-tags" class="ladder-tags"></div>';
    $('#ladder-add-device',this.container).onclick=()=>this.openDevicePicker();
    $('#ladder-add-tag',this.container).onclick=()=>{const id=this.uid('tag');this.ladder.tags.push({id,name:'New input',address:`I${this.ladder.tags.filter(t=>t.direction==='input').length}.0`,direction:'input',deviceId:'',code:'',dataType:'boolean',scale:1,offset:0,unit:''});this.selection={kind:'tag',id};this.changed();};
    const target=$('#ladder-tags',this.container);
    if(!this.ladder.tags.length)target.innerHTML='<div class="empty-state"><h3>Map your first I/O tag</h3><p>Choose a device and property, then give it a PLC address.</p></div>';
    for(const tag of this.ladder.tags){
      const button=document.createElement('button');button.className='tag-card';button.dataset.elementId=tag.id;button.dataset.tagId=tag.id;
      const device=this.devices.find(d=>d.id===tag.deviceId);
      button.innerHTML=`<span class="tag-address ${tag.source==='virtual'?'virtual':tag.direction==='output'?'output':''}">${esc(tag.address)}</span><div><strong>${esc(this.tagName(tag))}</strong><small>${tag.source==='virtual'?'Local test input · '+(tag.dataType==='number'?'analog value':'switch'):esc(device?.name || 'Select device')+' · '+esc(tag.code || 'select property')}</small><small>${esc(tag.direction.toUpperCase())} · ${esc(tag.dataType)}${tag.dataType==='number'?` · raw × ${esc(tag.scale ?? 1)} + ${esc(tag.offset ?? 0)}`:''}</small></div><span class="tag-value">—</span>`;
      button.onclick=()=>this.select({kind:'tag',id:tag.id});target.append(button);
    }
    this.highlightSelection();this.refresh(this.devices,this.runtime);
  }
  openDevicePicker() {
    if(this.runtime.running)return;
    const dialog=document.createElement('dialog');dialog.className='ladder-library-dialog';
    dialog.innerHTML='<div class="dialog-header"><div><span class="eyebrow">AVAILABLE DEVICES</span><h2>Add a device</h2></div><button class="icon-button close-library" aria-label="Close">×</button></div><p class="field-help">Import every supported readable and writable property as a PLC tag. No property codes to enter.</p><div class="device-picker-list"></div>';
    const target=$('.device-picker-list',dialog);
    if(!this.devices.length)target.innerHTML='<div class="empty-state"><h3>No devices available</h3><p>Connect your Tuya API key in Settings and sync your devices.</p></div>';
    for(const device of this.devices){const properties=propertyModel(device),existing=this.ladder.tags.filter(t=>t.deviceId===device.id).length;const card=document.createElement('div');card.className='device-picker-card';card.innerHTML=`<div><h3>${esc(device.name)}</h3><p>${device.online?'ONLINE':'OFFLINE'} · ${properties.length} properties · ${existing} mapped tags</p><small>${properties.map(p=>`${esc(propertyLabel(p))} [${esc(p.code)}] (${esc(p.typeSpec?.type || 'unknown')})`).join(' · ')}</small></div><button class="button primary small">Add device</button>`;$('.button',card).onclick=()=>{this.importDevice(device);dialog.close();};target.append(card);}
    $('.close-library',dialog).onclick=()=>dialog.close();dialog.onclose=()=>dialog.remove();document.body.append(dialog);dialog.showModal();
  }
  importDevice(device) {
    if(this.runtime.running)return;
    const before=this.ladder.tags.length;
    for(const prop of propertyModel(device)){
      if(!primitiveTypes[prop.typeSpec?.type])continue;
      const directions=[];if(['ro','rw'].includes(prop.accessMode)||(!['wr','wo'].includes(prop.accessMode)&&Object.hasOwn(device.properties || {},prop.code)))directions.push('input');if(['rw','wr','wo'].includes(prop.accessMode))directions.push('output');
      for(const direction of directions){try{this.ensurePropertyTag(device,prop,direction);}catch(error){this.onError?.(error.message);break;}}
    }
    this.selection=null;this.changed();if(this.ladder.tags.length===before)this.onError?.('All supported properties are already mapped, or this device has no supported primitive properties.');
  }
  ensurePropertyTag(device,prop,direction) {
    const existing=this.ladder.tags.find(t=>t.deviceId===device.id&&t.code===prop.code&&t.direction===direction);if(existing)return existing;
    if(this.ladder.tags.length>=512)throw new Error('The program has reached the 512 I/O tag limit.');
    const spec=prop.typeSpec || {},dataType=primitiveTypes[spec.type];if(!dataType)throw new Error('This feature does not expose a supported primitive value.');
    const prefix=(dataType==='number'?'A':dataType==='string'?'S':'')+(direction==='output'?'Q':'I');let n=0,address;
    do{address=`${prefix}${n++}${dataType==='boolean'?'.0':''}`;}while(this.ladder.tags.some(t=>t.address===address));
    const tag={id:this.uid('tag'),name:`${device.name} · ${propertyLabel(prop)}`,address,direction,deviceId:device.id,code:prop.code,dataType,scale:direction==='input'&&dataType==='number'?1/(10**Number(spec.scale || 0)):1,offset:0,unit:spec.unit || ''};
    this.ladder.tags.push(tag);return tag;
  }
  writableFeatures(device) {return propertyModel(device).filter(p=>['rw','wr','wo'].includes(p.accessMode)&&primitiveTypes[p.typeSpec?.type]);}
  selectInputFeature(contact,device,feature) {
    if(!device||!feature){contact.deviceId=device?.id || '';contact.tagId='';return;}
    const tag=this.ensurePropertyTag(device,feature,'input');contact.deviceId=device.id;if(contact.tagId===tag.id)return;
    contact.tagId=tag.id;contact.kind=tag.dataType==='boolean'?(contact.kind==='NC'?'NC':'NO'):'COMPARE';contact.operator=tag.dataType==='string'?'EQ':'GT';contact.value=tag.dataType==='string'?'':0;delete contact.valueTagId;
  }
  featureHelpPanel(property,direction,tag) {
    if(!property)return '';
    const help=featureHelp(property,{direction,tag});
    return `<section class="feature-help" data-feature-help><strong>${esc(help.title)}</strong><p>${esc(help.description)}</p><small>${help.details.slice(0,2).map(esc).join('<br>')}</small>${help.details.length>2?`<details><summary>Value details</summary><ul>${help.details.slice(2).map(detail=>`<li>${esc(detail)}</li>`).join('')}</ul></details>`:''}</section>`;
  }
  contactFeatureFields(contact) {
    const tag=this.tag(contact.tagId),deviceId=contact.deviceId ?? tag?.deviceId ?? '',device=this.devices.find(d=>d.id===deviceId),features=this.readableFeatures(device);
    if(tag?.source==='virtual')return this.virtualFields(tag);
    const selectedFeature=tag?.deviceId===deviceId?tag.code:'';
    const missingDevice=deviceId&&!device?`<option value="${esc(deviceId)}" selected>${esc(deviceId)} · unavailable</option>`:'';
    let fields=`<label>Device<select id="ladder-contact-device"><option value="">Select device…</option>${missingDevice}${this.devices.map(d=>`<option value="${esc(d.id)}" ${d.id===deviceId?'selected':''}>${esc(d.name)}${d.online?'':' · OFFLINE'}</option>`).join('')}</select></label><label>Feature<select id="ladder-contact-feature"><option value="">Select readable feature…</option>${features.map(p=>`<option value="${esc(p.code)}" ${p.code===selectedFeature?'selected':''}>${esc(propertyLabel(p))} · ${esc(p.code)}</option>`).join('')}</select></label>`;
    if(!deviceId)fields+='<p class="field-help">Choose a device to see its readable features.</p>';
    else if(!features.length)fields+='<p class="field-help">This device has no supported readable features. Write-only features cannot be used as contacts.</p>';
    if(tag){const feedback=this.contactFeedback(tag);fields+='<p class="field-help">'+esc(tag.address)+' · '+esc(tag.dataType)+' · '+esc(feedback.text)+(feedback.actualText?'<br>'+esc(feedback.actualText):'')+(tag.dataType==='number'?'<br>Input = raw × '+esc(tag.scale ?? 1)+' + '+esc(tag.offset ?? 0)+'.':'')+'</p>';}
    fields+=this.featureHelpPanel(propertyModel(device).find(p=>p.code===tag?.code),'input',tag);
    fields+=this.deviceParametersFields(device);
    return fields;
  }
  outputModel(coil) {
    const tag=this.tag(coil.tagId),device=this.devices.find(d=>d.id===tag?.deviceId),feature=propertyModel(device).find(p=>p.code===tag?.code),spec=feature?.typeSpec || {};
    return {tag,device,feature,spec,kind:primitiveTypes[spec.type] || tag?.dataType || 'boolean',factor:10**Number(spec.scale || 0)};
  }
  coilFeedback(rung) {
    const {tag,device,feature}=this.outputModel(rung.coil || {}),nodeId=rung.graphRung?(this.graph.map[rung.id]?.nodes?.[rung.coil?.id]?.result || `ld_${rung.id}_${rung.coil?.id}`):`ld_${rung.id}_coil`,output=(this.runtime.nodes || []).find(node=>node.id===nodeId),feedback=(this.runtime.outputFeedback || []).find(item=>item.nodeId===nodeId&&item.deviceId===tag?.deviceId&&item.code===tag?.code);
    return deriveCoilFeedback({device,property:device?.properties?.[tag?.code],feature,output,feedback,running:!!this.runtime.running,executionMode:this.runtime.executionMode,mapped:!!tag});
  }
  coilFeedbackFields(rung) {
    return `<section id="ladder-output-feedback" class="output-feedback" data-feedback-rung="${esc(rung.id)}"><strong>Output feedback</strong><div><span>Logic</span><b data-inspector-logic>—</b></div><div><span>Actual device</span><b data-inspector-device>Unknown</b></div><div><span>Last command target</span><b data-inspector-desired>—</b></div><span class="command-badge" data-inspector-command>Idle</span><small data-inspector-observation></small><p data-inspector-command-error></p></section>`;
  }
  deviceParametersFields(device) {
    if(!device)return '';
    return `<details id="ladder-device-parameters" class="device-parameters" data-device-id="${esc(device.id)}"${this.runtime.running?' open':''}><summary>All device parameters <span data-parameter-count></span></summary><p>Actual device reports, units and freshness. Simulated overrides are shown separately on the ladder.</p><div data-parameter-list></div></details>`;
  }
  updateDeviceParameters() {
    const panel=$('#ladder-device-parameters',this.inspector);if(!panel)return;
    const monitoring=!!this.runtime.running;if(monitoring&&panel.dataset.monitorRunning!=='true')panel.open=true;panel.dataset.monitorRunning=String(monitoring);
    const device=this.devices.find(item=>item.id===panel.dataset.deviceId),properties=propertyModel(device),signature=JSON.stringify(properties.map(property=>[property.code,propertyLabel(property),property.accessMode,property.typeSpec?.type]));
    if(panel.dataset.signature!==signature){panel.dataset.signature=signature;$('[data-parameter-count]',panel).textContent=`(${properties.length})`;$('[data-parameter-list]',panel).innerHTML=properties.map(property=>`<div class="device-parameter" data-device-parameter="${esc(property.code)}"><span><strong>${esc(propertyLabel(property))}</strong><small>${esc(property.code)}</small></span><span><b data-parameter-value>Unknown</b><small data-parameter-quality>Unknown</small></span></div>`).join('') || '<p>No parameter metadata is available yet.</p>';}
    for(const row of $$('[data-device-parameter]',panel)){
      const feature=properties.find(property=>property.code===row.dataset.deviceParameter),property=device?.properties?.[feature?.code],feedback=deriveCoilFeedback({device,property,feature});
      $('[data-parameter-value]',row).textContent=feedback.actualFresh?feedback.actualText:feedback.actualValue!==undefined&&!['wr','wo'].includes(feature?.accessMode)?`Last: ${feedback.actualText}`:'Unknown';
      $('[data-parameter-quality]',row).textContent=feedback.actualFresh?'Live':feedback.qualityLabel;row.classList.toggle('fresh',feedback.actualFresh);row.title=feedback.observation+' · '+feedback.qualityLabel;
    }
  }
  selectOutputFeature(rung,device,feature) {
    if(!device||!feature){
      rung.coil.deviceId=device?.id || '';rung.coil.tagId='';
      if(this.selection?.rungId===rung.id&&['coil','output-slot'].includes(this.selection.kind))this.selection={kind:device?'coil':'output-slot',id:`${rung.id}:${device?'coil':'output-slot'}`,rungId:rung.id};
      return;
    }
    const tag=this.ensurePropertyTag(device,feature,'output'),spec=feature.typeSpec || {},coil=rung.coil;coil.deviceId=device.id;
    if(this.selection?.kind==='output-slot'&&this.selection.rungId===rung.id)this.selection={kind:'coil',id:`${rung.id}:coil`,rungId:rung.id};
    if(coil.tagId===tag.id)return;
    coil.tagId=tag.id;coil.mode='trigger';coil.value=tag.dataType==='boolean'?false:tag.dataType==='number'?spec.min ?? 0:spec.range?.[0] || '';
    delete coil.delta;delete coil.source;delete coil.durationMs;
  }
  coilFields(rung) {
    const coil=rung.coil ||= {tagId:'',mode:'follow',value:false},model=this.outputModel(coil),{tag,feature,spec,kind,factor}=model;
    const deviceId=this.pendingCoilDevices.get(rung.id) ?? coil.deviceId ?? tag?.deviceId ?? '',device=this.devices.find(d=>d.id===deviceId),features=this.writableFeatures(device);
    const selectedFeature=tag?.deviceId===deviceId?tag.code:'';
    const missingDevice=deviceId&&!this.devices.some(d=>d.id===deviceId)?`<option value="${esc(deviceId)}" selected>${esc(deviceId)} · unavailable</option>`:'';
    const missingFeature=selectedFeature&&!features.some(p=>p.code===selectedFeature)?`<option value="${esc(selectedFeature)}" selected>${esc(selectedFeature)} · unavailable</option>`:'';
    let fields=`<label>Device<select id="ladder-coil-device"><option value="">Select device…</option>${missingDevice}${this.devices.map(d=>`<option value="${esc(d.id)}" ${d.id===deviceId?'selected':''}>${esc(d.name)}${d.online?'':' · OFFLINE'}</option>`).join('')}</select></label><label>Feature<select id="ladder-coil-feature"><option value="">Select writable feature…</option>${missingFeature}${features.map(p=>`<option value="${esc(p.code)}" ${p.code===selectedFeature?'selected':''}>${esc(propertyLabel(p))} · ${esc(p.code)}</option>`).join('')}</select></label>`;
    if(!deviceId)fields+='<p class="field-help">Choose a device to see its writable features.</p>';
    else if(!features.length)fields+='<p class="field-help">This device has no supported writable features available. Read-only sensors cannot be used as outputs.</p>';
    if(!this.hasOutputElement(rung))return fields;
    fields+=this.coilFeedbackFields(rung);
    fields+=this.featureHelpPanel(feature,'output',tag);
    if(kind==='boolean') {
      if(['trigger','pulse'].includes(coil.mode))fields+=`<label>Action<select id="ladder-coil-value"><option value="true" ${coil.value===true?'selected':''}>Turn ON</option><option value="false" ${coil.value!==true?'selected':''}>Turn OFF</option></select></label>`;
      fields+=`<label>Behavior<select id="ladder-coil-mode"><option value="trigger" ${coil.mode==='trigger'?'selected':''}>Once when rung turns TRUE</option><option value="follow" ${coil.mode==='follow'?'selected':''}>Continuous — follow rung ON/OFF</option><option value="pulse" ${coil.mode==='pulse'?'selected':''}>Timed pulse</option><option value="value" ${coil.mode==='value'?'selected':''}>Dynamic boolean value</option></select></label>`;
    } else {
      const adjust=kind==='number'&&feature?.accessMode==='rw';
      fields+=`<label>Action<select id="ladder-coil-mode"><option value="trigger" ${coil.mode==='trigger'?'selected':''}>${kind==='string'&&!Array.isArray(spec.range)?'Set text':'Set value'}</option>${kind==='number'?`<option value="increase" ${coil.mode==='adjust'&&coil.delta>0?'selected':''} ${!adjust?'disabled':''}>Increase by</option><option value="decrease" ${coil.mode==='adjust'&&coil.delta<0?'selected':''} ${!adjust?'disabled':''}>Decrease by</option>`:''}<option value="value" ${coil.mode==='value'?'selected':''}>Dynamic value</option></select></label>`;
      if(coil.mode==='trigger') {
        const numberAttrs=kind==='number'?`type="number" step="${esc(Number.isFinite(spec.step)?spec.step/factor:'any')}" ${Number.isFinite(spec.min)?`min="${spec.min/factor}"`:''} ${Number.isFinite(spec.max)?`max="${spec.max/factor}"`:''}`:'type="text"';
        const control=Array.isArray(spec.range)?`<select id="ladder-coil-value"><option value="">Select a value…</option>${spec.range.map(v=>`<option value="${esc(v)}" ${v===coil.value?'selected':''}>${esc(v)}</option>`).join('')}</select>`:`<input id="ladder-coil-value" ${numberAttrs} value="${esc(kind==='number'&&typeof coil.value==='number'?coil.value/factor:coil.value ?? '')}">`;
        fields+=`<label>Value${kind==='number'&&spec.unit?' ('+esc(spec.unit)+')':''}${control}</label>`;
      }
      if(kind==='number') {
        if(coil.mode==='adjust')fields+=`<label>Amount${spec.unit?' ('+esc(spec.unit)+')':''}<input id="ladder-coil-delta" type="number" min="${Number.isFinite(spec.step)&&spec.step>0?spec.step/factor:1/factor}" step="${Number.isFinite(spec.step)&&spec.step>0?spec.step/factor:'any'}" value="${Math.abs(coil.delta || spec.step || 1)/factor}"></label><p class="field-help">Read the current device value, ${coil.delta<0?'decrease':'increase'} it once on a rising rung, then clamp to the device range and round to its supported step.</p>`;
        fields+=`<p class="field-help">Range: ${esc(Number.isFinite(spec.min)?spec.min/factor:'—')} to ${esc(Number.isFinite(spec.max)?spec.max/factor:'—')} ${esc(spec.unit || '')} · step ${esc(Number.isFinite(spec.step)?spec.step/factor:'any')}. ${factor!==1?`Displayed values are converted to raw device values × ${esc(factor)}.`:'Values use the device scale.'}${!adjust?' Increase/decrease requires a readable and writable numeric feature.':''}</p>`;
      }
    }
    if(coil.mode==='pulse')fields+=`<label>Pulse duration (seconds)<input type="number" id="ladder-coil-duration" min="0.1" max="86400" step="0.1" value="${(coil.durationMs ?? 1000)/1000}"></label><p class="field-help">A rising rung starts one pulse, then restores the opposite value. Cloud response affects actual device timing.</p>`;
    if(coil.mode==='value'){fields+=this.operandFields(coil.source || {value:0},'coil-source','Value source (raw device units)',rung);fields+='<p class="field-help">Dynamic values are raw device values. Apply any required scaling in a function block before connecting the source.</p>';}
    fields+=`<details class="coil-advanced"><summary>Advanced · mapped output tag</summary><label>Output tag<select id="ladder-coil-tag">${this.tagOptions(coil.tagId,t=>t.direction==='output')}</select></label></details><p class="field-help">${coil.mode==='follow'?'The coil follows the rung: TRUE sends ON, FALSE sends OFF.':coil.mode==='value'?'While the rung is TRUE, send the source value when it changes. FALSE holds the last output.':'The action starts on a FALSE → TRUE rung transition.'} Stop leaves the last device state unchanged.</p>`;
    fields+=`<p class="field-help">Logic is the rung state; Device is the actual cloud report. ${coil.mode==='pulse'?'The pulse can return the device to its opposite value while the rung remains ON.':coil.mode==='trigger'?'An ON rung can request an OFF action; the two values do not have to match.':coil.mode==='value'?'Logic enables the output; the source supplies its separate value.':coil.mode==='adjust'?'The rung triggers an adjustment; the target is calculated from fresh device feedback.':'A sent command is not a confirmed device state.'}</p>`;
    fields+=this.deviceParametersFields(device);
    return fields;
  }
  renderInspector() {
    this.inspector.dataset.owner='ladder';
    if(!this.selection){this.inspector.innerHTML='<div class="empty-inspector"><h3>Select a ladder element</h3><p>Click a contact, function box, or coil to edit. Press Delete to remove the selected element. Deleting an output keeps its rung and inputs.</p></div>';return;}
    if(this.ladder.version===2&&this.graph.renderInspector())return;
    const selection=this.selection,canonical=this.ladder.rungs.find(r=>r.id===selection.rungId),rung=canonical&&this.ladder.version===2?this.graph.view(canonical,selection):canonical;
    if(selection.kind==='tag'){this.tagInspector(this.tag(selection.id));return;}
    if(!rung){this.selection=null;this.renderInspector();return;}
    let fields=`<span class="badge">${selection.kind==='output-slot'?'ADD OUTPUT':esc(selection.kind.toUpperCase())}</span>`;
    if(selection.kind==='rung'){
      fields+=`<label>Rung name<input id="ladder-rung-name" value="${esc(rung.name)}" maxlength="80"></label><p class="field-help">${rung.graphRung?'Draw power connections from a rail through contacts and functions to a coil. Series contacts are AND; explicit junctions combine paths with OR. Disconnected elements must be wired before saving.':'Contacts in a branch are in series. Parallel branches are OR conditions. An empty branch is always TRUE.'}</p><div class="input-row"><button type="button" id="ladder-rung-up" class="button secondary small">Move up</button><button type="button" id="ladder-rung-down" class="button secondary small">Move down</button></div><button type="button" id="ladder-duplicate-rung" class="quiet-button">Duplicate rung</button><button type="button" id="ladder-delete-rung" class="quiet-button delete-button">Delete rung</button>`;
    }else if(selection.kind==='contact'){
      const contact=rung.branches.find(b=>b.id===selection.branchId)?.contacts.find(c=>c.id===selection.id);if(!contact){this.selection=null;this.renderInspector();return;}
      fields+=this.contactFeatureFields(contact);
      fields+=`<label>Contact type<select id="ladder-contact-kind"><option value="NO" ${contact.kind==='NO'?'selected':''}>Normally open — NO</option><option value="NC" ${contact.kind==='NC'?'selected':''}>Normally closed — NC</option><option value="COMPARE" ${contact.kind==='COMPARE'?'selected':''} ${this.tag(contact.tagId)?.source==='virtual'&&this.tag(contact.tagId)?.dataType==='boolean'?'disabled':''}>Comparison contact</option></select></label><label>I/O tag<select id="ladder-contact-tag">${this.tagOptions(contact.tagId,t=>t.direction==='input'&&(contact.kind==='COMPARE'||t.dataType==='boolean'))}</select></label>`;
      if(contact.kind==='COMPARE')fields+=`<label>Comparison<select id="ladder-contact-operator">${Object.entries({GT:'Greater than >',GTE:'Greater or equal ≥',LT:'Less than <',LTE:'Less or equal ≤',EQ:'Equal =',NEQ:'Not equal ≠'}).map(([value,name])=>`<option value="${value}" ${value===contact.operator?'selected':''}>${esc(name)}</option>`).join('')}</select></label><label>Compare against<select id="ladder-compare-source"><option value="constant" ${!contact.valueTagId?'selected':''}>Constant value</option><option value="tag" ${contact.valueTagId?'selected':''}>Another I/O tag</option></select></label>${contact.valueTagId?`<label>Reference tag<select id="ladder-compare-tag">${this.tagOptions(contact.valueTagId)}</select></label>`:`<label>Comparison value${this.tag(contact.tagId)?.unit?" ("+esc(this.tag(contact.tagId).unit)+")":""}<input id="ladder-compare-value" type="${this.tag(contact.tagId)?.dataType==='string'?'text':'number'}" step="any" value="${esc(contact.value ?? 0)}"></label>`}`;
      fields+=this.tag(contact.tagId)?.source==='virtual'?'<p class="field-help">Reuse the same virtual input by selecting its I/O tag on another contact. Renaming it updates all contacts that use it.</p>':'<p class="field-help">Select the device and feature above. NO/NC contacts use boolean status. Comparison values use the input tag unit and scaling shown above.</p>';
      fields+='<button type="button" id="ladder-delete-contact" class="quiet-button delete-button">Delete contact</button>';
    }else if(selection.kind==='coil'||selection.kind==='output-slot'){
      fields+=this.coilFields(rung)+(this.hasOutputElement(rung)?'<button type="button" id="ladder-delete-coil" class="quiet-button delete-button">Delete output</button>':'');
    }else if(selection.kind==='block'){
      const block=rung.blocks.find(b=>b.id===selection.id);if(!block){this.selection=null;this.renderInspector();return;}
      const p=block.params ||= {};
      fields+=`<h3>${esc(block.type)} · ${esc(this.types[block.type]?.label || '')}</h3><p class="field-help">${esc(this.types[block.type]?.description || '')}</p>`;
      if(block.type==='SCHEDULE')fields+=dailyScheduleFields(p);
      if(timerTypes.includes(block.type))fields+=`<label>Duration (seconds)<input data-block-time="durationMs" type="number" min="0" max="86400" step="0.1" value="${(p.durationMs || 0)/1000}"></label>`;
      if(block.type==='BLINK')for(const [key,label] of [['onMs','ON time'],['offMs','OFF time']])fields+=`<label>${label} (seconds)<input data-block-time="${key}" type="number" min="0.1" max="86400" step="0.1" value="${(p[key] || 1000)/1000}"></label>`;
      if(countTypes.includes(block.type))fields+=`<label>Count preset<input id="ladder-block-preset" type="number" min="1" step="1" value="${p.preset || 1}"></label>`;
      if(['TONR','COUNTER','CTD','CTUD','LATCH','SR'].includes(block.type))fields+=`<label>${block.type==='CTD'?'Load preset tag':'Reset tag'}<select id="ladder-block-reset">${this.tagOptions(block.resetTagId,t=>t.direction==='input'&&t.dataType==='boolean','None — FALSE')}</select></label>`;
      if(block.type==='CTUD')fields+=`<label>Count down tag<select id="ladder-block-down">${this.tagOptions(block.downTagId,t=>t.direction==='input'&&t.dataType==='boolean','None — FALSE')}</select></label>`;
      if(operandCounts[block.type]){const operands=block.operands || [];for(let i=0;i<Math.max(operandCounts[block.type],operands.length);i++){const labels={CLAMP:['Value','Minimum','Maximum'],SELECT:['Condition','When TRUE','When FALSE']};fields+=this.operandFields(operands[i] || {value:0},`operand-${i}`,labels[block.type]?.[i] || `Operand ${String.fromCharCode(65+i)}`,rung,block.id);}}
      fields+='<p class="field-help">Function boxes run left to right. Numeric functions produce values; select them as a later operand or dynamic output source.</p><button type="button" id="ladder-delete-block" class="quiet-button delete-button">Delete function</button>';
    }
    if(['contact','block'].includes(selection.kind))fields+=rung.graphRung?'<p class="field-help">Drag the symbol to change its position. Wires stay connected; moving or crossing symbols never changes the logic.</p>':'<button type="button" id="ladder-move-element" class="button secondary small">Move selected element</button><p class="field-help">Drag the symbol to move it, or choose Move selected element and tap a highlighted destination. Put contacts in series for AND, or on a parallel path for OR.</p>';
    fields+='<p class="field-help">Select a symbol and press Delete to remove it. Text fields keep normal editing behavior.</p>';
    this.inspector.innerHTML=`<form id="ladder-element-form">${fields}</form>`;$('#ladder-element-form',this.inspector).onsubmit=e=>e.preventDefault();this.bindInspector(rung);this.bindVirtualControls(this.inspector);this.refresh(this.devices,this.runtime);
  }
  operandFields(source,key,label,rung,beforeId) {
    if(rung.graphRung){const port=key==='coil-source'?'value':key.replace('operand-','operand'),edge=rung.graphRung.edges.find(e=>e.to.nodeId===this.selection?.id&&e.to.port===port);if(edge)return `<div class="ladder-operand"><label>${esc(label)}</label><p class="field-help">Connected by wire from ${esc(edge.from.nodeId)} / ${esc(edge.from.port)}.</p><button type="button" class="quiet-button" data-disconnect-port="${esc(port)}">Disconnect value wire</button></div>`;}
    const kind=Object.hasOwn(source,'tagId')?'tag':Object.hasOwn(source,'blockId')?'block':'constant',type=typeof source.value==='boolean'?'boolean':typeof source.value==='string'?'string':'number';
    let blocks=rung.blocks || [];if(beforeId)blocks=rung.graphRung?blocks.filter(b=>b.id!==beforeId):blocks.slice(0,blocks.findIndex(b=>b.id===beforeId));
    return `<div class="ladder-operand" data-operand-key="${key}"><label>${esc(label)}<select data-operand-kind><option value="constant" ${kind==='constant'?'selected':''}>Constant</option><option value="tag" ${kind==='tag'?'selected':''}>I/O tag</option><option value="block" ${kind==='block'?'selected':''}>Earlier function</option></select></label>${kind==='tag'?`<select data-operand-value aria-label="${esc(label)} tag">${this.tagOptions(source.tagId)}</select>`:kind==='block'?`<select data-operand-value aria-label="${esc(label)} function"><option value="">Select function…</option>${source.blockId&&!blocks.some(b=>b.id===source.blockId)?`<option value="${esc(source.blockId)}" selected>Missing earlier function — select a replacement</option>`:''}${blocks.map(b=>`<option value="${esc(b.id)}" ${source.blockId===b.id?'selected':''}>${esc(b.type)} · ${esc(b.id)}</option>`).join('')}</select>`:`<div class="input-row"><select data-operand-type aria-label="Constant type"><option value="number" ${type==='number'?'selected':''}>Number</option><option value="boolean" ${type==='boolean'?'selected':''}>Boolean</option><option value="string" ${type==='string'?'selected':''}>Text</option></select>${type==='boolean'?`<select data-operand-value><option value="true" ${source.value===true?'selected':''}>TRUE</option><option value="false" ${source.value!==true?'selected':''}>FALSE</option></select>`:`<input data-operand-value type="${type==='number'?'number':'text'}" step="any" value="${esc(source.value ?? 0)}" aria-label="${esc(label)} value">`}</div>`}</div>`;
  }
  bindInspector(rung) {
    const bind=(selector,event,fn)=>{const el=$(selector,this.inspector);if(el)el.addEventListener(event,()=>{if(this.runtime.running)return;try{fn(el);if(rung.graphRung){const node=rung.graphRung.nodes.find(n=>n.id===this.selection?.id),port={'#ladder-block-reset':'reset','#ladder-block-down':'down','#ladder-compare-source':'value','#ladder-compare-tag':'value','#ladder-compare-value':'value'}[selector];if(node&&port)this.graph.bindingChanged(rung.id,node.id,port);if(node)this.graph.syncPorts(rung.graphRung,node);}this.changed();}catch(error){this.onError?.(error.message);}});};const s=this.selection;
    $('#ladder-move-element',this.inspector)?.addEventListener('click',()=>this.moveSelection());
    $$('[data-disconnect-port]',this.inspector).forEach(button=>button.onclick=()=>{if(this.runtime.running)return;this.graph.disconnectBinding(rung.id,this.selection.id,button.dataset.disconnectPort);this.graph.changed();});
    for(const selector of ['#ladder-delete-rung','#ladder-delete-contact','#ladder-delete-block','#ladder-delete-coil'])$(selector,this.inspector)?.addEventListener('click',()=>this.deleteSelection());
    bind('#ladder-rung-name','change',el=>{rung.name=el.value;});
    const move=delta=>{const i=this.ladder.rungs.indexOf(rung.graphRung || rung),to=i+delta;if(to>=0&&to<this.ladder.rungs.length)[this.ladder.rungs[i],this.ladder.rungs[to]]=[this.ladder.rungs[to],this.ladder.rungs[i]];};
    bind('#ladder-rung-up','click',()=>move(-1));bind('#ladder-rung-down','click',()=>move(1));
    bind('#ladder-duplicate-rung','click',()=>{if(rung.graphRung){const duplicate=copy(rung.graphRung),ids=new Map(duplicate.nodes.map(node=>[node.id,this.uid('copy')]));duplicate.id=this.uid('rung');duplicate.name=rung.name+' copy';for(const node of duplicate.nodes){node.id=ids.get(node.id);if(node.nodeType==='coil'){node.tagId='';node.deviceId='';}}for(const edge of duplicate.edges){edge.id=this.uid('wire');edge.from.nodeId=ids.get(edge.from.nodeId);edge.to.nodeId=ids.get(edge.to.nodeId);}this.ladder.rungs.splice(this.ladder.rungs.indexOf(rung.graphRung)+1,0,duplicate);this.selection={kind:'rung',id:duplicate.id,rungId:duplicate.id};return;}const duplicate=copy(rung);const ids=new Map();const newId=old=>{const id=this.uid('copy');ids.set(old,id);return id;};duplicate.id=newId(rung.id);duplicate.name=`${rung.name} copy`;for(const b of duplicate.branches){b.id=newId(b.id);for(const c of b.contacts)c.id=newId(c.id);}for(const b of duplicate.blocks)b.id=newId(b.id);for(const b of duplicate.blocks)for(const o of b.operands || [])if(o.blockId)o.blockId=ids.get(o.blockId)||o.blockId;if(duplicate.coil.source?.blockId)duplicate.coil.source.blockId=ids.get(duplicate.coil.source.blockId)||duplicate.coil.source.blockId;duplicate.coil.tagId='';this.ladder.rungs.splice(this.ladder.rungs.indexOf(rung)+1,0,duplicate);this.selection={kind:'rung',id:duplicate.id,rungId:duplicate.id};});
    if(s.kind==='contact'){
      const branch=rung.branches.find(b=>b.id===s.branchId),contact=branch.contacts.find(c=>c.id===s.id);
      bind('#ladder-virtual-name','change',el=>{const tag=this.tag(contact.tagId);if(tag?.source==='virtual')tag.name=el.value.trim() || 'Virtual switch';});
      bind('#ladder-virtual-default','change',el=>{if(!el.value||!el.checkValidity()||!Number.isFinite(Number(el.value)))throw new Error('Enter a finite reset value.');const tag=this.tag(contact.tagId);if(tag?.source==='virtual'&&tag.dataType==='number')tag.defaultValue=Number(el.value);});
      bind('#ladder-virtual-unit','change',el=>{const tag=this.tag(contact.tagId);if(tag?.source==='virtual'&&tag.dataType==='number')tag.unit=el.value.trim();});
      bind('#ladder-contact-device','change',el=>{this.selectInputFeature(contact,this.devices.find(d=>d.id===el.value),null);});
      bind('#ladder-contact-feature','change',el=>{const deviceId=contact.deviceId ?? this.tag(contact.tagId)?.deviceId,device=this.devices.find(d=>d.id===deviceId);this.selectInputFeature(contact,device,this.readableFeatures(device).find(p=>p.code===el.value));});
      bind('#ladder-contact-kind','change',el=>{contact.kind=el.value;if(contact.kind!=='COMPARE'&&this.tag(contact.tagId)?.dataType!=='boolean')contact.tagId='';});
      bind('#ladder-contact-tag','change',el=>{const tag=this.tag(el.value);contact.tagId=el.value;contact.deviceId=tag?.deviceId || '';if(tag?.source==='virtual'){contact.kind=tag.dataType==='number'?'COMPARE':contact.kind==='NC'?'NC':'NO';delete contact.valueTagId;}});bind('#ladder-contact-operator','change',el=>{contact.operator=el.value;});
      bind('#ladder-compare-source','change',el=>{if(el.value==='tag')contact.valueTagId=this.ladder.tags.find(t=>t.direction==='input')?.id || '';else delete contact.valueTagId;});
      bind('#ladder-compare-tag','change',el=>{contact.valueTagId=el.value;});bind('#ladder-compare-value','change',el=>{if(el.type==='number'&&!el.checkValidity())throw new Error('Enter a valid comparison value.');contact.value=primitive(this.tag(contact.tagId)?.dataType || 'number',el.value);});
    }
    if(s.kind==='coil'||s.kind==='output-slot'){
      const coil=rung.coil;
      bind('#ladder-coil-device','change',el=>{const device=this.devices.find(d=>d.id===el.value);this.selectOutputFeature(rung,device,this.writableFeatures(device)[0]);this.pendingCoilDevices.set(rung.id,el.value);});
      bind('#ladder-coil-feature','change',el=>{const deviceId=this.pendingCoilDevices.get(rung.id) ?? coil.deviceId ?? this.tag(coil.tagId)?.deviceId;const device=this.devices.find(d=>d.id===deviceId);this.selectOutputFeature(rung,device,this.writableFeatures(device).find(p=>p.code===el.value));});
      bind('#ladder-coil-tag','change',el=>{const tag=this.tag(el.value),device=this.devices.find(d=>d.id===tag?.deviceId),feature=propertyModel(device).find(p=>p.code===tag?.code);this.pendingCoilDevices.delete(rung.id);if(feature)this.selectOutputFeature(rung,device,feature);else coil.tagId=el.value;});
      bind('#ladder-coil-mode','change',el=>{
        const {kind,feature,spec}=this.outputModel(coil);
        if(['increase','decrease'].includes(el.value)){
          if(kind!=='number'||feature?.accessMode!=='rw')throw new Error('Relative actions require a readable and writable numeric feature.');
          coil.mode='adjust';coil.delta=(el.value==='decrease'?-1:1)*Math.abs(coil.delta || spec.step || 1);
        }else{
          coil.mode=el.value;
          if(coil.mode==='pulse'){coil.durationMs ||= 1000;if(typeof coil.value!=='boolean')coil.value=true;}
          if(coil.mode==='value')coil.source ||= {value:kind==='boolean'?false:kind==='number'?spec.min ?? 0:''};
        }
      });
      bind('#ladder-coil-value','change',el=>{const {kind,factor}=this.outputModel(coil);if((kind!=='string'&&!el.value)||!el.checkValidity())throw new Error('Enter a value within the device property range.');const value=primitive(kind,el.value);coil.value=kind==='number'?Math.round(value*factor*1e9)/1e9:value;if(kind==='number'&&!Number.isFinite(coil.value))throw new Error('Enter a finite numeric value.');});
      bind('#ladder-coil-delta','change',el=>{if(!el.value||!el.checkValidity()||Number(el.value)<=0)throw new Error('Enter a positive adjustment amount matching the supported step.');const {factor}=this.outputModel(coil),delta=Math.round(Number(el.value)*factor*1e9)/1e9;if(!Number.isFinite(delta)||delta===0)throw new Error('Enter a finite, nonzero adjustment amount.');coil.delta=(coil.delta<0?-1:1)*delta;});
      bind('#ladder-coil-duration','change',el=>{if(!el.checkValidity()||!el.value)throw new Error('Pulse duration must be 0.1–86,400 seconds.');coil.durationMs=Math.round(Number(el.value)*1000);});
    }
    if(s.kind==='block'){
      const block=rung.blocks.find(b=>b.id===s.id);
      $$('[data-schedule-param]',this.inspector).forEach(el=>el.onchange=()=>{if(this.runtime.running)return;try{const next=updateDailySchedule(block.params,el.dataset.scheduleParam,el.value);block.params=next;this.changed();}catch(error){el.value=block.params[el.dataset.scheduleParam]??dailyScheduleDefaults()[el.dataset.scheduleParam];this.onError?.(error.message);}});
      $$('[data-block-time]',this.inspector).forEach(el=>el.onchange=()=>{if(this.runtime.running)return;if(!el.value||!el.checkValidity()){this.onError?.('Enter a valid duration.');return;}block.params[el.dataset.blockTime]=Math.round(Number(el.value)*1000);this.changed();});
      bind('#ladder-block-preset','change',el=>{if(!el.value||!el.checkValidity())throw new Error('Preset must be a positive integer.');block.params.preset=Number(el.value);});
      bind('#ladder-block-reset','change',el=>{block.resetTagId=el.value;});bind('#ladder-block-down','change',el=>{block.downTagId=el.value;});
    }
    $$('[data-operand-key]',this.inspector).forEach(group=>{
      const get=()=>group.dataset.operandKey==='coil-source'?rung.coil.source:rung.blocks.find(b=>b.id===s.id).operands?.[Number(group.dataset.operandKey.split('-')[1])];
      const set=source=>{if(this.runtime.running)return;if(rung.graphRung){this.graph.setOperand(rung.id,s.id,group.dataset.operandKey==='coil-source'?'value':group.dataset.operandKey.replace('operand-','operand'),source);return;}if(group.dataset.operandKey==='coil-source')rung.coil.source=source;else{const block=rung.blocks.find(b=>b.id===s.id);block.operands ||= [];block.operands[Number(group.dataset.operandKey.split('-')[1])]=source;}this.changed();};
      $('[data-operand-kind]',group).onchange=event=>set(event.target.value==='tag'?{tagId:this.ladder.tags.find(t=>t.direction==='input')?.id || ''}:event.target.value==='block'?{blockId:rung.blocks.find(b=>b.id!==s.id)?.id || ''}:{value:0});
      $('[data-operand-type]',group)?.addEventListener('change',event=>set({value:event.target.value==='boolean'?false:event.target.value==='number'?0:''}));
      $('[data-operand-value]',group).onchange=event=>{const source=get() || {value:0};if('tagId'in source)set({tagId:event.target.value});else if('blockId'in source)set({blockId:event.target.value});else{if(event.target.type==='number'&&(!event.target.value||!event.target.checkValidity())){this.onError?.('Enter a valid operand.');return;}set({value:primitive(typeof source.value,event.target.value)});}};
    });
  }
  virtualTagInspector(tag) {
    this.inspector.innerHTML=`<form id="ladder-virtual-form">${this.virtualFields(tag)}<label>PLC address<input id="ladder-virtual-address" value="${esc(tag.address)}" maxlength="30"></label><p class="field-help">Select this I/O tag on multiple contacts to reuse the same input.</p><button type="button" id="ladder-delete-tag" class="quiet-button delete-button">Delete virtual input</button></form>`;
    $('#ladder-virtual-form',this.inspector).onsubmit=event=>event.preventDefault();
    $('#ladder-virtual-name',this.inspector).onchange=event=>{if(this.runtime.running)return;tag.name=event.target.value.trim() || 'Virtual switch';this.changed();};
    $('#ladder-virtual-address',this.inspector).onchange=event=>{if(this.runtime.running)return;tag.address=event.target.value.trim();this.changed();};
    $('#ladder-virtual-default',this.inspector)?.addEventListener('change',event=>{if(this.runtime.running)return;if(!event.target.value||!event.target.checkValidity()||!Number.isFinite(Number(event.target.value))){this.onError?.('Enter a finite reset value.');return;}tag.defaultValue=Number(event.target.value);this.changed();});
    $('#ladder-virtual-unit',this.inspector)?.addEventListener('change',event=>{if(this.runtime.running)return;tag.unit=event.target.value.trim();this.changed();});
    $('#ladder-delete-tag',this.inspector).onclick=()=>this.deleteSelection();this.bindVirtualControls(this.inspector);this.refresh(this.devices,this.runtime);
  }
  tagInspector(tag) {
    if(!tag){this.selection=null;this.renderInspector();return;}
    if(tag.source==='virtual'){this.virtualTagInspector(tag);return;}
    const device=this.devices.find(d=>d.id===tag.deviceId),properties=propertyModel(device).filter(p=>tag.direction==='output'?['rw','wr','wo'].includes(p.accessMode):!['wr','wo'].includes(p.accessMode));
    this.inspector.innerHTML=`<form id="ladder-tag-form"><span class="badge">I/O TAG</span><label>Tag name<input id="ladder-tag-name" value="${esc(this.tagName(tag))}" maxlength="80"></label><div class="input-row"><label>PLC address<input id="ladder-tag-address" value="${esc(tag.address)}" maxlength="30"></label><label>Direction<select id="ladder-tag-direction"><option value="input" ${tag.direction==='input'?'selected':''}>Input</option><option value="output" ${tag.direction==='output'?'selected':''}>Output</option></select></label></div><label>Device<select id="ladder-tag-device"><option value="">Select device…</option>${this.devices.map(d=>`<option value="${esc(d.id)}" ${d.id===tag.deviceId?'selected':''}>${esc(d.name)}${d.online?'':' · OFFLINE'}</option>`).join('')}</select></label><label>Device property<select id="ladder-tag-property"><option value="">Select property…</option>${properties.map(p=>`<option value="${esc(p.code)}" ${p.code===tag.code?'selected':''}>${esc(propertyLabel(p))} · ${esc(p.code)}</option>`).join('')}</select></label>${this.featureHelpPanel(properties.find(p=>p.code===tag.code),tag.direction,tag)}<label>Data type<select id="ladder-tag-type"><option value="boolean" ${tag.dataType==='boolean'?'selected':''}>Boolean — ON/OFF</option><option value="number" ${tag.dataType==='number'?'selected':''}>Number — analog value</option><option value="string" ${tag.dataType==='string'?'selected':''}>Text / enum</option></select></label>${tag.dataType==='number'?`<div class="input-row"><label>Multiplier ×<input id="ladder-tag-scale" type="number" step="any" value="${tag.scale ?? 1}"></label><label>Offset +<input id="ladder-tag-offset" type="number" step="any" value="${tag.offset ?? 0}"></label></div><label>Display unit<input id="ladder-tag-unit" value="${esc(tag.unit)}" maxlength="20"></label><p class="field-help">Input value = raw × multiplier + offset. Example: 2,500 mA × 0.001 = 2.5 A. Output values use the device raw format.</p>`:''}<div class="block-runtime"><span>Live value</span><strong id="ladder-tag-live">—</strong></div><button type="button" id="ladder-delete-tag" class="quiet-button delete-button">Delete tag</button></form>`;
    $('#ladder-tag-form',this.inspector).onsubmit=e=>e.preventDefault();
    const bind=(selector,key,convert=value=>value)=>$(selector,this.inspector)?.addEventListener('change',event=>{if(event.target.type==='number'&&(!event.target.value||!event.target.checkValidity())){this.onError?.('Enter a valid number.');return;}tag[key]=convert(event.target.value);this.changed();});
    bind('#ladder-tag-name','name');bind('#ladder-tag-address','address');bind('#ladder-tag-direction','direction');bind('#ladder-tag-scale','scale',Number);bind('#ladder-tag-offset','offset',Number);bind('#ladder-tag-unit','unit');
    $('#ladder-tag-type',this.inspector).onchange=event=>{tag.dataType=event.target.value;if(tag.dataType!=='number'){tag.scale=1;tag.offset=0;}this.changed();};
    $('#ladder-tag-device',this.inspector).onchange=event=>{tag.deviceId=event.target.value;tag.code='';this.changed();};
    $('#ladder-tag-property',this.inspector).onchange=event=>{tag.code=event.target.value;const model=propertyModel(this.devices.find(d=>d.id===tag.deviceId)).find(p=>p.code===tag.code);const spec=model?.typeSpec || {};tag.dataType=spec.type==='bool'?'boolean':['value','integer','float','double'].includes(spec.type)?'number':'string';tag.unit=spec.unit || '';tag.scale=tag.dataType==='number'?1/(10**Number(spec.scale || 0)):1;tag.offset=0;this.changed();};
    $('#ladder-delete-tag',this.inspector).onclick=()=>this.deleteSelection();
    this.refresh(this.devices,this.runtime);
  }
  telemetry() {
    if(!this.ladder)return;
    if(this.ladder.version===2&&this.mode!=='io'){this.graph.telemetry();return;}
    const evaluate=contact=>{const tag=this.tag(contact.tagId),a=this.readTag(tag);if(!a.valid)return {valid:false,value:false};if(contact.kind==='NO')return {valid:typeof a.value==='boolean',value:a.value===true};if(contact.kind==='NC')return {valid:typeof a.value==='boolean',value:a.value===false};const b=contact.valueTagId?this.readTag(this.tag(contact.valueTagId)):{valid:true,value:contact.value};if(!b.valid)return {valid:false,value:false};return {valid:true,value:({GT:()=>a.value>b.value,GTE:()=>a.value>=b.value,LT:()=>a.value<b.value,LTE:()=>a.value<=b.value,EQ:()=>a.value===b.value,NEQ:()=>a.value!==b.value}[contact.operator] || (()=>false))()};};
    for(const rung of this.ladder.version===2?[]:this.ladder.rungs){
      for(const branch of rung.branches)for(const contact of branch.contacts){const el=$$('[data-contact-id]',this.container).find(e=>e.dataset.contactId===contact.id);if(!el)continue;const state=evaluate(contact),tag=this.tag(contact.tagId),value=this.readTag(tag);el.classList.toggle('energized',!!this.runtime.running&&state.valid&&state.value);el.classList.toggle('invalid',!state.valid);$('.contact-live',el).textContent=value.valid?`${value.forced?'SIM · ':''}${valueText(value.value)}${tag?.unit?' '+tag.unit:''}`:value.quality.shortLabel;el.title=value.quality.observation+' · '+value.quality.label;const forceActive=tag?.source==='virtual'&&tag.dataType==='boolean'&&this.runtime.running&&['test','live-test'].includes(this.runtime.executionMode);el.dataset.forceActive=String(forceActive);if(forceActive){$('.contact-live',el).textContent=(value.value?'ON':'OFF')+' · Click to toggle';el.title=this.tagName(tag)+': click to force '+(value.value?'OFF':'ON')+(this.runtime.executionMode==='live-test'?' in Live Test (real device actions).':' in Test Run (simulated outputs).');}}
      const feedback=this.coilFeedback(rung),coil=$$('[data-coil-id]',this.container).find(e=>e.dataset.coilId===rung.id);
      if(coil){
        coil.classList.toggle('energized',feedback.logicOn);$('[data-coil-logic]',coil).textContent=`Logic: ${feedback.logicText}`;const actual=$('[data-coil-device]',coil);actual.textContent=`Device: ${feedback.deviceText}`;actual.classList.toggle('actual-fresh',feedback.actualFresh);actual.classList.toggle('device-on',feedback.actualFresh&&feedback.actualValue===true);actual.classList.toggle('device-off',feedback.actualFresh&&feedback.actualValue===false);actual.title=feedback.observation+' · '+feedback.qualityLabel;
        const command=$('[data-coil-command]',coil);command.textContent=feedback.commandText;command.dataset.status=feedback.commandKind;command.title=feedback.commandError || (feedback.hasDesired?'Last target: '+feedback.desiredText:'No command has been sent.');$('[data-coil-observed]',coil).textContent=feedback.observation;coil.title=`Logic: ${feedback.logicText}\nDevice: ${feedback.deviceText}\n${feedback.observation}\nCommand: ${feedback.commandText}${feedback.commandError?' · '+feedback.commandError:''}`;
      }
      const inspector=$('#ladder-output-feedback',this.inspector);if(inspector?.dataset.feedbackRung===rung.id){
        $('[data-inspector-logic]',inspector).textContent=feedback.logicText;$('[data-inspector-device]',inspector).textContent=feedback.deviceText;$('[data-inspector-device]',inspector).classList.toggle('actual-fresh',feedback.actualFresh);$('[data-inspector-desired]',inspector).textContent=feedback.desiredText;const command=$('[data-inspector-command]',inspector);command.textContent=feedback.commandText;command.dataset.status=feedback.commandKind;$('[data-inspector-observation]',inspector).textContent=feedback.observation+' · '+feedback.qualityLabel;$('[data-inspector-command-error]',inspector).textContent=feedback.commandError;
      }
      for(const block of rung.blocks || []){const el=$$('[data-block-id]',this.container).find(e=>e.dataset.blockId===block.id);if(!el)continue;const live=(this.runtime.nodes || []).find(n=>n.id===`ld_${rung.id}_${block.id}`);$('.block-live',el).textContent=!this.runtime.running?'READY':live?live.valid===false?'INVALID':Number.isFinite(live.elapsedMs)?`${(live.elapsedMs/1000).toFixed(1)} s`:Number.isFinite(live.count)?`CV ${live.count}`:valueText(live.value):'READY';el.classList.toggle('energized',!!this.runtime.running&&live?.valid!==false&&live?.value===true);}
    }
    for(const el of $$('[data-tag-id]',this.container)){const tag=this.tag(el.dataset.tagId),value=this.readTag(tag);$('.tag-value',el).textContent=value.valid?`${valueText(value.value)}${tag.unit?' '+tag.unit:''}`:value.quality.shortLabel;el.title=value.quality.observation+' · '+value.quality.label;}
    const tag=this.selection?.kind==='tag'?this.tag(this.selection.id):null,live=$('#ladder-tag-live',this.inspector);if(live&&tag){const value=this.readTag(tag);live.textContent=value.valid?`${valueText(value.value)} ${tag.unit || ''}`:value.quality.label;live.title=value.quality.observation;}
    this.updateDeviceParameters();
  }
}
