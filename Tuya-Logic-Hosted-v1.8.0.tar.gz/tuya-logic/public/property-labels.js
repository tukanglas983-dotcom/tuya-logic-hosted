// Display-only labels. Device property codes, values, and manufacturer metadata
// remain unchanged for API requests and saved programs.
const known = {
  switch:'Switch',switch_led:'Light switch',led_switch:'Indicator light',switch_usb:'USB switch',switch_backlight:'Backlight',child_lock:'Child lock',
  countdown:'Countdown',cur_current:'Current',cur_power:'Power',cur_voltage:'Voltage',current:'Current',voltage:'Voltage',power:'Power',
  add_ele:'Energy used',total_energy:'Total energy',forward_energy_total:'Total forward energy',reverse_energy_total:'Total reverse energy',
  relay_status:'Power-on state',power_on_state:'Power-on state',fault:'Fault alarm',alarm:'Alarm',alarm_switch:'Alarm enabled',
  light_mode:'Indicator mode',indicator_status:'Indicator status',work_mode:'Operating mode',mode:'Mode',status:'Status',
  temp_current:'Current temperature',cur_temperature:'Temperature',temperature:'Temperature',temp_set:'Target temperature',target_temperature:'Target temperature',temp_unit:'Temperature unit',
  temp_correction:'Temperature offset',temp_calibration:'Temperature calibration',temperature_calibration:'Temperature calibration',
  humidity_value:'Humidity',cur_humidity:'Humidity',humidity:'Humidity',humidity_set:'Target humidity',humidity_calibration:'Humidity calibration',
  battery_percentage:'Battery level',battery_state:'Battery status',battery_value:'Battery voltage',battery:'Battery',
  bright_value:'Brightness',bright_value_v2:'Brightness',temp_value:'Color temperature',temp_value_v2:'Color temperature',colour_data:'Color',colour_data_v2:'Color',scene_data:'Scene',scene_data_v2:'Scene',
  fan_speed:'Fan speed',fan_speed_enum:'Fan speed',speed:'Speed',percent_control:'Position setpoint',percent_state:'Current position',control:'Control',control_back_mode:'Motor direction',
  doorcontact_state:'Door contact',pir:'Motion detected',presence_state:'Presence',smoke_sensor_state:'Smoke alarm',gas_sensor_state:'Gas alarm',watersensor_state:'Water leak alarm',
  illuminance_value:'Illuminance',sensitivity:'Sensitivity',sensitivity_level:'Sensitivity level',distance:'Distance',
  overload:'Overload',over_current:'Overcurrent threshold',over_voltage:'Overvoltage threshold',under_voltage:'Undervoltage threshold',
  over_current_alarm:'Overcurrent alarm',over_voltage_alarm:'Overvoltage alarm',under_voltage_alarm:'Undervoltage alarm',
  phase_a:'Phase A measurements',phase_b:'Phase B measurements',phase_c:'Phase C measurements',
  timer:'Timer',cycle_time:'Cycle timer',random_time:'Random timer',countdown_set:'Countdown setting',
  switch_sound:'Sound enabled',volume_set:'Volume',mute:'Mute',eco:'Eco mode',sleep:'Sleep mode',
  filter_reset:'Reset filter',filter_life:'Filter life',filter_days:'Filter days remaining',cleaning:'Cleaning',
  pm25:'PM2.5',co2_value:'CO₂ concentration',voc_value:'VOC level',air_quality:'Air quality',
  key_code:'IR key-code parameter',key_code2:'IR key-code parameter 2',key_code3:'IR key-code parameter 3',key_code4:'IR key-code parameter 4',
  key_study:'Send learned IR code',key_study2:'Send learned IR code 2',key_study3:'Send learned IR code 3',key_study4:'Send learned IR code 4',
  ir_send:'IR transmit payload',ir_study_code:'Learned IR code report',study_code:'Learned IR code report',ir_code:'IR decoding payload'
};
const words={cur:'Current',temp:'Temperature',volt:'Voltage',ele:'Energy',hum:'Humidity',humidity:'Humidity',dp:'DP',id:'ID',usb:'USB',led:'LED',ir:'IR',uv:'UV',ac:'AC',dc:'DC',wifi:'Wi-Fi',ip:'IP',pir:'Motion',co2:'CO₂',pm25:'PM2.5',kwh:'kWh',rf:'RF',rgb:'RGB'};

export function hasNonLatinLetters(value) {
  return [...String(value ?? '')].some(char=>/\p{L}/u.test(char)&&!/\p{Script=Latin}/u.test(char));
}
export function propertyLabel(property, manufacturerName) {
  const code=String(typeof property==='string'?property:property?.code || '').trim();
  const name=String(manufacturerName ?? (typeof property==='object'?property?.name:'') ?? '').trim();
  if(name&&name!==code&&!hasNonLatinLetters(name))return name;
  const normalized=code.toLowerCase();
  if(known[normalized])return known[normalized];
  const channel=/^(switch|countdown|cur_current|cur_power|cur_voltage|temp_current|temp_set|humidity_value)_(\d+)$/u.exec(normalized);
  if(channel)return `${known[channel[1]]} ${channel[2]}`;
  const phase=/^(current|voltage|power|cur_current|cur_voltage|cur_power)_([abc])$/u.exec(normalized);
  if(phase)return `${known[phase[1]]} · phase ${phase[2].toUpperCase()}`;
  const tokens=code.replace(/([a-z])([A-Z])/g,'$1 $2').split(/[_\s.-]+/).filter(Boolean);
  if(!tokens.length)return 'Device property';
  return tokens.map((token,index)=>words[token.toLowerCase()] || (index===0?token[0].toUpperCase()+token.slice(1).toLowerCase():token.toLowerCase())).join(' ');
}

export function propertyQuality(property, device) {
  const reason=property?.qualityReason || (device?.online===false?'offline':property?.valid===true?'fresh':device?.error?'readfailed':property?'stale':'missing');
  const names={fresh:'Fresh cloud data',offline:'Offline',disconnected:'Disconnected',readfailed:'Read failed',stale:'Cached — sync devices to refresh',missing:'No data yet'};
  const shortNames={fresh:'LIVE',offline:'OFFLINE',disconnected:'DISCONNECTED',readfailed:'READ FAILED',stale:'CACHED',missing:'NO DATA'};
  const observedAt=property?.observedAt ?? property?.updatedAt;
  const date=observedAt?new Date(observedAt):null;
  const observation=date&&Number.isFinite(date.getTime())?`Cloud checked ${date.toLocaleTimeString('en-US',{hour12:false})}`:'Not yet checked';
  return {reason,label:names[reason] || names.missing,shortLabel:shortNames[reason] || shortNames.missing,observation,valid:reason==='fresh'&&property?.valid===true};
}

// Plain text only: consumers must use textContent or their normal HTML escaping.
// Standard meanings were checked against Tuya's switch/socket instructions and
// smart-switch function definitions. Model metadata always supplies units and
// limits; a familiar code is not evidence for an undocumented device protocol.
// https://developer.tuya.com/en/docs/iot/switch-socket-and-power-strip?id=K9gf7o3qbbklt
// https://developer.tuya.com/en/docs/iot/smart-switch-product-function-definition?id=K9r7gh4lbe886
const helpDescriptions = {
  cur_current:'Electrical current reported by the device. Use a numeric comparison to check a current threshold.',
  cur_power:'Electrical power reported by the device. Use a numeric comparison to check a power threshold.',
  cur_voltage:'Electrical voltage reported by the device. Use a numeric comparison to check a voltage threshold.',
  add_ele:'Energy consumption reported by the device. The reporting interval and whether this is an increment or a cumulative reading depend on the device; it is not an instantaneous power reading.',
  temp_current:'Temperature measured by the device. Use a comparison contact to check a temperature threshold.',
  cur_temperature:'Temperature measured by the device. Use a comparison contact to check a temperature threshold.',
  current_temperature:'Temperature measured by the device. Use a comparison contact to check a temperature threshold.',
  temperature:'Temperature reported by the device. Its sensor location depends on the device.',
  temp_set:'The target temperature requested from the device. It is a setpoint, not the measured temperature.',
  target_temperature:'The target temperature requested from the device. It is a setpoint, not the measured temperature.',
  humidity:'Humidity reported by the device. Use a comparison contact to check a humidity threshold.',
  cur_humidity:'Humidity reported by the device. Use a comparison contact to check a humidity threshold.',
  humidity_current:'Humidity reported by the device. Use a comparison contact to check a humidity threshold.',
  humidity_value:'Humidity reported by the device. Use a comparison contact to check a humidity threshold.',
  relay_status:'The configured switch state after power returns. This is a power-on setting, not the present switch feedback; use the device’s listed options.',
  fault:'Device fault status or fault flags. The meaning of each code or bit must come from this model’s documentation.',
  test_bit:'Manufacturer-defined test or diagnostic field. Its meaning is not documented here; do not assume it represents a particular sensor, relay, or alarm.',
  random_time:'The device’s random-timing configuration. Its schedule format and behavior depend on the model; a text value is not a simple ON/OFF switch.',
  cycle_time:'The device’s repeating-timer configuration. Its schedule format and behavior depend on the model; it is separate from a Ladder timer.',
  switch_inching:'The device’s inching or short-duration switching configuration. The payload format, duration and return behavior depend on the model; do not guess the text payload.'
};
// Tuya identifies these as protocol DPs, not custom phone-app button slots:
// https://developer.tuya.com/en/docs/iot-device-dev/Infrared_radio_frequency?id=Kay1cva9iq4ow
const irNameNote='Remote and button names assigned in Tuya Smart / Smart Life are not available through the current connection.';
function irDescription(code) {
  const key=/^key_code([2-4]?)$/.exec(code),learned=/^key_study([2-4]?)$/.exec(code);
  if(key)return `An IR remote key-code protocol parameter${key[1]?' ('+key[1]+')':''}. The field number does not identify a saved remote button. ${irNameNote}`;
  if(learned)return `A protocol payload used to send a learned IR code${learned[1]?' through parameter '+learned[1]:''}. This field is not an assigned button name. ${irNameNote}`;
  if(code==='ir_send')return `An IR transmission payload for the hub. Its command structure follows the device protocol; it is not a simple ON/OFF button. ${irNameNote}`;
  if(code==='ir_study_code'||code==='study_code')return `IR code data reported after learning from a remote. This is learned-code payload data, not a remote or button name. ${irNameNote}`;
  if(code==='ir_code')return `An IR signal-decoding protocol payload. Its structure follows this device's protocol. ${irNameNote}`;
  return null;
}
const helpTypes={bool:'boolean',boolean:'boolean',value:'number',integer:'number',float:'number',double:'number',number:'number',enum:'enum',string:'string',bitmap:'bitmap',raw:'raw',json:'json'};
const helpText=value=>typeof value==='string'?value.replace(/[\u0000-\u001f\u007f]/g,' ').trim():'';
const helpNumber=value=>Number.isFinite(value)?String(Number(value.toPrecision(12))):null;

export function featureHelp(property, {direction,tag}={}) {
  const p=property&&typeof property==='object'?property:{};
  const spec=p.typeSpec&&typeof p.typeSpec==='object'&&!Array.isArray(p.typeSpec)?p.typeSpec:{};
  const code=helpText(p.code).toLowerCase(),type=helpTypes[helpText(spec.type).toLowerCase()] || 'unknown';
  const access=helpText(p.accessMode).toLowerCase(),unit=helpText(spec.unit),details=[];
  const selectedDirection=direction || tag?.direction;
  const channel=/^(switch|countdown)_(\d+)$/.exec(code);
  let description=irDescription(code) || helpDescriptions[code];
  if(code==='switch'||channel?.[1]==='switch')description=`The ON/OFF state${channel?' of switch channel '+channel[2]:''}. TRUE means ON and FALSE means OFF for a standard switch feature.`;
  if(code==='countdown'||channel?.[1]==='countdown')description=`The device countdown${channel?' for switch channel '+channel[2]:''}. The action at expiry and the meaning of zero depend on the device; this is separate from a Ladder timer.`;
  if(!description)description='A manufacturer-defined device feature. Its exact behavior is not documented here; use the reported type, access and limits below, and the device manual.';
  if(access==='rw')details.push('Read/write: reports a value and accepts commands.');
  else if(access==='ro')details.push('Read-only: reported status; it cannot be used as an output.');
  else if(access==='wr'||access==='wo')details.push('Write-only: accepts commands; it cannot be used as a readable input.');
  else details.push('Access mode is not reported; input/output support is not confirmed.');
  const names={boolean:'Boolean — TRUE or FALSE',number:'Number',enum:'Enum — one of the listed text values',string:'Text',bitmap:'Bitmap — status flags',raw:'Encoded raw data',json:'Structured JSON data',unknown:'Not reported or unsupported'};
  details.push('Type: '+names[type]+(unit?' · unit: '+unit:'')+'.');
  if(type==='number'){
    const scale=spec.scale===undefined?0:Number.isInteger(spec.scale)&&spec.scale>=0&&spec.scale<=15?spec.scale:null;
    const factor=scale===null?1:10**scale,suffix=unit?' '+unit:'';
    if(scale===null)details.push('The reported decimal scale is invalid; the limits below are raw values.');
    else if(scale>0)details.push(`Decimal scale: ${scale}; display value = raw ÷ ${helpNumber(factor)}.`);
    const min=typeof spec.min==='number'&&Number.isFinite(spec.min)?spec.min:null;
    const max=typeof spec.max==='number'&&Number.isFinite(spec.max)?spec.max:null;
    if(min!==null&&max!==null&&min>max)details.push('The reported range is inconsistent; check the device model.');
    else if(min!==null||max!==null)details.push(`Reported range: ${min!==null?helpNumber(min/factor):'unspecified minimum'} to ${max!==null?helpNumber(max/factor):'unspecified maximum'}${scale===null?' (raw)':suffix}.`);
    if(typeof spec.step==='number'&&Number.isFinite(spec.step)&&spec.step>0)details.push(`Reported step: ${helpNumber(spec.step/factor)}${scale===null?' (raw)':suffix}.`);
    if(selectedDirection==='output')details.push('Fixed-value fields use the displayed device units; dynamic output sources use raw device values.');
  }
  if(type==='enum'){
    const values=Array.isArray(spec.range)?spec.range.filter(value=>typeof value==='string'):[];
    details.push(values.length?'Allowed values: '+values.map(value=>JSON.stringify(value)).join(', ')+'.':'Allowed values were not reported; do not invent an enum value.');
  }
  if(type==='string'&&Number.isInteger(spec.maxlen)&&spec.maxlen>=0)details.push(`Reported maximum text length: ${spec.maxlen}.`);
  if(type==='bitmap'){
    const labels=Array.isArray(spec.label)?spec.label.filter(value=>typeof value==='string'):[];
    if(labels.length)details.push('Device flag labels: '+labels.map(value=>JSON.stringify(value)).join(', ')+'.');
    details.push('Bitmap values are not supported as primitive Ladder inputs or outputs.');
  }else if(['raw','json','unknown'].includes(type))details.push('This metadata does not establish a supported primitive Ladder value.');
  if(tag&&typeof tag==='object'){
    const kind={boolean:'boolean',number:'numeric',string:'text / enum'}[tag.dataType] || 'unspecified';
    details.push(`PLC tag${helpText(tag.address)?' '+helpText(tag.address):''}: ${kind}${['input','output'].includes(selectedDirection)?' '+selectedDirection:''}. The address is a software mapping, not a physical terminal number.`);
    if(tag.dataType==='number'&&selectedDirection==='input'){
      const multiplier=tag.scale===undefined?1:tag.scale,offset=tag.offset===undefined?0:tag.offset;
      if(typeof multiplier==='number'&&Number.isFinite(multiplier)&&typeof offset==='number'&&Number.isFinite(offset))details.push(`Ladder input = raw × ${helpNumber(multiplier)} ${offset<0?'−':'+'} ${helpNumber(Math.abs(offset))}${helpText(tag.unit)?' '+helpText(tag.unit):''}. Comparison values use this tag scaling.`);
      else details.push('The tag scaling is invalid; correct it before using the input.');
    }
  }
  return {title:propertyLabel(p),description,details};
}
