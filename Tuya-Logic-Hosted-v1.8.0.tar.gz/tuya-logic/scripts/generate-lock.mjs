// Small registry-verified lock generator for this project's sole, exact ws dependency.
// No package scripts, optional native addons, or packages are installed.
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root = new URL('../', import.meta.url);
const pkg = JSON.parse(await readFile(new URL('package.json', root), 'utf8'));
if (Object.keys(pkg.dependencies || {}).join() !== 'ws' || !/^\d+\.\d+\.\d+$/.test(pkg.dependencies.ws)) {
  throw new Error('Dependency graph changed; generate the lock with npm install --package-lock-only --ignore-scripts.');
}
const response = await fetch(`https://registry.npmjs.org/ws/${pkg.dependencies.ws}`, {signal: AbortSignal.timeout(30000)});
if (!response.ok) throw new Error(`Registry metadata failed: ${response.status}`);
const meta = await response.json();
if (meta.name !== 'ws' || meta.version !== pkg.dependencies.ws || Object.keys(meta.dependencies || {}).length) {
  throw new Error('Unexpected package metadata; use npm to resolve the changed dependency graph.');
}
if (!meta.dist?.tarball?.startsWith('https://registry.npmjs.org/ws/-/') || !/^sha512-[A-Za-z0-9+/=]+$/.test(meta.dist?.integrity || '')) {
  throw new Error('Package metadata does not provide the expected HTTPS archive and SHA-512 integrity.');
}
const archiveResponse = await fetch(meta.dist.tarball, {signal: AbortSignal.timeout(30000)});
if (!archiveResponse.ok) throw new Error(`Package download failed: ${archiveResponse.status}`);
const archive = Buffer.from(await archiveResponse.arrayBuffer());
if (`sha512-${createHash('sha512').update(archive).digest('base64')}` !== meta.dist.integrity) {
  throw new Error('Downloaded package failed SHA-512 verification.');
}
const entry = {version: meta.version, resolved: meta.dist.tarball, integrity: meta.dist.integrity};
for (const key of ['license', 'engines', 'peerDependencies', 'peerDependenciesMeta']) {
  if (meta[key]) entry[key] = meta[key];
}
const lock = {name: pkg.name, version: pkg.version, lockfileVersion: 3, requires: true, packages: {
  '': {name: pkg.name, version: pkg.version, dependencies: pkg.dependencies, engines: pkg.engines},
  'node_modules/ws': entry
}};
await writeFile(new URL('package-lock.json', root), `${JSON.stringify(lock, null, 2)}\n`);
console.log(`package-lock.json generated; ws ${meta.version} archive integrity verified; no packages installed.`);
