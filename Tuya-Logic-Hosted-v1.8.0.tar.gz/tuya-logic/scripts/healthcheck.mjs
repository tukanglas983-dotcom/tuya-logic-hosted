// Public liveness only; never request device state or log response bodies.
try {
  const response = await fetch(`http://127.0.0.1:${process.env.PORT || 3210}/api/health`, {
    signal: AbortSignal.timeout(4000), redirect: 'error'
  });
  const body = response.ok ? await response.json() : null;
  process.exitCode = body?.ok === true ? 0 : 1;
} catch {
  process.exitCode = 1;
}
