-- Run once in the Supabase SQL editor as the project administrator.
-- Dedicated state only: never put device API keys or login hashes in this table.
begin;
create table if not exists public.tuya_logic_state (
  namespace text primary key check (namespace ~ '^[-a-zA-Z0-9_]{1,64}$'),
  programs jsonb,
  logs jsonb,
  revision bigint not null default 0,
  lease_owner uuid,
  lease_expires_at timestamptz not null default '-infinity'
);
alter table public.tuya_logic_state enable row level security;
alter table public.tuya_logic_state force row level security;
revoke all on table public.tuya_logic_state from public, anon, authenticated, service_role;

create or replace function public.tuya_logic_load(p_namespace text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare row public.tuya_logic_state;
begin
  select * into row from public.tuya_logic_state where namespace=p_namespace;
  return jsonb_build_object('programs',row.programs,'logs',row.logs,'revision',coalesce(row.revision,0));
end; $$;

create or replace function public.tuya_logic_lease(p_namespace text,p_owner uuid,p_ttl_seconds integer default 45)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare row public.tuya_logic_state; granted boolean; observed timestamptz;
begin
  if p_owner is null or p_ttl_seconds is null or p_ttl_seconds<30 or p_ttl_seconds>120 then raise exception 'Invalid lease request'; end if;
  insert into public.tuya_logic_state(namespace) values(p_namespace) on conflict do nothing;
  select * into row from public.tuya_logic_state where namespace=p_namespace for update;
  observed=clock_timestamp();
  granted=row.lease_owner=p_owner or row.lease_expires_at<=observed;
  granted=coalesce(granted,false);
  if granted then
    update public.tuya_logic_state set lease_owner=p_owner,lease_expires_at=observed+make_interval(secs=>p_ttl_seconds) where namespace=p_namespace returning * into row;
  end if;
  return jsonb_build_object('acquired',granted,'expires_at',row.lease_expires_at,'server_time',observed,'revision',row.revision);
end; $$;

create or replace function public.tuya_logic_write(p_namespace text,p_owner uuid,p_kind text,p_value jsonb)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare row public.tuya_logic_state;
begin
  if p_kind not in ('programs','logs') or p_kind is null or p_value is null then raise exception 'Invalid shared data'; end if;
  if p_kind='programs' and (jsonb_typeof(p_value)<>'object' or octet_length(p_value::text)>2097152) then raise exception 'Invalid programs'; end if;
  if p_kind='logs' then
    if jsonb_typeof(p_value)<>'array' then raise exception 'Invalid logs'; end if;
    if jsonb_array_length(p_value)>250 or octet_length(p_value::text)>262144 then raise exception 'Invalid logs'; end if;
  end if;
  select * into row from public.tuya_logic_state where namespace=p_namespace for update;
  if not found or p_owner is null or row.lease_owner is distinct from p_owner or row.lease_expires_at<=clock_timestamp() then raise exception 'Runtime lease unavailable'; end if;
  update public.tuya_logic_state set
    programs=case when p_kind='programs' then p_value else programs end,
    logs=case when p_kind='logs' then p_value else logs end,
    revision=revision+case when p_kind='programs' then 1 else 0 end
  where namespace=p_namespace returning * into row;
  return jsonb_build_object('ok',true,'revision',row.revision);
end; $$;

create or replace function public.tuya_logic_release(p_namespace text,p_owner uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
begin
  -- Reserve a drain interval. An external command already sent cannot be
  -- recalled merely by releasing a database lease.
  update public.tuya_logic_state set lease_expires_at=clock_timestamp()+interval '20 seconds'
    where namespace=p_namespace and lease_owner=p_owner and lease_expires_at>clock_timestamp();
  return jsonb_build_object('ok',true);
end; $$;

revoke all on function public.tuya_logic_load(text) from public, anon, authenticated;
revoke all on function public.tuya_logic_lease(text,uuid,integer) from public, anon, authenticated;
revoke all on function public.tuya_logic_write(text,uuid,text,jsonb) from public, anon, authenticated;
revoke all on function public.tuya_logic_release(text,uuid) from public, anon, authenticated;
grant execute on function public.tuya_logic_load(text) to service_role;
grant execute on function public.tuya_logic_lease(text,uuid,integer) to service_role;
grant execute on function public.tuya_logic_write(text,uuid,text,jsonb) to service_role;
grant execute on function public.tuya_logic_release(text,uuid) to service_role;
commit;
