// Read-only cloud rule discovery. These Cloud APIs can require a separate
// project authorization even when the Tuya.AI end-user device API works.
const CACHE_MS=60000,REFRESH_MS=5000,MAX_HOME_RESULTS=16;
const cloudReason='Not loaded. This Tuya connection cannot read the Cloud Scenes & Automations API. A Tuya Cloud project connection with the linked app account and scene permissions is required; the current device API key is not assumed to be expired.';
const unavailable=reason=>({status:'unavailable',items:[],reason});
const clone=value=>JSON.parse(JSON.stringify(value));
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const id=value=>{if(typeof value==='number'&&Number.isSafeInteger(value))value=String(value);if(typeof value!=='string'||!value||value.length>200)throw new Error('schema');return value;};
const name=value=>{if(typeof value!=='string'||!value.trim()||value.length>500)throw new Error('schema');return value;};
function safeJson(value,depth=0,budget={left:20000}){
  if(--budget.left<0||depth>10)throw new Error('schema');
  if(value===null||typeof value==='boolean')return value;
  if(typeof value==='number'&&Number.isFinite(value))return value;
  if(typeof value==='string'&&value.length<=10000)return value;
  if(Array.isArray(value)){if(value.length>1000)throw new Error('schema');return value.map(item=>safeJson(item,depth+1,budget));}
  if(plain(value)){const result=Object.create(null);for(const[key,item]of Object.entries(value)){if(['__proto__','constructor','prototype'].includes(key))continue;result[key]=safeJson(item,depth+1,budget);}return result;}
  throw new Error('schema');
}
function normalizeList(value,kind){
  if(!Array.isArray(value)||value.length>1000)throw new Error('schema');
  const seen=new Set(),budget={left:20000};
  return value.map(row=>{
    if(!plain(row))throw new Error('schema');
    const result={id:id(row[kind==='scenes'?'scene_id':'automation_id']??row.id),name:name(row.name)};
    if(seen.has(result.id))throw new Error('schema');seen.add(result.id);
    if(row.enabled!==undefined){if(typeof row.enabled!=='boolean')throw new Error('schema');result.enabled=row.enabled;}
    for(const field of ['conditions','actions'])if(row[field]!==undefined){if(!Array.isArray(row[field]))throw new Error('schema');result[field]=safeJson(row[field],0,budget);}
    return result;
  });
}
function failureReason(error){
  if(error?.message==='schema')return 'Not loaded. Tuya returned an unexpected rule-list format; no empty list was inferred.';
  const code=String(error?.message||'').match(/\(code ([A-Za-z0-9_-]+)\)/)?.[1];
  if(['1010','1011','1002','1004','1005','1106','28841001','28841002'].includes(code))return cloudReason;
  return 'Not loaded. The Tuya rule read did not succeed. Retry after checking the connection and Cloud project scene permissions.';
}
export class SceneReader {
  constructor({clock=Date.now}={}){this.now=clock;this.providers=new WeakMap();}
  async read(provider,{mode='live',homeId,refresh=false}={}){
    const time=this.now();
    if(mode!=='live'){const reason='Not loaded in demo mode. Connect a live Tuya account to check phone scenes and automations.';return {status:'demo',homes:[],homeId:null,scenes:unavailable(reason),automations:unavailable(reason),checkedAt:time,reason};}
    if(!provider||typeof provider.request!=='function'){const reason='Not loaded. The current connection has no cloud rule query capability.';return {status:'unavailable',homes:[],homeId:null,scenes:unavailable(reason),automations:unavailable(reason),checkedAt:time,reason};}
    if(homeId!==undefined&&(typeof homeId!=='string'||!homeId||homeId.length>200)){const error=new Error('Select a known home.');error.status=400;throw error;}
    let cache=this.providers.get(provider);
    if(!cache){cache={homes:null,homesAt:-Infinity,homesFailure:null,homesPending:null,results:new Map(),pending:new Map(),lastAttempt:-Infinity};this.providers.set(provider,cache);}
    const force=refresh&&time-cache.lastAttempt>=REFRESH_MS;
    if(!cache.homesPending&&(force||time-cache.homesAt>=CACHE_MS)){
      cache.lastAttempt=time;
      cache.homesPending=Promise.resolve().then(async()=>{
        try{
          const result=await provider.request('/v1.0/end-user/homes/all');
          if(!plain(result)||!Array.isArray(result.homes)||result.homes.length>1000)throw new Error('schema');
          const seen=new Set();cache.homes=result.homes.map(row=>{if(!plain(row))throw new Error('schema');const home={id:id(row.home_id),name:name(row.name)};if(seen.has(home.id))throw new Error('schema');seen.add(home.id);return home;});
          cache.homesFailure=null;
        }catch(error){cache.homes=null;cache.homesFailure=failureReason(error);cache.results.clear();}
        finally{cache.homesAt=this.now();cache.homesPending=null;}
      });
    }
    if(cache.homesPending)await cache.homesPending;
    if(!cache.homes){const reason=cache.homesFailure;return {status:'unavailable',homes:[],homeId:null,scenes:unavailable(reason),automations:unavailable(reason),checkedAt:cache.homesAt,reason};}
    const selected=homeId===undefined?cache.homes[0]?.id:homeId;
    if(selected&&!cache.homes.some(home=>home.id===selected)){const error=new Error('The selected home is not available in this account.');error.status=400;throw error;}
    if(!selected){const reason='Not loaded. This account returned no homes, so no scene or automation list was queried.';return {status:'unavailable',homes:[],homeId:null,scenes:unavailable(reason),automations:unavailable(reason),checkedAt:cache.homesAt,reason};}
    const previous=cache.results.get(selected);
    if(previous&&!force&&this.now()-previous.checkedAt<CACHE_MS)return clone({...previous,homes:cache.homes});
    if(!cache.pending.has(selected)){
      cache.lastAttempt=this.now();
      const work=(async()=>{
        const sections={};
        // Deliberately only GET list endpoints. No trigger/enable/disable API.
        for(const kind of ['scenes','automations']){
          try{sections[kind]={status:'available',items:normalizeList(await provider.request(`/v1.0/homes/${encodeURIComponent(selected)}/${kind}`),kind)};}
          catch(error){sections[kind]=unavailable(failureReason(error));}
        }
        const count=Object.values(sections).filter(section=>section.status==='available').length;
        const response={status:count===2?'available':count===1?'partial':'unavailable',homes:cache.homes,homeId:selected,...sections,checkedAt:this.now(),...(count<2?{reason:count===1?'Some rule lists were not loaded. See the connection reason for the unavailable section.':sections.scenes.reason}:{})};
        cache.results.delete(selected);cache.results.set(selected,response);while(cache.results.size>MAX_HOME_RESULTS)cache.results.delete(cache.results.keys().next().value);
        return response;
      })().finally(()=>cache.pending.delete(selected));
      cache.pending.set(selected,work);
    }
    return clone(await cache.pending.get(selected));
  }
}
