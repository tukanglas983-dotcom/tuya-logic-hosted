import {EventEmitter} from 'node:events';
import WebSocket from 'ws';

const REST={AY:'openapi.tuyacn.com',AZ:'openapi.tuyaus.com',EU:'openapi.tuyaeu.com',IN:'openapi.tuyain.com',UE:'openapi-ueaz.tuyaus.com',WE:'openapi-weaz.tuyaeu.com',SG:'openapi-sg.iotbing.com'};
const WS={AY:'wsmsgs.tuyacn.com',AZ:'wsmsgs.iot-wus.com',EU:'wsmsgs.iot-eu.com',IN:'wsmsgs.iot-ap.com',UE:'wsmsgs.iot-eus.com',WE:'wsmsgs.iot-weu.com',SG:'wsmsgs.iot-sea.com'};
export function regionForKey(key) {
  const match=/^sk-([A-Z]{2})[A-Za-z0-9_-]+$/.exec(key);
  if(!match || !REST[match[1]]) throw new Error('Use a Tuya.AI API Key starting with sk- and a supported region code.');
  return {prefix:match[1],baseUrl:'https://'+REST[match[1]],wsUrl:'wss://'+WS[match[1]]};
}
export function parseModel(result) {
  const m=typeof result?.model==='string'?JSON.parse(result.model):result?.model || result;
  const properties=(m?.services || []).flatMap(s=>s.properties || []);
  return properties.filter(p=>typeof p.code==='string');
}
export function validateCommand(device, code, value) {
  if(!device || !device.online) throw new Error('The device is unavailable or offline.');
  const p=device.model.find(p=>p.code===code);
  if(!p || !['rw','wr'].includes(p.accessMode)) throw new Error('This property cannot be controlled.');
  validatePropertyValue(p,value);
}
export function resolveAdjustment(device,code,delta) {
  if(typeof delta!=='number'||!Number.isFinite(delta)||delta===0)throw new Error('Adjustment must be a finite nonzero number.');
  const property=device?.model.find(p=>p.code===code),sample=device?.properties[code],spec=property?.typeSpec;
  if(!device?.online||device.error||property?.accessMode!=='rw'||spec?.type!=='value')throw new Error('Adjustments require an online readable and writable numeric property.');
  if(sample?.valid!==true||typeof sample.value!=='number'||!Number.isFinite(sample.value))throw new Error('The current output value is unavailable or stale; adjustment was not sent.');
  const {min,max}=spec,step=spec.step??1;
  if(![min,max,step].every(v=>typeof v==='number'&&Number.isFinite(v))||min>max||step<=0||!Number.isSafeInteger(Math.floor((max-min)/step)))throw new Error('The numeric property has invalid or unavailable range/step metadata.');
  validatePropertyValue(property,sample.value);
  const clamped=Math.max(min,Math.min(max,sample.value+delta));
  const steps=Math.max(0,Math.min(Math.floor((max-min)/step+1e-8),Math.round((clamped-min)/step)));
  const value=Math.max(min,Math.min(max,min+steps*step));
  validateCommand(device,code,value);
  return value;
}
function validatePropertyValue(p,value) {
  const s=p.typeSpec || {};
  if(s.type==='bool' && typeof value==='boolean') return;
  if(s.type==='enum' && s.range?.includes(value)) return;
  if(s.type==='string' && typeof value==='string' && value.length<=1024 && (!s.maxlen || value.length<=s.maxlen)) return;
  if(s.type==='value' && typeof value==='number' && Number.isFinite(value) && (s.min===undefined || value>=s.min) && (s.max===undefined || value<=s.max)) {
    const step=s.step || 1, q=(value-(s.min || 0))/step;
    if(Math.abs(q-Math.round(q))<1e-8) return;
  }
  throw new Error('The value does not match the property type, range, or step.');
}

export class TuyaClient extends EventEmitter {
  constructor(key,{fetchImpl=fetch,WebSocketImpl=WebSocket,clock=Date.now}={}) {
    super(); this.key=key; this.region=regionForKey(key); this.fetch=fetchImpl; this.WebSocket=WebSocketImpl; this.now=clock;
    this.devices=new Map(); this.closed=false; this.status='disconnected'; this.retry=0; this.requestTail=Promise.resolve(); this.issueTail=Promise.resolve();
  }
  async request(path,body,{shouldSend=()=>true,prepareBody}={}) {
    // Serialize requests with a gap to avoid bursts against trial quotas.
    const work=this.requestTail.then(async()=>{
      if(this.closed) throw new Error('The Tuya connection has been closed.');
      if(this.backoffUntil>this.now()) throw new Error('The Tuya rate limit was reached; wait before trying again.');
      if(!shouldSend()) throw new Error('The command was cancelled before sending.');
      const payload=prepareBody?prepareBody():body;
      const response=await this.fetch(this.region.baseUrl+path,{method:payload===undefined?'GET':'POST',headers:{Authorization:`Bearer ${this.key}`,'Content-Type':'application/json'},body:payload===undefined?undefined:JSON.stringify(payload),signal:AbortSignal.timeout(10000)});
      const json=await response.json();
      if(response.status===429 || String(json.code)==='429') this.backoffUntil=this.now()+60000;
      if(!response.ok || json.success!==true) throw new Error(`Tuya API request failed (code ${String(json.code || response.status).replace(/[^a-zA-Z0-9_-]/g,'').slice(0,40)}). Check the key, permissions, and account quota.`);
      return json.result;
    });
    this.requestTail=work.catch(()=>{}).then(()=>new Promise(r=>setTimeout(r,150)));
    return work;
  }
  async discover() {
    const started=this.now();
    const result=await this.request('/v1.0/end-user/devices/all');
    if(!Array.isArray(result?.devices)) throw new Error('The Tuya device-list response is not recognized.');
    const ids=new Set();
    for(const row of result.devices) {
      const id=row.device_id; if(typeof id!=='string') continue;
      ids.add(id);
      const d=this.devices.get(id) || {id,properties:{},model:[]};
      Object.assign(d,{name:row.name || id,category:row.category});
      this.applyOnline(d,row.online===true,started); this.devices.set(id,d);
      try {
        d.model=parseModel(await this.request(`/v1.0/end-user/devices/${encodeURIComponent(id)}/model`));
        await this.refresh(id);
      } catch(e) { d.error=e.message; this.emit('warning',`${d.name}: ${e.message}`); }
    }
    for(const id of this.devices.keys()) if(!ids.has(id)) this.devices.delete(id);
    this.emit('change'); return this.list();
  }
  applyOnline(d,online,time=this.now()) {
    // Tuya event timestamps are Unix milliseconds. An old online event or a
    // REST request begun before an offline event must not revive the device.
    if(typeof online!=='boolean' || !Number.isFinite(time) || time<0 || time>this.now()+60000) return;
    if(d.onlineUpdatedAt!==undefined && time<d.onlineUpdatedAt) return;
    // Prefer offline when ordering is ambiguous at the same millisecond.
    if(time===d.onlineUpdatedAt && d.online===false && online) return;
    d.online=online; d.onlineUpdatedAt=time;
  }
  applyProperty(d,code,value,time=this.now(),source='event') {
    // Reject future/old events without reviving stale data.
    if(!Number.isFinite(time) || time<0 || time>this.now()+60000) return;
    const previous=d.properties[code];
    if(previous && time<previous.updatedAt) return;
    const p=d.model.find(p=>p.code===code), s=p?.typeSpec || {};
    const observedAt=Math.min(time,this.now());
    // A cloud observation and an observed value change are different facts.
    // REST detail has no sensor timestamp; only events provide reportedAt.
    d.properties[code]={value,updatedAt:time,observedAt,lastChangedAt:!previous||previous.value!==value?observedAt:previous.lastChangedAt??previous.updatedAt,...(source==='event'?{reportedAt:time}:previous?.reportedAt===undefined?{}:{reportedAt:previous.reportedAt}),unit:s.unit || '',scale:s.scale || 0,type:s.type || typeof value,writable:['rw','wr'].includes(p?.accessMode),source};
  }
  async refresh(id) {
    const d=this.devices.get(id); if(!d) throw new Error('The device was not found.');
    const started=this.now(),before=new Map(Object.entries(d.properties));
    try {
      const detail=await this.request(`/v1.0/end-user/devices/${encodeURIComponent(id)}/detail`);
      if(!detail || !detail.properties || typeof detail.properties!=='object'||Array.isArray(detail.properties)) throw new Error('Device status is unavailable.');
      this.applyOnline(d,detail.online===true,started); delete d.error;
      for(const [code,value] of Object.entries(detail.properties)) {
        // A successful detail read re-observes even an unchanged cloud state.
        // Never overwrite an event/another read received while this read was
        // in flight, including events with the same millisecond timestamp.
        if(d.properties[code]===before.get(code))this.applyProperty(d,code,value,started,'shadow');
      }
      d.lastShadowReadAt=Math.max(d.lastShadowReadAt??0,started);
      this.emit('change'); return d;
    } catch(e) {d.error=e.message; this.emit('change'); throw e;}
  }
  list() {
    const now=this.now();
    return [...this.devices.values()].map(d=>({...d,properties:Object.fromEntries(Object.entries(d.properties).map(([code,p])=>{
      const observedAt=p.observedAt??p.updatedAt;
      const qualityReason=!d.online?'offline':this.status!=='connected'?'disconnected':d.error?'readfailed':!Number.isFinite(observedAt)||now-observedAt>45000?'stale':'fresh';
      return [code,{...p,observedAt,qualityReason,valid:qualityReason==='fresh'}];
    }))}));
  }
  readInput(id,code) {
    const d=this.list().find(d=>d.id===id), p=d?.properties[code];
    const reasons={offline:'The device is offline.',disconnected:'The Tuya event connection is disconnected.',readfailed:'The latest device read failed.',stale:'The last cloud observation is older than 45 seconds.'};
    return p?.valid ? {value:p.value,valid:true} : {value:null,valid:false,reason:reasons[p?.qualityReason]||'Device data is unavailable.'};
  }
  issue(id,code,value,options={}) {
    // Keep read-modify-write actions ordered through confirmation, so a second
    // adjustment cannot reuse the first action's pre-command shadow.
    const work=this.issueTail.then(()=>this.issueNow(id,code,value,options));
    this.issueTail=work.catch(()=>{});return work;
  }
  async issueNow(id,code,value,{shouldSend=()=>true,adjustDelta}={}) {
    const d=this.devices.get(id);if(adjustDelta===undefined)validateCommand(d,code,value);
    if(this.status!=='connected') throw new Error('The Tuya event connection is not ready.');
    // Wait for outstanding reads before the final cancellation check.
    await this.requestTail;
    if(!shouldSend()) throw new Error('The command was cancelled because the program stopped.');
    await this.request(`/v1.0/end-user/devices/${encodeURIComponent(id)}/shadow/properties/issue`,undefined,{shouldSend,prepareBody:()=>{
      if(this.status!=='connected')throw new Error('The Tuya event connection is not ready.');
      if(adjustDelta!==undefined)value=resolveAdjustment(this.list().find(device=>device.id===id),code,adjustDelta);
      else validateCommand(this.devices.get(id),code,value);
      return {properties:JSON.stringify({[code]:value})};
    }});
    // Accepted by cloud is different from a confirmed device state.
    await new Promise(r=>setTimeout(r,800));
    const fresh=await this.refresh(id);
    if(!fresh.online || !this.readInput(id,code).valid || fresh.properties[code]?.value!==value) throw new Error('Tuya accepted the command, but the output state is not confirmed. Check the device.');
    return {confirmed:true,...(adjustDelta===undefined?{}:{value})};
  }
  connect() {
    if(this.closed) return;
    this.status='connecting'; this.emit('status',this.status);
    const socket=this.socket=new this.WebSocket(this.region.wsUrl,{headers:{Authorization:this.key},handshakeTimeout:10000});
    socket.on('open',()=>{if(this.closed)return; this.retry=0; this.status='connected'; this.lastPong=this.now(); this.emit('status',this.status); this.heartbeat=setInterval(()=>{if(this.now()-this.lastPong>55000){socket.terminate();return;}if(socket.readyState===1)socket.ping();},25000);});
    socket.on('pong',()=>{this.lastPong=this.now();});
    socket.on('message',raw=>{
      let event; try{event=JSON.parse(raw.toString());}catch{return;}
      if(event.success===false || event.error || event.errorCode && event.errorCode!=='SUCCESS') {this.emit('warning','Tuya rejected the event connection. Check account authorization.'); socket.close(1000);return;}
      const p=event.data || {},d=this.devices.get(p.devId);if(!d)return;
      if(event.eventType==='onlineStatusChange' && ['online','offline'].includes(p.status)) this.applyOnline(d,p.status==='online',Number(p.time));
      if(event.eventType==='devicePropertyChange') for(const prop of p.status || []) this.applyProperty(d,prop.code,prop.value,Number(prop.time));
      this.emit('change');
    });
    socket.on('error',()=>this.emit('warning','The Tuya event connection failed; the server will reconnect.'));
    socket.on('close',()=>{
      clearInterval(this.heartbeat);this.status='disconnected';this.emit('status',this.status);
      if(!this.closed) this.reconnect=setTimeout(()=>this.connect(),Math.min(60000,2000*2**Math.min(this.retry++,5)));
    });
  }
  close() {this.closed=true;clearTimeout(this.reconnect);clearInterval(this.heartbeat);this.socket?.close();this.status='disconnected';}
}

export class DemoClient {
  constructor() {
    this.current=0.8;this.online=true;this.switch=true;this.status='connected';
    this.climateOnline=true;this.controllerOnline=true;
    this.switchProperties={cur_voltage:2300,cur_power:1850};
    this.climateProperties={cur_temperature:285,cur_humidity:650};
    this.controllerProperties={target_temperature:240,mode:'auto',cur_temperature:235};
  }
  list() {
    const now=Date.now();
    const switchModel=[
      {code:'cur_current',name:'Current',accessMode:'ro',typeSpec:{type:'value',unit:'mA',scale:0,min:0,max:16000,step:1}},
      {code:'switch_1',name:'Switch',accessMode:'rw',typeSpec:{type:'bool'}},
      {code:'cur_voltage',name:'Voltage',accessMode:'ro',typeSpec:{type:'value',unit:'V',scale:1,min:0,max:2600,step:1}},
      {code:'cur_power',name:'Power',accessMode:'ro',typeSpec:{type:'value',unit:'W',scale:1,min:0,max:40000,step:1}}
    ];
    const climateModel=[
      {code:'cur_temperature',name:'Temperature',accessMode:'ro',typeSpec:{type:'value',unit:'°C',scale:1,min:-400,max:1250,step:1}},
      {code:'cur_humidity',name:'Humidity',accessMode:'ro',typeSpec:{type:'value',unit:'%',scale:1,min:0,max:1000,step:1}}
    ];
    const controllerModel=[
      {code:'target_temperature',name:'Target temperature',accessMode:'rw',typeSpec:{type:'value',unit:'°C',scale:1,min:160,max:350,step:5}},
      {code:'mode',name:'Mode',accessMode:'rw',typeSpec:{type:'enum',range:['auto','cool','heat']}},
      {code:'cur_temperature',name:'Current temperature',accessMode:'ro',typeSpec:{type:'value',unit:'°C',scale:1,min:-400,max:1250,step:1}}
    ];
    const properties=(model,values,online)=>Object.fromEntries(model.map(p=>[p.code,{value:values[p.code],unit:p.typeSpec.unit||'',scale:p.typeSpec.scale||0,type:p.typeSpec.type,updatedAt:now,valid:online,writable:['rw','wr'].includes(p.accessMode)}]));
    return [
      {id:'demo-switch',name:'Desk switch · simulation',category:'cz',online:this.online,model:switchModel,properties:properties(switchModel,{...this.switchProperties,cur_current:this.switch?Math.round(this.current*1000):0,switch_1:this.switch},this.online)},
      {id:'demo-climate',name:'Climate sensor · simulation',category:'wsdcg',online:this.climateOnline,model:climateModel,properties:properties(climateModel,this.climateProperties,this.climateOnline)},
      {id:'demo-controller',name:'Climate controller · simulation',category:'wk',online:this.controllerOnline,model:controllerModel,properties:properties(controllerModel,this.controllerProperties,this.controllerOnline)}
    ];
  }
  readInput(id,code) {const d=this.list().find(d=>d.id===id),p=d?.properties[code];return p?.valid?{value:p.value,valid:true}:{value:null,valid:false,reason:'The simulated device is offline or the input was not found.'};}
  async issue(id,code,value,{shouldSend=()=>true,adjustDelta}={}) {
    if(!shouldSend())throw new Error('The program stopped.');
    const device=this.list().find(d=>d.id===id);
    if(adjustDelta!==undefined)value=resolveAdjustment(device,code,adjustDelta);
    else validateCommand(device,code,value);
    if(id==='demo-switch'&&code==='switch_1')this.switch=value;
    else if(id==='demo-controller'&&['target_temperature','mode'].includes(code))this.controllerProperties[code]=value;
    else throw new Error('This simulated property cannot be controlled.');
    return {confirmed:true,...(adjustDelta===undefined?{}:{value})};
  }
  update(input) {
    if(!input||typeof input!=='object'||Array.isArray(input)) throw new Error('Simulation settings must be an object.');
    const {deviceId='demo-switch',current,online,switch:sw,properties}=input;
    const device=this.list().find(d=>d.id===deviceId);
    if(!device) throw new Error('The simulated device was not found.');
    if(deviceId!=='demo-switch'&&(current!==undefined||sw!==undefined)) throw new Error('Current and switch settings apply only to the simulated switch.');
    if(current!==undefined&&(typeof current!=='number'||!Number.isFinite(current)||current<0||current>16)) throw new Error('Current must be between 0 and 16 A.');
    if(online!==undefined&&typeof online!=='boolean') throw new Error('Online status must be boolean.');
    if(sw!==undefined&&typeof sw!=='boolean') throw new Error('Switch status must be boolean.');
    if(properties!==undefined&&(!properties||typeof properties!=='object'||Array.isArray(properties))) throw new Error('Simulated properties must be an object.');
    const entries=Object.entries(properties||{});
    // Validate the complete update before mutating any state. The simulation
    // can override sensor values; physical command permissions remain enforced.
    for(const [code,value] of entries) {
      const property=device.model.find(p=>p.code===code);
      if(!property) throw new Error(`Unknown simulated property: ${code}.`);
      if(code==='cur_current'&&current!==undefined||code==='switch_1'&&sw!==undefined) throw new Error('Set each simulated property only once per update.');
      validatePropertyValue(property,value);
    }
    if(deviceId==='demo-switch') {
      if(current!==undefined)this.current=current;
      if(online!==undefined)this.online=online;
      if(sw!==undefined)this.switch=sw;
      for(const [code,value] of entries) {
        if(code==='cur_current')this.current=value/1000;
        else if(code==='switch_1')this.switch=value;
        else this.switchProperties[code]=value;
      }
    } else if(deviceId==='demo-climate') {
      if(online!==undefined)this.climateOnline=online;
      for(const [code,value] of entries)this.climateProperties[code]=value;
    } else {
      if(online!==undefined)this.controllerOnline=online;
      for(const [code,value] of entries)this.controllerProperties[code]=value;
    }
  }
  close() {}
}
