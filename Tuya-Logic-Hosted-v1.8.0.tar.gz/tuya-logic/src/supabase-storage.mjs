import {randomUUID} from 'node:crypto';

const clone=value=>structuredClone(value);
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const failure=()=>Object.assign(new Error('Shared storage is unavailable. Changes were not confirmed; reconnect and check the saved version before retrying.'),{status:503});
export function supabaseConfiguration(env=process.env){
  if(!env.TUYA_SUPABASE_URL&&!env.TUYA_SUPABASE_SERVICE_KEY)return null;
  if(env.TUYA_HOSTED!=='1')throw new Error('Supabase persistence requires TUYA_HOSTED=1.');
  const url=env.TUYA_SUPABASE_URL,serviceKey=env.TUYA_SUPABASE_SERVICE_KEY,namespace=env.TUYA_STORAGE_NAMESPACE||'default';let parsed;
  try{parsed=new URL(url);}catch{}
  if(!parsed||parsed.protocol!=='https:'||parsed.origin!==url||!parsed.hostname.endsWith('.supabase.co'))throw new Error('Set TUYA_SUPABASE_URL to the HTTPS origin of your Supabase project.');
  if(!/^[-a-zA-Z0-9_]{1,64}$/.test(namespace))throw new Error('TUYA_STORAGE_NAMESPACE must contain 1–64 letters, digits, hyphens or underscores.');
  let legacy=false;
  if(typeof serviceKey==='string'&&/^sb_secret_[-A-Za-z0-9_]{16,}$/.test(serviceKey)){}
  else if(typeof serviceKey==='string'&&serviceKey.length<8192){try{const parts=serviceKey.split('.');legacy=parts.length===3&&JSON.parse(Buffer.from(parts[1],'base64url').toString()).role==='service_role';}catch{}}
  if(!legacy&&!(typeof serviceKey==='string'&&/^sb_secret_[-A-Za-z0-9_]{16,}$/.test(serviceKey)))throw new Error('Set TUYA_SUPABASE_SERVICE_KEY to a server secret key or legacy service_role key; public keys are not accepted.');
  return {url,serviceKey,namespace,legacy};
}

// Cache only programs and bounded logs. The database is authoritative; writes
// update this cache only after a lease-conditional RPC has confirmed them.
export class SupabaseStorage {
  #config;#fetch;#now;#owner;#deadline=0;#status='unavailable';#reason='Connecting to shared storage.';#cache={};#revision=-1;#closed=false;#polling=null;#tail=Promise.resolve();#timer;#abort=new AbortController();
  constructor({url,serviceKey,namespace='default',fetchImpl=fetch,now=()=>performance.now(),owner=randomUUID(),ttlSeconds=45,renewIntervalMs=10000,drainMarginMs=20000,onChange=()=>{}}){
    this.#config=supabaseConfiguration({TUYA_HOSTED:'1',TUYA_SUPABASE_URL:url,TUYA_SUPABASE_SERVICE_KEY:serviceKey,TUYA_STORAGE_NAMESPACE:namespace});
    if(!Number.isInteger(ttlSeconds)||ttlSeconds<30||ttlSeconds>120||!Number.isFinite(drainMarginMs)||drainMarginMs<20000||ttlSeconds*1000<=drainMarginMs)throw new Error('Invalid shared runtime lease timing.');
    this.#fetch=fetchImpl;this.#now=now;this.#owner=owner;this.ttlSeconds=ttlSeconds;this.renewIntervalMs=renewIntervalMs;this.drainMarginMs=drainMarginMs;this.onChange=onChange;this.kind='supabase';
  }
  loadKey(){return process.env.TUYA_API_KEY?.trim()||'';}
  get programSequence(){return this.#revision<0?null:this.#revision;}
  saveKey(){throw new Error('Hosted credentials are managed through server environment secrets.');}
  read(name,fallback){if(!['programs','logs'].includes(name))return fallback;return this.#cache[name]==null?clone(fallback):clone(this.#cache[name]);}
  #notify(reloaded=false){this.onChange?.(this.leaseState(),{reloaded});}
  revoke(reason='Shared storage is unavailable. Runtime stopped; waiting for a verified lease.'){
    const changed=this.#status!=='unavailable'||this.#deadline!==0;this.#deadline=0;this.#status='unavailable';this.#reason=reason;if(changed)this.#notify();
  }
  canWrite(){
    if(this.#closed)return false;
    if(this.#status==='active'&&this.#now()>=this.#deadline)this.revoke('Runtime lease expired. Commands stopped before another server can take ownership.');
    return this.#status==='active'&&this.#deadline>this.#now();
  }
  leaseState(){return {status:this.canWrite()?'active':this.#status,writable:this.canWrite(),reason:this.#reason};}
  async #rpc(name,args,{closing=false}={}){
    if(this.#closed&&!closing)throw failure();
    const headers={'Content-Type':'application/json',apikey:this.#config.serviceKey};
    if(this.#config.legacy)headers.Authorization='Bearer '+this.#config.serviceKey;
    try{
      const response=await this.#fetch(this.#config.url+'/rest/v1/rpc/tuya_logic_'+name,{method:'POST',headers,body:JSON.stringify({p_namespace:this.#config.namespace,...args}),redirect:'error',signal:closing?AbortSignal.timeout(5000):AbortSignal.any([this.#abort.signal,AbortSignal.timeout(5000)])});
      if(!response.ok)throw failure();
      const text=await response.text();if(Buffer.byteLength(text)>3145728)throw failure();
      const result=JSON.parse(text);if(!plain(result))throw failure();return result;
    }catch{throw failure();} // Never echo HTTP bodies, URLs, keys or token errors.
  }
  async reload(){
    try{
      const data=await this.#rpc('load',{});
      if(data.programs!==null&&!plain(data.programs)||data.logs!==null&&(!Array.isArray(data.logs)||data.logs.length>250)||!Number.isSafeInteger(data.revision))throw failure();
      if(this.#closed)throw failure();
      this.#cache={programs:clone(data.programs),logs:clone(data.logs)};this.#revision=data.revision;return data;
    }catch(error){this.revoke();throw error;}
  }
  async initialize(){await this.pollLease();if(!this.#closed){this.#timer=setInterval(()=>{void this.pollLease();},this.renewIntervalMs);this.#timer.unref?.();}return this;}
  pollLease(){
    if(this.#closed)return Promise.resolve(this.leaseState());
    if(this.#polling)return this.#polling;
    this.#polling=this.#tail.then(async()=>{
      const wasActive=this.canWrite(),started=this.#now();
      try{
        const lease=await this.#rpc('lease',{p_owner:this.#owner,p_ttl_seconds:this.ttlSeconds});
        if(this.#closed)return this.leaseState();
        if(typeof lease.acquired!=='boolean'||!Number.isSafeInteger(lease.revision))throw failure();
        if(!lease.acquired){
          const changed=this.#status!=='standby';this.#deadline=0;this.#status='standby';this.#reason='Standby: another server owns the runtime. Editing drafts and exports remain available.';
          if(changed)this.#notify();
          if(this.#revision!==lease.revision){await this.reload();this.#notify(true);}
          return this.leaseState();
        }
        const lifetime=Date.parse(lease.expires_at)-Date.parse(lease.server_time);
        if(!Number.isFinite(lifetime)||lifetime<=this.drainMarginMs||lifetime>this.ttlSeconds*1000+1000)throw failure();
        const deadline=started+Math.min(lifetime,this.ttlSeconds*1000)-this.drainMarginMs;
        const reloaded=!wasActive||this.#revision!==lease.revision;
        if(reloaded)await this.reload();
        if(this.#closed||this.#now()>=deadline)throw failure();
        this.#deadline=deadline;this.#status='active';this.#reason='This server owns the runtime lease. Programs are saved in shared storage.';this.#notify(reloaded);
      }catch{if(!this.#closed)this.revoke();}
      return this.leaseState();
    }).finally(()=>{this.#polling=null;});this.#tail=this.#polling.catch(()=>{});return this.#polling;
  }
  async write(name,value){
    if(!['programs','logs'].includes(name))throw new Error('Shared storage accepts programs and logs only.');
    if(name==='logs'&&(!Array.isArray(value)||value.length>250)||name==='programs'&&!plain(value))throw new Error('Invalid shared data.');
    const snapshot=clone(value);
    const task=this.#tail.then(async()=>{
      if(!this.canWrite())throw failure();
      try{
        const result=await this.#rpc('write',{p_owner:this.#owner,p_kind:name,p_value:snapshot});
        if(result.ok!==true||!Number.isSafeInteger(result.revision)||!this.canWrite())throw failure();
        this.#cache[name]=snapshot;this.#revision=result.revision;
      }catch(error){this.revoke();throw error;}
    });this.#tail=task.catch(()=>{});return task;
  }
  async close(){
    if(this.#closed)return;this.#closed=true;this.#deadline=0;this.#status='unavailable';this.#reason='The shared storage connection is closed.';clearInterval(this.#timer);this.#abort.abort();
    await this.#polling?.catch(()=>{});await this.#tail;
    try{await this.#rpc('release',{p_owner:this.#owner},{closing:true});}catch{}
  }
}
