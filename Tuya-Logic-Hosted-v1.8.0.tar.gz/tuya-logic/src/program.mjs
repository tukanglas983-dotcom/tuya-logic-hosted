export function exampleProgram() {
  return { id: 'arus-30-detik', name: 'Current > 2 A · switch OFF after 30 seconds', nodes: [
    {id:'arus',type:'INPUT',label:'Plug current',inputs:[],params:{deviceId:'demo-switch',code:'cur_current',scale:0.001,offset:0},x:40,y:80},
    {id:'batas',type:'CONST',label:'2 A limit',inputs:[],params:{value:2},x:40,y:270},
    {id:'lebih',type:'GT',label:'Current > limit',inputs:['arus','batas'],params:{},x:300,y:100},
    {id:'tunda',type:'TON',label:'Continuous for 30 s',inputs:['lebih'],params:{durationMs:30000},x:560,y:100},
    {id:'matikan',type:'OUTPUT',label:'Switch OFF',inputs:['tunda'],params:{deviceId:'demo-switch',code:'switch_1',value:false},x:820,y:100}
  ]};
}
export const emptyProgram = () => ({id:'program-tuya',name:'Tuya device program',nodes:[]});
