import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const credentialHelper=fileURLToPath(new URL('../windows/TuyaCredential.exe',import.meta.url));
const credentialTimeoutMs=10000;

function protectCredential(mode,input,errorMessage) {
  const r=spawnSync(credentialHelper,[mode],{input,encoding:'utf8',windowsHide:true,timeout:credentialTimeoutMs,maxBuffer:2*1024*1024});
  // Never propagate stdout/stderr or native error objects: they could include
  // credential material. All callers receive a fixed, non-secret message.
  if(r.error?.code==='ETIMEDOUT')throw new Error('Windows credential protection timed out after 10 seconds.');
  if(r.error?.code==='ENOENT')throw new Error('The Windows credential helper is missing. Restore windows/TuyaCredential.exe from the application package.');
  if(r.error||r.status!==0)throw new Error(errorMessage);
  return r.stdout;
}

export class Storage {
  constructor(dir = process.env.TUYA_LOGIC_DATA || path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), '.local', 'share'), 'TuyaLogic', 'data'),{hosted=process.env.TUYA_HOSTED==='1'}={}) {
    this.hosted=hosted;
    if(hosted&&(!process.env.TUYA_LOGIC_DATA||!path.isAbsolute(process.env.TUYA_LOGIC_DATA)||path.resolve(dir)!==path.resolve(process.env.TUYA_LOGIC_DATA)))throw new Error('Hosted mode requires TUYA_LOGIC_DATA to point to an absolute persistent-volume directory.');
    this.dir = dir;
    fs.mkdirSync(dir, {recursive:true, mode:0o700});
    if(hosted)fs.accessSync(dir,fs.constants.R_OK|fs.constants.W_OK);
    if (process.platform === 'win32') {
      const sid=protectCredential('user-sid','','Unable to identify the current Windows account.');
      if(!/^S-\d+(?:-\d+)+$/.test(sid))throw new Error('Unable to identify the current Windows account.');
      const account='*'+sid;
      const r = spawnSync('icacls.exe',[dir,'/inheritance:r','/grant:r',`${account}:(OI)(CI)F`],{windowsHide:true,encoding:'utf8',timeout:10000});
      if (r.status !== 0) throw new Error('Unable to protect the local configuration directory.');
    }
  }
  read(name, fallback) {
    const file = path.join(this.dir, name+'.json');
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file,'utf8'));
  }
  write(name, value) {
    const file=path.join(this.dir,name+'.json');
    fs.writeFileSync(file+'.tmp', JSON.stringify(value,null,2),{mode:0o600});
    fs.renameSync(file+'.tmp',file);
  }
  saveKey(key) {
    if(this.hosted)throw new Error('Hosted credentials are managed through server environment secrets.');
    if (!key) { this.write('credential',{}); return; }
    if (process.platform === 'win32') {
      const encrypted=protectCredential('protect',key,'Unable to encrypt the API Key with this Windows account.');
      this.write('credential',{dpapiV2:encrypted});
    } else this.write('credential',{apiKey:key});
  }
  loadKey() {
    if(this.hosted)return process.env.TUYA_API_KEY?.trim()||'';
    if(process.env.TUYA_API_KEY) return process.env.TUYA_API_KEY.trim();
    const c=this.read('credential',{});
    if(c.dpapiV2 && process.platform==='win32')return protectCredential('unprotect',c.dpapiV2,'This Windows account cannot decrypt the saved API Key.');
    if(c.dpapi && process.platform==='win32')return protectCredential('unprotect-legacy',c.dpapi,'This Windows account cannot decrypt the saved API Key.');
    return c.apiKey || '';
  }
}
